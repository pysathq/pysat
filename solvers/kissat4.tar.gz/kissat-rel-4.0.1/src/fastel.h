#ifndef _fastel_h_INCLUDED

struct kissat;
void kissat_fast_variable_elimination (struct kissat *);

#endif
