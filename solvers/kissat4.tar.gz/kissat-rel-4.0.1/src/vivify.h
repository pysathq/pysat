#ifndef _vivify_h_INCLUDED
#define _vivify_h_INCLUDED

struct kissat;

void kissat_vivify (struct kissat *);

#endif
