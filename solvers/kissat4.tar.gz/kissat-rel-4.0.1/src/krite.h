#ifndef _krite_h_INCLUDED
#define _krite_h_INCLUDED

#include <stdio.h>

struct kissat;
void kissat_write_dimacs (struct kissat *, FILE *);

#endif
