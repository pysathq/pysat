/*
 * uniqfn.h (normally it is better to use the mkstemp() POSIX function)
 *
 *  Created on: Mar 15, 2013
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef UNIQFN_H_
#define UNIQFN_H_

// system includes:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
// local includes:
// local defines:
// local types:

//
//=============================================================================
static inline char *get_filename(char *orig, char *ext, int id)
{
	char *dest = calloc((strlen(orig) + 500), sizeof(char));

	char hostname[100] = { 0 };
	gethostname(hostname, 99);

	sprintf(dest, "%s_%s_%d_%d", orig, hostname, getpid(), id);

	if (ext) {
		if (ext[0] != '.')
			strcat(dest, ".");

		strcat(dest, ext);
	}

	return dest;
}

//
//=============================================================================
static inline char *get_unique_filename(char *orig, char *ext)
{
	static int id = 0;
	return get_filename(orig, ext, ++id);
}

#endif // UNIQFN_H_
