/*
 * clausemm.h
 *
 *  Created on: Nov 16, 2011
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef CLAUSEMM_H_
#define CLAUSEMM_H_

// system includes:
// local includes:
#include "arena.h"
#include "clause.h"
#include "vect.h"
// local defines:

// local types:
//=============================================================================

// clause memory manager: a per-size free-chain layer over an arena that is
// borrowed, not owned, since problem and learnt clauses share a single
// arena (watchers and reasons cross-reference both -- see ergo.c)
struct clmm {
	struct arena *arena;
	bool          learnt;     // whether clauses here carry an activity word
	struct vect   free_heads; // aref per literal count (contains: aref)
};

//
//=============================================================================
static inline void clmm_init(struct clmm *self, struct arena *arena, bool learnt)
{
	self->arena  = arena;
	self->learnt = learnt;
	vect_init(&self->free_heads, sizeof(aref));
}

//
//=============================================================================
static inline struct clause *clmm_deref(struct clmm *self, aref r)
{
	return (struct clause *)arena_deref(self->arena, r);
}

// returns the head of this size's free chain if one is available; otherwise,
// bump-allocates a fresh clause of 'size' literals from the arena;
//=============================================================================
static inline aref clmm_alloc(struct clmm *self, size_t size)
{
	while (vect_size(&self->free_heads) <= size)
		vect_append(&self->free_heads, AREF_NIL);

	aref *head = vect_at(&self->free_heads, size);

	if (*head != AREF_NIL) {
		aref r = *head;
		struct clause *old = clmm_deref(self, r);
		*head = *(aref *)old->lits;

		// credit back exactly what clmm_free() charged for this slot
		arena_unfree(self->arena, cl_words((int)size, cl_has_acty(old)));

		return r;
	}

	return arena_alloc(self->arena, cl_words((int)size, self->learnt));
}

// grows 'free_heads' the same way clmm_alloc() does before indexing into it
//=============================================================================
static inline void clmm_free(struct clmm *self, aref r)
{
	struct clause *cl   = clmm_deref(self, r);
	int            size = cl_size(cl);

	arena_free(self->arena, cl_words(size, cl_has_acty(cl)));

	while (vect_size(&self->free_heads) <= (size_t)size)
		vect_append(&self->free_heads, AREF_NIL);

	aref *head = vect_at(&self->free_heads, size);
	*(aref *)cl->lits = *head;
	*head = r;
}

// every reference on a free chain lives in a chunk the arena is about to
// discard once compaction finishes;
//=============================================================================
static inline void clmm_clear_free_chains(struct clmm *self)
{
	for (size_t i = 0; i < vect_size(&self->free_heads); ++i)
		*(aref *)vect_at(&self->free_heads, i) = AREF_NIL;
}

// relocates one clause during a compaction pass
//=============================================================================
static inline aref clmm_reloc(struct arena *arena, aref old)
{
	struct clause *cl = (struct clause *)arena_old_deref(arena, old);

	if (cl_reloced(cl))
		return cl_relocation(cl);

	aref to = arena_reloc(arena, old, cl_words(cl_size(cl), cl_has_acty(cl)));
	cl_relocate(cl, to);

	return to;
}

//
//=============================================================================
static inline void clmm_destroy(struct clmm *self)
{
	vect_destroy(&self->free_heads);
}

#endif // CLAUSEMM_H_
