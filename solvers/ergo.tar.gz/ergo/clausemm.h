/*
 * clausemm.h
 *
 *  Created on: Nov 16, 2011
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef CLAUSEMM_H_
#define CLAUSEMM_H_

// system includes:
#include <limits.h>
// local includes:
#include "arena.h"
#include "clause.h"
#include "vect.h"
// local defines:

// local types:
//=============================================================================

DECLARE_VECT(aref_vect, aref, size_t);

// arena-backed clause storage with size-indexed free lists
struct clmm {
	struct arena    *arena;
	bool             learnt;     // activity layout for new clauses
	struct aref_vect free_heads; // aref per literal count (contains: aref)
};

//
//=============================================================================
static inline void clmm_init(struct clmm *self, struct arena *arena, bool learnt)
{
	self->arena  = arena;
	self->learnt = learnt;
	vect_init(&self->free_heads);
}

//
//=============================================================================
static inline struct clause *clmm_deref(struct clmm *self, aref r)
{
	return (struct clause *)arena_deref(self->arena, r);
}

// reuse a matching free slot or allocate from the arena
//=============================================================================
static inline aref clmm_alloc(struct clmm *self, size_t size)
{
	if (size > (size_t)INT_MAX - cl_words(0, self->learnt)) {
		fputs("ergo: clause too large for arena allocation\n", stderr);
		abort();
	}

	// buckets are needed only for sizes that have actually been freed.
	aref *head = size < vect_size(&self->free_heads) ?
			vect_at(&self->free_heads, size) : NULL;

	if (head && *head != AREF_NIL) {
		aref r = *head;
		struct clause *old = clmm_deref(self, r);
		*head = *(aref *)old->lits;

		// a promoted learnt can be freed in the permanent pool;
		// if its activity word is no longer needed, leave it as garbage
		assert(cl_has_acty(old) || !self->learnt);
		arena_unfree(self->arena, cl_words((int)size, self->learnt));

		return r;
	}

	return arena_alloc(self->arena, cl_words((int)size, self->learnt));
}

// shrink a clause, preserving activity and charging its tail
//=============================================================================
static inline void clmm_shrink(struct clmm *self, aref r, int size)
{
	struct clause *cl       = clmm_deref(self, r);
	int            old_size = cl_size(cl);

	cl_shrink(cl, size);
	arena_free(self->arena, old_size - size);
}

// grows the free-chain table only when there is a slot to store
//=============================================================================
static inline void clmm_free(struct clmm *self, aref r)
{
	struct clause *cl   = clmm_deref(self, r);
	int            size = cl_size(cl);

	arena_free(self->arena, cl_words(size, cl_has_acty(cl)));

	while (vect_size(&self->free_heads) <= (size_t)size)
		vect_append(&self->free_heads, AREF_NIL);

	aref *head = vect_at(&self->free_heads, size);
	*(aref *)cl->lits = *head;
	*head = r;
}

// discard free lists before releasing old chunks
//=============================================================================
static inline void clmm_clear_free_chains(struct clmm *self)
{
	for (size_t i = 0; i < vect_size(&self->free_heads); ++i)
		*(aref *)vect_at(&self->free_heads, i) = AREF_NIL;
}

// relocates one clause during a compaction pass
//=============================================================================
static inline aref clmm_reloc(struct arena *arena, aref old)
{
	struct clause *cl = (struct clause *)arena_old_deref(arena, old);

	if (cl_reloced(cl))
		return cl_relocation(cl);

	aref to = arena_reloc(arena, old, cl_words(cl_size(cl), cl_has_acty(cl)));
	cl_relocate(cl, to);

	return to;
}

//
//=============================================================================
static inline void clmm_destroy(struct clmm *self)
{
	vect_destroy(&self->free_heads);
}

#endif // CLAUSEMM_H_
