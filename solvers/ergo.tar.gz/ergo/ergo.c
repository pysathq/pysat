/*
 * ergo.c
 *
 *  Created on: Apr 2, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

// system includes:
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
#include "cnffmt.h"
#include "ext.h"
#include "api.h"
#include "ergo.h"
#include "ergodbg.h"

//
//=============================================================================
int ergo_dlevel(struct ergo *s)
{
	return vect_size(&s->trail_lim);
}

//
//=============================================================================
static inline void ergo_print_head(void)
{
	printf("c Search statistics:\n");
	printf("c Conflicts            Original                    Learnt            Progress\n");
	printf("c                Vars  Clauses Literals      Limit  Clauses Lit/Cl           \n");
}

//
//=============================================================================
static inline void ergo_print_tail(void)
{
	printf("c\n");
}

//
//=============================================================================
static inline void ergo_trace_cl(struct clause *cl, bool delete, FILE *to)
{
	if (delete)
		fprintf(to, "d ");

	cl_dump(cl, FMT_DIMACS, to);
}

//
//=============================================================================
static inline void ergo_trace_vect(struct vect *cl, bool delete, FILE *to)
{
	if (delete)
		fprintf(to, "d ");

	size_t i;
	int *lits = vect_begin(cl);

	for (i = 0; i < vect_size(cl); ++i) {
		lit_dump(lits[i], to);
		fprintf(to, " ");
	}

	fprintf(to, "0\n");
}

//
//=============================================================================
static double ergo_progress(struct ergo *s)
{
	double  progress = 0;
	double  pow_base = 1.0 / ergo_nvars(s);

	for (int i = 0; i <= ergo_dlevel(s); ++i) {
		int beg = i == 0 ? 0 : vect_memb(&s->trail_lim, int, i - 1);
		int end = i == ergo_dlevel(s) ? s->qtail : vect_memb(&s->trail_lim, int, i);
		progress += pow(pow_base, i) * (end - beg);
	}

	return progress / ergo_nvars(s);
}

//
//=============================================================================
static inline void ergo_print_status(struct ergo *s)
{
	int nvar = 0;
	if (vect_empty(&s->trail_lim))
		nvar = ergo_nvars(s) - s->qtail;
	else
		nvar = ergo_nvars(s) - *(int *)vect_begin(&s->trail_lim);

	printf("c %9d   %7d %8d %8d   %8d %8d %6.1f   %6.3f %%\n",
			(int)s->stat.conflicts, nvar, (int)ergo_nclauses(s),
			(int)s->stat.clauses_literals, (int)s->max_learnts,
			(int)ergo_nlearnts(s),
			(double)s->stat.learnts_literals / ergo_nlearnts(s),
			ergo_progress(s) * 100);
}

//
//=============================================================================
inline void ergo_print_model(struct ergo *s)
{
	if (vect_empty(&s->model))
		return;

	printf("v ");

	for (int i = 0; i < ergo_nvars(s); ++i) {
		if (*(lbool *)(vect_at(&s->model, i)) == ltrue)
			printf("+");
		else
			printf("-");
		printf("%d ", i + 1);
	}

	printf("0\n");
}

//
//=============================================================================
static inline void ergo_watcher(
	struct watcher *dest,
	aref cl,
	int blocker
)
{
	memset(dest, 0, sizeof(struct watcher));

	dest->cl      = cl;
	dest->blocker = blocker;
}

//
//=============================================================================
static inline struct vect *ergo_wlist(struct ergo *s, int l)
{
	return &s->wlists[l];
}

//
//=============================================================================
static inline void ergo_smudge_wlist(struct ergo *s, int l, aref cl)
{
	if (!s->wdirt_c[l]) {
		s->wdirt_c[l] = 1;
		vect_append(&s->wdirty, l);
	}
}

//
//=============================================================================
void ergo_clean_wlist(struct ergo *s, int l)
{
	struct vect *wl = ergo_wlist(s, l);

	size_t i, j;
	for (i = j = 0; i < vect_size(wl); ++i) {
		struct watcher *w  = vect_at(wl, i);
		aref            cr = AREF_UNTAG(w->cl);
		struct clause  *cl = arena_deref(&s->arena, cr);
		bool            lf = cl_learnt(cl);

		if (!cl_marked(cl)) {
			if (i != j)
				*(struct watcher *)vect_at(wl, j) = *w;
			++j;
		}
		else {
			assert(cl_marked(cl) < 3);

			if (cl_marked(cl) < 2)
				cl_mark(cl);
			else {
				// second watched literal is cleaned;
				// thus, the clause can be deleted
				if (lf) {
					s->stat.learnts--;
					s->stat.learnts_literals -= cl_size(cl);
					clmm_free(&s->learnts.storage, cr);
				}
				else {
					s->stat.clauses--;
					s->stat.clauses_literals -= cl_size(cl);
					clmm_free(&s->clauses.storage, cr);
				}
			}
		}
	}

	s->wdirt_c[l] = 0;
	vect_shrink(wl, j);
}

//
//=============================================================================
void ergo_clean_wlists(struct ergo *s)
{
	for (size_t i = 0; i < vect_size(&s->wdirty); ++i) {
		int l = vect_memb(&s->wdirty, int, i);
		ergo_clean_wlist(s, l);
	}

	vect_clear(&s->wdirty);
}

//
//=============================================================================
static inline void order_percolate_up(struct ergo *s, int i)
{
	int *heap   = vect_begin(&s->order);
	int  x      = heap[i];
	int  parent = (i - 1) / 2;

	while (i != 0 && s->activity[x] > s->activity[heap[parent]]) {
		heap[i]              = heap[parent];
		s->orderpos[heap[i]] = i;
		i      = parent;
		parent = (i - 1) / 2;
	}

	heap[i]        = x;
	s->orderpos[x] = i;
}

//
//=============================================================================
static inline void order_percolate_down(struct ergo *s, int i)
{
	int *heap   = vect_begin(&s->order);
	int  sz     = vect_size(&s->order);
	int  x      = heap[i];
	int  child  = 2 * i + 1;

	while (child < sz) {
		if (child + 1 < sz && s->activity[heap[child]] < s->activity[heap[child + 1]])
			++child;

		assert(child < sz);

		if (s->activity[x] >= s->activity[heap[child]])
			break;

		heap[i]              = heap[child];
		s->orderpos[heap[i]] = i;

		i     = child;
		child = 2 * child + 1;
	}

	heap[i]        = x;
	s->orderpos[x] = i;
}

//
//=============================================================================
void order_unassign(struct ergo *s, int v)
{
	if (s->orderpos[v] == -1) {
		s->orderpos[v] = vect_size(&s->order);
		vect_append(&s->order, v);

		order_percolate_up(s, s->orderpos[v]);
	}
}

//
//=============================================================================
static inline int order_select(struct ergo *s)
{
	// activity based decision
	int *heap = vect_begin(&s->order);

	while (vect_size(&s->order) > 0) {
		int sz   = vect_size(&s->order) - 1;

		int next = heap[0];
		s->orderpos[next] = -1;

		// popping the heap's last element: no replacement to move into
		// position 0, and nothing left to touch orderpos[next] again
		if (sz > 0) {
			heap[0] = heap[sz];
			s->orderpos[heap[0]] = 0;
		}

		vect_shrink(&s->order, sz);
		if (sz > 1)
			order_percolate_down(s, 0);

		// the gate is to correctly deal with retired extension variables
		if ((!s->ext || s->dec_var[next]) && s->assigns[lit_of(next)] == lundef)
			return next;
	}

	return var_undef;
}

//
//=============================================================================
static inline void order_rebuild(struct ergo *s)
{
	if (s->dec_vars) {
		// cleaning
		for (int v = 0; v < ergo_nvars(s); ++v)
			s->orderpos[v] = -1;
		vect_shrink(&s->order, 0);

		// creating a new heap
		s->dec_vars = 0;
		for (int v = 0; v < ergo_nvars(s); ++v) {
			if (s->dec_var[v] && s->assigns[lit_of(v)] == lundef) {
				s->orderpos[v] = vect_size(&s->order);
				vect_append(&s->order, v);

				s->dec_vars++;
			}
		}

		// sorting
		for (int i = vect_size(&s->order) / 2 - 1; i >= 0; --i)
			order_percolate_down(s, i);
	}
}

//
//=============================================================================
void ergo_rescale_act_v(struct ergo *s)
{
	for (int i = 0; i < s->size; ++i)
		s->activity[i] *= 1e-100;

	s->var_inc *= 1e-100;
}

//
//=============================================================================
static inline void ergo_bump_var(struct ergo *s, int v)
{
	s->activity[v] += s->var_inc;

	if (s->activity[v] > 1e100)
		ergo_rescale_act_v(s);

	if (s->orderpos[v] != -1)
		order_percolate_up(s, s->orderpos[v]);
}

//
//=============================================================================
void ergo_bump_first(struct ergo *s, int count)
{
	for (int i = 0; i < count; ++i)
		ergo_bump_var(s, i);
}

//
//=============================================================================
void ergo_bump_some(struct ergo *s, struct vect *to_bump)
{
	for (size_t i = 0; i < vect_size(to_bump); ++i)
		ergo_bump_var(s, vect_memb(to_bump, int, i));
}

//
//=============================================================================
static inline void ergo_decay_act_v(struct ergo *s)
{
	s->var_inc *= s->var_decay;
}

//
//=============================================================================
static inline void ergo_rescale_act_c(struct ergo *s)
{
	aref *cls = clset_begin(&s->learnts);

	for (size_t i = 0; i < clset_size(&s->learnts); ++i) {
		struct clause *c = arena_deref(&s->arena, cls[i]);
		cl_set_acty(c, cl_get_acty(c) * 1e-20);
	}

	s->cla_inc *= 1e-20;
}

//
//=============================================================================
static inline void ergo_bump_cl(struct ergo *s, aref clr)
{
	struct clause *cl = arena_deref(&s->arena, clr);
	float a = cl_get_acty(cl) + s->cla_inc;

	cl_set_acty(cl, a);

	if (a > 1e20)
		ergo_rescale_act_c(s);
}

//
//=============================================================================
static inline void ergo_decay_act_c(struct ergo *s)
{
	s->cla_inc *= s->cla_decay;
}

//
//=============================================================================
static inline bool ergo_locked_cl(struct ergo *s, aref clr)
{
	struct clause *cl = arena_deref(&s->arena, clr);
	return s->reasons[lit_var(*cl_begin(cl))] == clr;
}

//
//=============================================================================
static inline void ergo_unlock_cl(struct ergo *s, aref clr)
{
	struct clause *cl = arena_deref(&s->arena, clr);
	s->reasons[lit_var(*cl_begin(cl))] = AREF_NIL;
}

//
//=============================================================================
static inline void ergo_stock_cl(struct ergo *s, aref clr)
{
	struct clause *cl   = arena_deref(&s->arena, clr);
	int           *lits = cl_begin(cl);
	aref           tclr = cl_size(cl) > 2 ? clr : (clr | AREF_TAG);

	assert(lits[0] >= 0);
	assert(lits[1] >= 0);

	assert(lits[0] < ergo_nvars(s) * 2);
	assert(lits[1] < ergo_nvars(s) * 2);

	assert(lit_neg(lits[0]) < ergo_nvars(s) * 2);
	assert(lit_neg(lits[1]) < ergo_nvars(s) * 2);

	struct watcher w1; ergo_watcher(&w1, tclr, lits[1]);
	struct watcher w2; ergo_watcher(&w2, tclr, lits[0]);

	vect_append(ergo_wlist(s, lit_neg(lits[0])), w1);
	vect_append(ergo_wlist(s, lit_neg(lits[1])), w2);
}

//
//=============================================================================
static inline void ergo_unwatch(struct ergo *s, int lit, aref tclr)
{
	struct vect     *wl  = ergo_wlist(s, lit);
	struct watcher  *w   = vect_begin(wl);
	struct watcher  *end = vect_end(wl);

	for (; w != end; ++w) {
		if (w->cl == tclr) {
			*w = *(struct watcher *)vect_back(wl);
			vect_shrink(wl, vect_size(wl) - 1);
			return;
		}
	}
}

//
//=============================================================================
static inline void ergo_unstock_cl(struct ergo *s, aref clr)
{
	struct clause *cl   = arena_deref(&s->arena, clr);
	int           *lits = cl_begin(cl);
	aref           tclr = cl_size(cl) > 2 ? clr : (clr | AREF_TAG);

	ergo_unwatch(s, lit_neg(lits[0]), tclr);
	ergo_unwatch(s, lit_neg(lits[1]), tclr);
}

//
//=============================================================================
aref ergo_new_cl(struct ergo *s, struct vect *c, bool learnt)
{
	assert(vect_size(c) > 1);

	aref cl = clset_add(learnt ? &s->learnts : &s->clauses, c, learnt);
	assert((cl & AREF_TAG) == 0);

	if (learnt) {
		s->stat.learnts++;
		s->stat.learnts_literals += vect_size(c);
	} else {
		s->stat.clauses++;
		s->stat.clauses_literals += vect_size(c);
	}

	if (s->ext)
		ext_cl_created(s, cl);

	ergo_stock_cl(s, cl);

	return cl;
}

//
//=============================================================================
void ergo_remove_cl(struct ergo *s, aref clr)
{
	struct clause *cl   = arena_deref(&s->arena, clr);
	int           *lits = cl_begin(cl);
	aref           tclr = cl_size(cl) > 2 ? clr : (clr | AREF_TAG);

	assert(lit_neg(lits[0]) < s->size * 2);
	assert(lit_neg(lits[1]) < s->size * 2);

	if (s->proof_trace)
		ergo_trace_cl(cl, true, s->proof_trace);

	if (ergo_locked_cl(s, clr))
		ergo_unlock_cl(s, clr);

	if (s->ext)
		ext_cl_removed(s, cl);

	ergo_smudge_wlist(s, lit_neg(lits[0]), tclr);
	ergo_smudge_wlist(s, lit_neg(lits[1]), tclr);
	cl_mark(cl);
}

//
//=============================================================================
static bool ergo_cl_satisfied(struct ergo *s, aref clr)
{
	assert(ergo_dlevel(s) == 0);

	struct clause *cl   = arena_deref(&s->arena, clr);
	int           *lits = cl_begin(cl);
	for (int i = 0; i < cl_size(cl); ++i) {
		if (s->assigns[lits[i]] == ltrue)
			return true;
	}

	return false;
}

//
//=============================================================================
void ergo_set_polar(struct ergo *s, struct vect *p, bool hard)
{
	// if the value of hard is true:
	// setting user defined polarities, which
	// won't be changed during the search process;
	// otherwise, setting polarities "softy":
	// they can be later modified by phase saving

	int *pol_arr = hard ? s->user_pol : s->polarity;

	for (int *l = vect_begin(p); l < (int *)vect_end(p); ++l)
		pol_arr[lit_var(*l)] = *l;
}

// replaces the entire variable ordering with a user-given one: the variables
// in 'vars' take the activities in 'acts', every other variable's activity
// drops to 0.0, and the var_inc bump goes back to its initial value so that
// whatever the search adds from here on is on the same scale as what was
// just set;
//=============================================================================
void ergo_set_acts(struct ergo *s, struct vect *vars, struct vect *acts)
{
	assert(vect_size(vars) == vect_size(acts));
	assert(ergo_dlevel(s) == 0); // the heap only holds unassigned variables

	int    *v = vect_begin(vars);
	double *a = vect_begin(acts);

	for (int i = 0; i < s->size; ++i)
		s->activity[i] = 0;

	for (size_t i = 0; i < vect_size(vars); ++i) {
		assert(v[i] < s->size && a[i] <= 1e100);
		s->activity[v[i]] = a[i];
	}

	s->var_inc = 1; // 'var_decay' is the user's own tuning and stays put
	order_rebuild(s);
}

//
//=============================================================================
void ergo_set_dvar(struct ergo *s, int var)
{
	if (s->dec_var[var] == false) {
		s->dec_vars++;
		s->dec_var[var] = true;
	}
}

//
//=============================================================================
void ergo_set_dvars(struct ergo *s, struct vect *dec_vars)
{
	assert(vect_size(dec_vars) != 0);

	int *vars = vect_begin(dec_vars);
	for (size_t i = 0; i < vect_size(dec_vars); ++i)
		ergo_set_dvar(s, vars[i]);

	order_rebuild(s);
}

//
//=============================================================================
void ergo_set_dvars_all(struct ergo *s)
{
	for (int var = 0; var < ergo_nvars(s); ++var)
		ergo_set_dvar(s, var);

	order_rebuild(s);
}

// 'perm_diff' is tracked separated from 'cap' due to warm start's dummy levels
//=============================================================================
static inline void ergo_grow_permdiff(struct ergo *s, int need)
{
	if (need <= s->cap_levels)
		return;

	int old_cap = s->cap_levels;
	while (s->cap_levels < need)
		s->cap_levels = s->cap_levels * 2 + 1;

	s->perm_diff = realloc(s->perm_diff, s->cap_levels * sizeof(unsigned));
	for (int i = old_cap; i < s->cap_levels; ++i)
		s->perm_diff[i] = 0;
}

//
//=============================================================================
void ergo_init_var(struct ergo *s, int var)
{
	s->activity [var] = 0;
	s->polarity [var] = lit_neg(lit_of(var));
	s->user_pol [var] = lit_undef;
	s->dec_var  [var] = false;
	s->observed [var] = false;

	s->assigns  [var * 2    ] = lundef;
	s->assigns  [var * 2 + 1] = lundef;

	s->reasons  [var] = AREF_NIL;
	s->levels   [var] = 0;
	s->tags     [var] = 0;

	s->orderpos [var] = -1;

	ext_init_var(s, var);
}

//
//=============================================================================
void ergo_setnvars(struct ergo *s, int n)
{
	if (s->cap < n) {
		while (s->cap < n)
			s->cap = s->cap * 2 + 1;

		s->activity   = realloc(s->activity,   s->cap * sizeof(double));
		s->polarity   = realloc(s->polarity,   s->cap * sizeof(int));
		s->user_pol   = realloc(s->user_pol,   s->cap * sizeof(int));
		s->dec_var    = realloc(s->dec_var,    s->cap * sizeof(bool));
		s->observed   = realloc(s->observed,   s->cap * sizeof(bool));
		s->assigns    = realloc(s->assigns,    s->cap * sizeof(lbool) * 2);
		s->levels     = realloc(s->levels,     s->cap * sizeof(int));
		s->orderpos   = realloc(s->orderpos,   s->cap * sizeof(int));
		s->reasons    = realloc(s->reasons,    s->cap * sizeof(aref));
		s->tags       = realloc(s->tags,       s->cap * sizeof(char));
		s->trail      = realloc(s->trail,      s->cap * sizeof(int));
		s->wlists     = realloc(s->wlists,     s->cap * sizeof(struct vect) * 2);
		s->wdirt_c    = realloc(s->wdirt_c,    s->cap * sizeof(char) * 2);

		// reallocate 'perm_diff' if required
		ergo_grow_permdiff(s, s->cap);

		// reallocate extension-related stuff
		ext_grow_vars(s);
	}

	for (int var = s->size; var < n; ++var) {
		// creating watchers
		vect_init(&s->wlists[2 * var],     sizeof(struct watcher));
		vect_init(&s->wlists[2 * var + 1], sizeof(struct watcher));

		s->wdirt_c  [var * 2    ] = 0;
		s->wdirt_c  [var * 2 + 1] = 0;

		ergo_init_var(s, var);
	}

	s->size = n > s->size ? n : s->size;
}

//
//=============================================================================
static inline unsigned ergo_compute_lbd(struct ergo *s, struct vect *cl)
{
	unsigned lbd = 0;
	s->magic_counter++;

	int *lits = vect_begin(cl);
	for (size_t i = 0; i < vect_size(cl); ++i) {
		int l = s->levels[lit_var(lits[i])];

		if (s->perm_diff[l] != s->magic_counter) {
			s->perm_diff[l] = s->magic_counter;
			lbd++;
		}
	}

	return lbd;
}

// moves a learnt clause into the permanent pool (chanseok)
//=============================================================================
static inline void ergo_promote_cl(struct ergo *s, aref cl)
{
	struct clause *c = arena_deref(&s->arena, cl);
	cl_setlearnt(c, false);

	clset_detach(&s->learnts, cl);
	vect_append(&s->clauses.ptrs, cl);
	cl_setidx(c, (unsigned)(vect_size(&s->clauses.ptrs) - 1));

	s->stat.learnts--;
	s->stat.learnts_literals -= cl_size(c);
	s->stat.clauses++;
	s->stat.clauses_literals += cl_size(c);
}

//
//=============================================================================
static inline void ergo_relbd_cl(struct ergo *s, aref clr)
{
	struct clause *cl = arena_deref(&s->arena, clr);
	unsigned lbd_new = 0;
	s->magic_counter++;

	for (int i = 0; i < cl_size(cl); ++i) {
		int l = s->levels[lit_var(cl_at(cl, i))];

		if (s->perm_diff[l] != s->magic_counter) {
			s->perm_diff[l] = s->magic_counter;
			lbd_new++;
		}
	}

	if (lbd_new + 1 < cl_lbd(cl)) {
		if (cl_lbd(cl) <= s->frozencl_lbd_lb)
			cl_setneeded(cl, true);

		if (s->permanent_mode && lbd_new <= s->perm_lbd_lb)
			ergo_promote_cl(s, clr);
		else
			cl_relbd(cl, lbd_new);
	}
}

// IPASIR-UP: sentinels for s->reasons[v] when v was forced by cb_propagate();
// the real reason clause is built lazily, only if conflict analysis ever
// resolves through it
#define AREF_EXT_TRUE  ((aref)(AREF_NIL - 1))
#define AREF_EXT_FALSE ((aref)(AREF_NIL - 2))

//
//=============================================================================
static inline bool ergo_reason_is_lazy(aref r)
{
	return r == AREF_EXT_TRUE || r == AREF_EXT_FALSE;
}

// converts to/from the plain DIMACS-style int
//=============================================================================
int ergo_lit_to_dimacs(int l)
{
	return lit_sign(l) ? -(lit_var(l) + 1) : (lit_var(l) + 1);
}

//
//=============================================================================
int ergo_dimacs_to_lit(int d)
{
	return d > 0 ? lit_of(d - 1) : lit_neg(lit_of(-d - 1));
}

// asks the propagator to justify literal 'l', which was forced earlier by
// cb_propagate(), and materializes it as a real clause; called by
// ergo_reason() and ergo_propagate_ext(); swaps 'l' to the front like
// every other reason clause;
//=============================================================================
static aref ergo_build_reason_clause(struct ergo *s, int l)
{
	int dl = ergo_lit_to_dimacs(l);

	struct vect lits = vect_new(int);
	int d;
	while ((d = s->propagator->cb_add_reason_clause_lit(s->propagator->ctx, dl)))
		vect_append(&lits, ergo_dimacs_to_lit(d));

	// a unit-size reason is legal under IPASIR-UP,
	// and we need to treat it properly in ergo_search()
	if (vect_size(&lits) == 1) {
		assert(*(int *)vect_begin(&lits) == l); // propagator must
							 // include the
							 // propagated literal
		vect_destroy(&lits);
		return AREF_NIL;
	}

	assert(vect_size(&lits) > 1); // at this point, external clauses
				      // must be all non-unit
	int *ls = vect_begin(&lits);
	for (size_t i = 0; i < vect_size(&lits); ++i)
		if (ls[i] == l) {
			ls[i] = ls[0];
			ls[0] = l;
			break;
		}
	assert(ls[0] == l); // propagator must include the propagated literal

#ifdef LOGGING
	ergo_log_begin(s);
	fprintf(stderr, "extreason");
	for (size_t i = 0; i < vect_size(&lits); ++i)
		fprintf(stderr, " %d", ergo_lit_to_dimacs(ls[i]));
	fprintf(stderr, " 0\n");
#endif

	if (s->ext) {
#ifdef LOGGING
		size_t orig_size = vect_size(&lits);
#endif
		ergo_ext_subst(s, &lits, 1); // tail only -- ls[0] must stay 'l'

#ifdef LOGGING
		if (vect_size(&lits) != orig_size) {
			ergo_log_begin(s);
			fprintf(stderr, "extreason (rewritten)");
			ls = vect_begin(&lits);
			for (size_t i = 0; i < vect_size(&lits); ++i)
				fprintf(stderr, " %d", ergo_lit_to_dimacs(ls[i]));
			fprintf(stderr, " 0\n");
		}
#endif
	}

	aref r = ergo_new_cl(s, &lits, true);
	vect_destroy(&lits);
	return r;
}

// materializes the reason clause for a variable; required because of
// IPASIR-UP, as external propagation does not provide a reason clause
// immediately;
//=============================================================================
static aref ergo_reason(struct ergo *s, int v)
{
	aref r = s->reasons[v];

	if (ergo_reason_is_lazy(r)) {
		int l = (r == AREF_EXT_TRUE) ? lit_of(v) : lit_neg(lit_of(v));
		r = ergo_build_reason_clause(s, l);

		s->reasons[v] = r;
		s->ext_reason[v] = true; // mark that this came from the propagator

		// empty reason => mark for future assignment at level 0
		if (r == AREF_NIL)
			vect_append(&s->external_units, l);
	}

	// mined on every consultation since the same reason may explain
	// different external propagations
	if (r != AREF_NIL && s->ext_reason[v] && s->ext &&
			s->stat.conflicts >= (uint64_t)s->ext_warmup) {
		struct clause *c = arena_deref(&s->arena, r);
		ergo_ext_mine_cl(s, cl_begin(c), (size_t)cl_size(c), 0);
	}

	return r;
}

//
//=============================================================================
static inline bool ergo_lit_redundant(struct ergo *s, int p)
{
	enum { tag_undef = 0, tag_source = 1, tag_rm = 2, tag_failed = 3 };
	assert(s->tags[lit_var(p)] == tag_undef || s->tags[lit_var(p)] == tag_source);
	assert(s->reasons[lit_var(p)] != AREF_NIL);

	vect_clear(&s->stack_i);
	vect_clear(&s->stack_p);

	struct clause *c;
	aref cr = ergo_reason(s, lit_var(p));
	if (cr == AREF_NIL)
		goto finish_p; // a lazily-discovered permanent fact: nothing to
		               // explore, trivially "removable" like any other
		               // level-0 literal already is
	c = arena_deref(&s->arena, cr);

	for (int i = 1; ; i++) {
		if (i < cl_size(c)) {
			// checking 'p'-parents 'l'
			int l = cl_at(c, i);
			int v = lit_var(l);

			// variable at level 0 or previously removable
			if (s->levels[v] == 0 || s->tags[v] == tag_source || s->tags[v] == tag_rm)
				continue;

			// check variable can not be removed for some local reason
			if (s->reasons[v] == AREF_NIL || s->tags[v] == tag_failed) {
				vect_append(&s->stack_i, 0);
				vect_append(&s->stack_p, p);

				for (int j = 0; j < vect_size(&s->stack_p); ++j) {
					int q = vect_memb(&s->stack_p, int, j);
					int w = lit_var(q);
					if (s->tags[w] == tag_undef) {
						s->tags[w] = tag_failed;
						vect_append(&s->tagged, q);
					}
				}

				return false;
			}

			// recursively check 'l'
			vect_append(&s->stack_i, i);
			vect_append(&s->stack_p, p);
			i = 0;
			p = l;
			cr = ergo_reason(s, lit_var(p));
			if (cr == AREF_NIL)
				goto finish_p;
			c = arena_deref(&s->arena, cr);
		}
		else {
finish_p:
			// finished with current element 'p' and reason 'c'
			int v = lit_var(p);
			if (s->tags[v] == tag_undef) {
				s->tags[v] = tag_rm;
				vect_append(&s->tagged, p);
			}

			// terminate with success if stack is empty
			if (vect_empty(&s->stack_i))
				break;

			// continue with top element on stack
			vect_pop(&s->stack_i, &i);
			vect_pop(&s->stack_p, &p);
			cr = ergo_reason(s, lit_var(p));
			if (cr == AREF_NIL)
				goto finish_p;
			c = arena_deref(&s->arena, cr);
		}
	}

	return true;
}

//
//=============================================================================
static void ergo_minimize_binres(struct ergo *s, struct vect *learnt)
{
	if (ergo_compute_lbd(s, learnt) > s->ccmin_lbd_lb)
		return;

	int *lits = vect_begin(learnt);

	s->magic_counter++;
	for (size_t i = 1; i < vect_size(learnt); ++i)
		s->perm_diff[lit_var(lits[i])] = s->magic_counter;

	size_t nb = 0;
	struct watcher *w   = vect_begin(ergo_wlist(s, lit_neg(lits[0])));
	struct watcher *end = vect_end  (ergo_wlist(s, lit_neg(lits[0])));

	for (; w != end; ++w) {
		if (!(w->cl & AREF_TAG))
			continue;

		int imp = w->blocker;
		if (s->perm_diff[lit_var(imp)] == s->magic_counter && s->assigns[imp] == ltrue) {
			++nb;
			s->perm_diff[lit_var(imp)] = s->magic_counter - 1;
		}
	}

	if (nb == 0)
		return;

	size_t l = vect_size(learnt) - 1;
	for (size_t i = 1; i < vect_size(learnt) - nb; ++i) {
		if (s->perm_diff[lit_var(lits[i])] != s->magic_counter) {
			int tmp = lits[l]; lits[l] = lits[i]; lits[i] = tmp;
			--l; --i;
		}
	}

	vect_shrink(learnt, vect_size(learnt) - nb);
}

//
//=============================================================================
static void ergo_analyze(
	struct ergo *s,
	aref confl,
	struct vect *learnt,
	int *btlevel,
	unsigned *lbd
)
{
	int cnt = 0;
	int p   = lit_undef;
	int ind = s->qtail - 1;

	vect_append(learnt, lit_undef);

	do {
		// checking if the conflict clause is a unit-size reason of an
		// externally derived literal; if it is, there is nothing to
		// analyze;
		if (confl != AREF_NIL) {
			struct clause *cl = arena_deref(&s->arena, confl);

#ifdef LOGGING
			ergo_log_begin(s);
			fprintf(stderr, "resolve against ");
			cl_dump(cl, FMT_BF, stderr);
#endif

			if (cl_learnt(cl)) {
				ergo_bump_cl(s, confl);

				if (cl_lbd(cl) > 2)
					// trying to improve the clause's LBD
					ergo_relbd_cl(s, confl);
			}

			int *lits = cl_begin(cl);
			for (int j = (p == lit_undef ? 0 : 1); j < cl_size(cl); ++j) {
				int q = lits[j];
				assert(lit_var(q) >= 0 && lit_var(q) < s->size);

				if (s->tags[lit_var(q)] == 0 && s->levels[lit_var(q)] > 0) {
					ergo_bump_var(s, lit_var(q));
					s->tags[lit_var(q)] = 1;

					if (s->levels[lit_var(q)] == ergo_dlevel(s)) {
						++cnt;

						aref rq = s->reasons[lit_var(q)];
						if (s->glucose_bump && rq != AREF_NIL &&
								(ergo_reason_is_lazy(rq) || cl_learnt(arena_deref(&s->arena, rq))))
							vect_append(&s->last_level, q);
					}
					else
						vect_append(learnt, q);
				}
			}
		}

		while (s->tags[lit_var(s->trail[ind--])] == 0)
			;

		p = s->trail[ind + 1];
		confl = ergo_reason(s, lit_var(p));
		s->tags[lit_var(p)] = 0;
		cnt--;

		LOG(s, "pivot: var %d (level %d)%s", lit_var(p) + 1, s->levels[lit_var(p)],
				confl == AREF_NIL ? "  <- decision, stop" : "");

	} while (cnt > 0);

	// vect_memb(learnt, int, 0) = lit_neg(p); // not compilable by clang; use instead:
	*(int *)vect_begin(learnt) = lit_neg(p);
	vect_copy_lazy(learnt, &s->tagged);

	// simplify conflict clause
	size_t i, j;
	int *lits = vect_begin(learnt);
	switch (s->ccmin_mode) {
	case 2:
		for (i = j = 1; i < vect_size(learnt); ++i) {
			int var = lit_var(vect_memb(learnt, int, i));
			aref r = s->reasons[var];

			if (r == AREF_NIL || !ergo_lit_redundant(s, vect_memb(learnt, int, i)))
				lits[j++] = lits[i];
		}
		break;
	case 1:
		for (i = j = 1; i < vect_size(learnt); ++i) {
			int var = lit_var(vect_memb(learnt, int, i));
			aref r = s->reasons[var];

			if (r == AREF_NIL)
				lits[j++] = lits[i];
			else {
				// AREF_NIL reasons for external literals just
				// make them disappear
				aref rr = ergo_reason(s, var);
				if (rr == AREF_NIL)
					lits[j++] = lits[i];
				else {
					struct clause *rc = arena_deref(&s->arena, rr);
					for (int k = 1; k < cl_size(rc); ++k) {
						int v = lit_var(cl_at(rc, k));
						if (s->tags[v] == 0 && s->levels[v] > 0) {
							lits[j++] = lits[i];
							break;
						}
					}
				}
			}
		}
		break;
	default: // 0
		i = j = vect_size(learnt);
	}

	// update size of learnt + statistics
	s->stat.max_literals += vect_size(learnt);
	s->stat.tot_literals += j;
	vect_shrink(learnt, j);

	if (vect_size(learnt) <= (size_t)s->ccmin_sz_lb)
		ergo_minimize_binres(s, learnt);

	// compute correct backtrack level
	if (vect_size(learnt) == 1)
		*btlevel = 0;
	else {
		i = 1;
		// find the first literal assigned at the next-highest level
		for (j = 2; j < vect_size(learnt); ++j) {
			if (s->levels[lit_var(lits[j])] > s->levels[lit_var(lits[i])])
				i = j;
		}

		// swap-in this literal at index 1
		p        = lits[i];
		lits[i]  = lits[1];
		lits[1]  = p;
		*btlevel = s->levels[lit_var(p)];
	}

	// computing LBD
	*lbd = ergo_compute_lbd(s, learnt);

#ifdef LOGGING
	ergo_log_begin(s);
	fprintf(stderr, "learnt: ");
	dbg_print_vect(learnt, FMT_BF, stderr);
	LOG(s, "backtrack to level %d, lbd %u", *btlevel, *lbd);
#endif

	// bumping variables implied at the current level by "good" clauses
	if (s->glucose_bump && vect_size(&s->last_level) > 0) {
		int *last_l = vect_begin(&s->last_level);
		for (int i = 0; i < vect_size(&s->last_level); ++i) {
			// a still-lazy external reason's LBD is unknown until
			// materialized, and a resolved-to-unit one has no LBD
			// at all; treat either as "not good enough to bump"
			aref reason = s->reasons[lit_var(last_l[i])];
			if (reason != AREF_NIL && !ergo_reason_is_lazy(reason) &&
					cl_lbd(arena_deref(&s->arena, reason)) < *lbd)
				ergo_bump_var(s, lit_var(last_l[i]));
		}

		vect_clear(&s->last_level);
	}

	// clear tags
	int *tagged = vect_begin(&s->tagged);
	for (int i = 0; i < vect_size(&s->tagged); ++i)
		s->tags[lit_var(tagged[i])] = 0;
	vect_shrink(&s->tagged, 0);
}

//
//=============================================================================
void ergo_analyze_final(struct ergo *s, int l)
{
	vect_clear(&s->conflict);
	vect_append(&s->conflict, l);

	if (ergo_dlevel(s) == 0)
		return;

	int *to_check = calloc(ergo_nvars(s), sizeof(int));
	to_check[lit_var(l)] = 1;

	int bound = vect_memb(&s->trail_lim, int, 0);
	for (int i = s->qtail - 1; i >= bound; --i) {
		int var = lit_var(s->trail[i]);

		if (to_check[var]) {
			// resolves any still-lazy reason too (a no-op for an
			// ordinary decision, whose reason is already AREF_NIL)
			aref reason = ergo_reason(s, var);
			if (reason == AREF_NIL) {
				assert(s->levels[var] > 0);

				// an externally-asserted unconditional fact
				// that isn't an assumption and cannot be
				// blamed on one;
				if (!s->ext_reason[var])
					vect_append(&s->conflict, lit_neg(s->trail[i]));
			}
			else {
				struct clause *rc = arena_deref(&s->arena, reason);
				for (int j = 1; j < cl_size(rc); ++j) {
					int v = lit_var(rc->lits[j]);
					if (s->levels[v] > 0)
						to_check[v] = 1;
				}
			}
			to_check[var] = 0;
		}
	}

	free(to_check);
}

//
//=============================================================================
bool ergo_enqueue(struct ergo *s, int l, aref from)
{
	int   v   = lit_var(l);
	lbool val = s->assigns[v << 1];

	if (val != lundef)
		return s->assigns[l] == ltrue;
	else {
		// new fact -- store it.
		s->assigns[l]     = ltrue;
		s->assigns[l ^ 1] = lfalse;

		s->reasons[v] = from;
		s->levels [v] = ergo_dlevel(s);
		s->trail[s->qtail++] = l;

#ifdef LOGGING
		if (from == AREF_NIL)
			LOG(s, "decide %d level %d", ergo_lit_to_dimacs(l), ergo_dlevel(s));
		else if (ergo_reason_is_lazy(from))
			LOG(s, "propagate %d level %d reason <external, not yet materialized>",
					ergo_lit_to_dimacs(l), ergo_dlevel(s));
		else {
			ergo_log_begin(s);
			fprintf(stderr, "propagate %d level %d reason ",
					ergo_lit_to_dimacs(l), ergo_dlevel(s));
			cl_dump(arena_deref(&s->arena, from), FMT_BF, stderr);
		}
#endif

		return true;
	}
}

//
//=============================================================================
static inline void ergo_new_dlevel(struct ergo *s)
{
	vect_append(&s->trail_lim, s->qtail);
	ergo_grow_permdiff(s, ergo_dlevel(s) + 1);

	LOG(s, "new level %d", ergo_dlevel(s));

	if (s->propagator && !s->propagator->is_lazy && !s->probing) {
		s->propagator->notify_new_decision_level(s->propagator->ctx);
		LOG(s, "notify_new_decision_level %d", ergo_dlevel(s));
	}
}

// batches every newly-made assignment into one notify_assignment() call,
// filtered to observed variables only;
//=============================================================================
static void ergo_notify_assignments(struct ergo *s)
{
	if (!s->propagator || s->propagator->is_lazy || s->notified >= s->qtail)
		return;

	vect_clear(&s->notify_buf);

	while (s->notified < s->qtail) {
		int l = s->trail[s->notified++];
		if (s->observed[lit_var(l)])
			vect_append(&s->notify_buf, ergo_lit_to_dimacs(l));
	}

	int n = (int)vect_size(&s->notify_buf);
	if (n) {
		s->propagator->notify_assignment(s->propagator->ctx, vect_begin(&s->notify_buf), n);
		LOG(s, "notify_assignment %d lit(s)", n);
	}
}

// notify the propagator (if any) about backtracing or new assignments
//=============================================================================
static void ergo_notify_pending(struct ergo *s)
{
	if (!s->propagator)
		return;

	if (s->notify_backtrack_pending) {
		if (!s->propagator->is_lazy) {
			s->propagator->notify_backtrack(s->propagator->ctx, ergo_dlevel(s));
			LOG(s, "notify_backtrack %d", ergo_dlevel(s));
		}
		s->notify_backtrack_pending = false;
	}

	ergo_notify_assignments(s);
}

// asks the connected propagator to veto or accept the current complete
// assignment (unobserved variables are filtered out)
//=============================================================================
static bool ergo_check_found_model(struct ergo *s)
{
	int *buf = malloc((size_t)s->size * sizeof(int));
	int  n   = 0;

	for (int v = 0; v < s->size; ++v) {
		if (!s->observed[v])
			continue;

		lbool val = s->assigns[lit_of(v)];
		if (val != lundef)
			buf[n++] = (val == ltrue) ? (v + 1) : -(v + 1);
	}

	bool ok = s->propagator->cb_check_found_model(s->propagator->ctx, buf, n);
	LOG(s, "cb_check_found_model(%d lit(s)) -> %d", n, (int)ok);
	free(buf);
	return ok;
}

//
//=============================================================================
static inline lbool ergo_assume(struct ergo *s)
{
	// wrapped in a loop: cb_decide() may call ergo_force_backtrack() and
	// unwind an assumption's own decision level out from under us (see
	// below) -- restarting re-applies it instead of letting whatever the
	// propagator suggested silently override it.
	for (;;) {
		int next = lit_undef;

		while (ergo_dlevel(s) < vect_size(&s->assumps)) {
			// perform user provided assumption
			int *l = vect_at(&s->assumps, ergo_dlevel(s));

			if (s->assigns[*l] == ltrue)
				// dummy decision level
				ergo_new_dlevel(s);
			else if (s->assigns[*l] == lfalse) {
				LOG(s, "assumption %d falsified", ergo_lit_to_dimacs(*l));
				ergo_analyze_final(s, lit_neg(*l));
				return lfalse;
			}
			else {
				next = *l;
				break;
			}
		}

		// batch-report a recently made backtracking or anything newly
		// assigned in ergo_simplify() / ergo_vivify()
		ergo_notify_pending(s);

		if (next == lit_undef) {
			// new variable decision
			s->stat.decisions++;

			bool from_propagator = false;
			if (s->propagator && !s->propagator->is_lazy) {
				int d = s->propagator->cb_decide(s->propagator->ctx);
				LOG(s, "cb_decide -> %d", d);

				// cb_decide() may have just called
				// ergo_force_backtrack(); flush that
				// notification now, before anything else gets
				// reported
				ergo_notify_pending(s);

				if (ergo_dlevel(s) < vect_size(&s->assumps))
					// force-backtracked below assumptions
					// levels; all assumptions need
					// restoring before 'd'
					continue;

				if (d) {
					int l = ergo_dimacs_to_lit(d);
					assert(lit_var(l) < s->size && s->observed[lit_var(l)]);
					if (s->assigns[l] == lundef) {
						next           = l;
						from_propagator = true;
					}
				}
			}

			if (!from_propagator) {
				next = order_select(s);

				if (next != var_undef) {
					if (s->user_pol[next] != lit_undef)
						next = s->user_pol[next];
					else
						next = s->polarity[next];
				}
				else {
					// model found - unless the propagator objects,
					// in which case it now has (or will next round
					// have, via cb_has_external_clause()) a
					// refuting clause ready
					if (s->propagator && !ergo_check_found_model(s))
						return lundef;
					return ltrue;
				}
			}
		}

		assert(s->qtail == s->qhead);
		assert(s->assigns[lit_abs(next)] == lundef);

		// increase decision level and enqueue 'next'
		ergo_new_dlevel(s);
		ergo_enqueue(s, next, AREF_NIL);

		return lundef;
	}
}

//
//=============================================================================
static inline void ergo_cancel_until(struct ergo *s, int level)
{
	if (ergo_dlevel(s) > level) {
		int bound = vect_memb(&s->trail_lim, int, level);
		int bound_curr = *(int *)vect_back(&s->trail_lim);

		LOG(s, "backtrack from level %d to %d, undoing %d",
				ergo_dlevel(s), level, s->qtail - bound);

		for (int i = s->qtail - 1; i >= bound; --i) {
			int v = lit_var(s->trail[i]);

			s->reasons   [v] = AREF_NIL;
			s->ext_reason[v] = false; // keep in sync with 'reasons[v]'
			s->assigns[s->trail[i]]     = lundef;
			s->assigns[s->trail[i] ^ 1] = lundef;

			if (s->ext)
				ext_var_unassigned(s, v);

			if (s->phase_saving > 1 || (s->phase_saving == 1 && i > bound_curr))
				s->polarity[v] = s->trail[i];

			if (s->dec_var[v])
				order_unassign(s, v);
		}

		s->qhead = s->qtail = bound;
		vect_shrink(&s->trail_lim, level);

		// IPASIR-UP: defer notify_backtrack() to the top of
		// ergo_assume() rather than call it synchronously here;
		// otherwise, it would be too expensive
		if (s->propagator) {
			// internal probing undoes only what it opened itself,
			// so there is nothing to report; the watermark still
			// has to follow the trail back down
			if (!s->probing)
				s->notify_backtrack_pending = true;
			if (s->notified > s->qtail)
				s->notified = s->qtail;
		}
	}
}

//
//=============================================================================
void ergo_set_start(struct ergo *s, bool warm)
{
	s->warm_start = warm;
	ergo_cancel_until(s, 0);
}

//
//=============================================================================
void ergo_set_cbudget(struct ergo *s, int64_t x)
{
	s->conflict_budget = s->stat.conflicts + x;
}

//
//=============================================================================
void ergo_set_pbudget(struct ergo *s, int64_t x)
{
	s->propagation_budget = s->stat.propagations + x;
}

//
//=============================================================================
void ergo_budget_off(struct ergo *s)
{
	s->conflict_budget = s->propagation_budget = -1;
}

//
//=============================================================================
void ergo_interrupt(struct ergo *s)
{
	s->asynch_interrupt = true;
}

//
//=============================================================================
void ergo_clear_interrupt(struct ergo *s)
{
	s->asynch_interrupt = false;
}

//
//=============================================================================
static inline bool ergo_within_budget(struct ergo *s)
{
	return !s->asynch_interrupt &&
		(s->conflict_budget    < 0 || s->stat.conflicts    < (uint64_t)s->conflict_budget) &&
		(s->propagation_budget < 0 || s->stat.propagations < (uint64_t)s->propagation_budget);
}

// under warm start, a trail decision may belong to a *previous* assumption
// list; so we need to find the longest agreeing prefix with the new one
// and backtrack past the first disagreement (no-op at dlevel 0);
//=============================================================================
static inline void ergo_reconcile_assumps(struct ergo *s, struct vect *old_assumps)
{
	int old_n = (int)vect_size(old_assumps);
	int new_n = (int)vect_size(&s->assumps);
	int bound = old_n < new_n ? old_n : new_n;

	int keep = 0;
	while (keep < bound && vect_memb(old_assumps, int, keep) == vect_memb(&s->assumps, int, keep))
		++keep;

	// a mismatch within the overlap forces a backtrack to it; so does the
	// new list being longer, even with full agreement, since dlevel may
	// already sit beyond old_n
	if (keep < bound || new_n > old_n)
		ergo_cancel_until(s, keep);
}

//
//=============================================================================
static void ergo_learn(struct ergo *s, struct vect *c, unsigned lbd)
{
	assert(vect_size(c) > 0);

	// clauses good enough to keep forever are allocated straight into
	// 's->clauses' (non-learnt layout, no activity word) instead of
	// 's->learnts' -- see 'ergo_promote_cl()' for why that alone suffices
	bool perm = s->permanent_mode && vect_size(c) > 1 && lbd <= s->perm_lbd_lb;

	aref cl = (vect_size(c) > 1) ? ergo_new_cl(s, c, !perm) : AREF_NIL;
	ergo_enqueue(s, vect_memb(c, int, 0), cl);

	if (cl != AREF_NIL) {
		cl_relbd(arena_deref(&s->arena, cl), lbd);

		if (!perm)
			ergo_bump_cl(s, cl);
	}
}

//
//=============================================================================
aref ergo_propagate(struct ergo *s)
{
	aref confl = AREF_NIL;
	int num_props = 0;

	while (s->qhead < s->qtail) {
		int p = s->trail[s->qhead++];

		struct vect    *ws = ergo_wlist(s, p);
		struct watcher *i, *j, *end;

		num_props++;

		for (i = j = vect_begin(ws), end = vect_end(ws); i != end; ) {
			aref cl      = i->cl;
			int  blocker = i->blocker;

			if (s->assigns[blocker] == ltrue) {
				*j++ = *i++;
				continue;
			}

			if (cl & AREF_TAG) {
				// binary clause
				*j++ = *i++;
				cl = AREF_UNTAG(cl);
				if (!ergo_enqueue(s, blocker, cl)) {
					s->qhead = s->qtail;
					confl = cl;

					// copy the remaining watches
					while (i < end)
						*j++ = *i++;
				}
				else {
					struct clause *c = arena_deref(&s->arena, cl);
					int  false_lit = lit_neg(p);
					int *lits      = cl_begin(c);

					// make sure the false literal is lits[1]
					if (lits[0] == false_lit) {
						lits[0] = lits[1];
						lits[1] = false_lit;
					}
					assert(lits[1] == false_lit);
				}
			}
			else {
				struct clause *c = arena_deref(&s->arena, cl);
				int  false_lit    = lit_neg(p);
				int *lits         = cl_begin(c);

				// make sure the false literal is lits[1]
				if (lits[0] == false_lit) {
					lits[0] = lits[1];
					lits[1] = false_lit;
				}
				assert(lits[1] == false_lit);
				i++;

				// if 0th watch is true, then clause is already satisfied
				int first = lits[0];
				struct watcher w; ergo_watcher(&w, cl, first);
				if (first != blocker && s->assigns[first] == ltrue) {
					*j++ = w;
					continue;
				}

				// look for new watch
				for (int k = 2; k < cl_size(c); ++k) {
					if (s->assigns[lits[k]] != lfalse) {
						lits[1] = lits[k];
						lits[k] = false_lit;

						vect_append(ergo_wlist(s, lit_neg(lits[1])), w);
						goto next;
					}
				}

				// did not find watch -- clause is unit under assignment
				*j++ = w;
				if (!ergo_enqueue(s, first, cl)) {
					confl    = cl;
					s->qhead = s->qtail;

					// copy the remaining watches
					while (i < end)
						*j++ = *i++;
				}
			}

			next:;
		}

		vect_shrink(ws, vect_size(ws) - (i - j));
	}

	s->stat.propagations += num_props;
	s->simpdb_props      -= num_props;

	return confl;
}

// forward declaration: ergo_add_cl_warm() is defined much later
static bool ergo_add_cl_warm(struct ergo *s, struct clause *cl);

// wraps ergo_propagate() with IPASIR-UP's cb_propagate()/
// cb_has_external_clause() rounds. Only ergo_search()'s main loop uses
// this; every other ergo_propagate() caller stays propagator-unaware.
//=============================================================================
static aref ergo_propagate_ext(struct ergo *s)
{
	aref confl;

	for (;;) {
		confl = ergo_propagate(s);
		if (confl != AREF_NIL || !s->propagator)
			return confl;

		ergo_notify_pending(s);

		int d;

		// is_lazy skips cb_propagate() but not
		// cb_has_external_clause(); it stays the only channel a lazy
		// propagator can influence the search
		if (!s->propagator->is_lazy) {
			d = s->propagator->cb_propagate(s->propagator->ctx);
			LOG(s, "cb_propagate -> %d", d);
			if (d) {
				int   l = ergo_dimacs_to_lit(d);
				lbool v = s->assigns[l];
				assert(lit_var(l) < s->size && s->observed[lit_var(l)]);

				if (v == lundef) {
					ergo_enqueue(s, l, lit_sign(l) ? AREF_EXT_FALSE : AREF_EXT_TRUE);
					continue; // re-run native propagation on top of this
				}
				if (v == lfalse) {
					// already false under the current trail; a
					// conflict, unless the reason itself turns
					// out to be unit (AREF_NIL, see
					// ergo_build_reason_clause())
					aref r = ergo_build_reason_clause(s, l);
					if (r == AREF_NIL) {
						vect_append(&s->external_units, l);
						return AREF_NIL;
					}

					// also, external conflicts need not
					// involve the current decision level
					struct clause *c = arena_deref(&s->arena, r);
					int conflict_level = 0;

					for (int i = 0; i < cl_size(c); ++i) {
						int q = cl_at(c, i);
						assert(s->assigns[q] == lfalse);

						int level = s->levels[lit_var(q)];
						if (level > conflict_level)
							conflict_level = level;
					}

					if (conflict_level < ergo_dlevel(s)) {
						ergo_cancel_until(s, conflict_level);
						ergo_notify_pending(s);
					}

					return r;
				}
				continue; // already true -- ignore, ask again next round
			}
		}

		bool forgettable;
		if (!s->propagator->cb_has_external_clause(s->propagator->ctx, &forgettable)) {
			LOG(s, "cb_has_external_clause -> false");
			return AREF_NIL; // both hooks exhausted, no conflict
		}
		LOG(s, "cb_has_external_clause -> true, forgettable=%d", (int)forgettable);

		struct vect lits = vect_new(int);
		while ((d = s->propagator->cb_add_external_clause_lit(s->propagator->ctx)))
			vect_append(&lits, ergo_dimacs_to_lit(d));

#ifdef LOGGING
		ergo_log_begin(s);
		fprintf(stderr, "extclause");
		int *el = vect_begin(&lits);
		for (size_t i = 0; i < vect_size(&lits); ++i)
			fprintf(stderr, " %d", ergo_lit_to_dimacs(el[i]));
		fprintf(stderr, " 0\n");
#endif

		// an empty clause leads to UNSAT immediately
		if (vect_empty(&lits)) {
			vect_destroy(&lits);
			s->ok = false;
			return AREF_NIL;
		}

		if (s->ext) {
#ifdef LOGGING
			size_t orig_size = vect_size(&lits);
#endif
			ergo_ext_subst(s, &lits, 0); // no asserting literal to protect here

#ifdef LOGGING
			if (vect_size(&lits) != orig_size) {
				ergo_log_begin(s);
				fprintf(stderr, "extclause (rewritten)");
				int *el = vect_begin(&lits);
				for (size_t i = 0; i < vect_size(&lits); ++i)
					fprintf(stderr, " %d", ergo_lit_to_dimacs(el[i]));
				fprintf(stderr, " 0\n");
			}
#endif
		}

		// mined immediately
		if (s->ext && s->stat.conflicts >= (uint64_t)s->ext_warmup)
			ergo_ext_mine_cl(s, vect_begin(&lits), vect_size(&lits), 0);

		// record IPASIR-UP's external clause after modification (if any)
		struct clause *cl = malloc((size_t)cl_words((int)vect_size(&lits), forgettable) * sizeof(int));
		cl_init(cl, &lits, forgettable);
		ergo_add_cl_warm(s, cl);
		free(cl);
		vect_destroy(&lits);

		if (!s->ok)
			return AREF_NIL; // permanent UNSAT
	}
}

// auxiliary pointer to be used with qsort()
static struct arena *sort_arena;

//
//=============================================================================
static int ergo_compare_acty(const void *a, const void *b)
{
	struct clause *ca = arena_deref(sort_arena, *(const aref *)a);
	struct clause *cb = arena_deref(sort_arena, *(const aref *)b);

	return cl_compare_acty(&ca, &cb);
}

//
//=============================================================================
static int ergo_compare_acty_b(const void *a, const void *b)
{
	struct clause *ca = arena_deref(sort_arena, *(const aref *)a);
	struct clause *cb = arena_deref(sort_arena, *(const aref *)b);

	return cl_compare_acty_b(&ca, &cb);
}

//
//=============================================================================
static int ergo_compare_acty_g(const void *a, const void *b)
{
	struct clause *ca = arena_deref(sort_arena, *(const aref *)a);
	struct clause *cb = arena_deref(sort_arena, *(const aref *)b);

	return cl_compare_acty_g(&ca, &cb);
}

// relocates every live clause reference once the overall garbage fraction
// crosses its threshold; called from 'ergo_reducedb()', 'ergo_reducedb_gluc()',
// and 'ergo_simplify()';
//=============================================================================
void ergo_compact(struct ergo *s)
{
	if (!arena_needs_compact(&s->arena))
		return;

	clmm_clear_free_chains(&s->clauses.storage);
	clmm_clear_free_chains(&s->learnts.storage);

	arena_compact_begin(&s->arena);

	for (int v = 0; v < s->size; ++v)
		if (s->reasons[v] != AREF_NIL && !ergo_reason_is_lazy(s->reasons[v]))
			s->reasons[v] = clmm_reloc(&s->arena, s->reasons[v]);

	for (int l = 0; l < s->size * 2; ++l) {
		struct vect    *wl  = &s->wlists[l];
		struct watcher *w   = vect_begin(wl);
		struct watcher *end = vect_end(wl);

		for (; w != end; ++w) {
			aref tag = w->cl & AREF_TAG;
			w->cl = clmm_reloc(&s->arena, AREF_UNTAG(w->cl)) | tag;
		}
	}

	aref *cls = clset_begin(&s->clauses), *cle = clset_end(&s->clauses);
	for (; cls != cle; ++cls)
		*cls = clmm_reloc(&s->arena, *cls);

	cls = clset_begin(&s->learnts), cle = clset_end(&s->learnts);
	for (; cls != cle; ++cls)
		*cls = clmm_reloc(&s->arena, *cls);

	if (s->ext)
		ext_compact_relocate(s);

	arena_compact_end(&s->arena);
}

// tries to replace 'clr' with the shortest RUP prefix
//=============================================================================
static bool ergo_vivify_cl(struct ergo *s, aref clr, bool *removed)
{
	struct clause *cl = arena_deref(&s->arena, clr);
	int  n = cl_size(cl);
	bool sat = false;
	int  i;

	*removed = false;
	ergo_unstock_cl(s, clr);
	ergo_new_dlevel(s);

	for (i = 0; i < n; ++i) {
		int l = cl_at(cl, i);

		if (s->assigns[l] == ltrue) {
			sat = true;
			break;
		}

		// 'l' isn't already true
		ergo_enqueue(s, lit_neg(l), AREF_NIL);

		if (ergo_propagate(s) != AREF_NIL) {
			++i;
			break;
		}
	}

	ergo_cancel_until(s, 0);

	if (sat || i == n) {
		ergo_stock_cl(s, clr); // unchanged; no shorter RUP prefix found
		return true;
	}

	// account for the old clause before cl_shrink() overwrites its tail;
	// retirement is deferred; retained references are restored below;
	if (s->ext)
		ext_cl_removed(s, cl);

	// 'clr' shrinks to its first 'i' literals; trace the replacement
	// before shrinking, since ergo_trace_cl() always dumps whatever 'cl'
	// currently holds
	if (s->proof_trace) {
		struct vect cl_del; vect_init(&cl_del, sizeof(int));
		cl_litvect_copy(cl, &cl_del);
		cl_shrink(cl, i);
		ergo_trace_cl(cl, false, s->proof_trace);
		ergo_trace_vect(&cl_del, true, s->proof_trace);
		vect_destroy(&cl_del);
	}
	else
		cl_shrink(cl, i);

	s->stat.learnts_literals -= n - i;
	cl_setext(cl, false);
	if (s->ext && i > 1)
		ext_cl_created(s, clr);

	// fix the LBD
	if (cl_lbd(cl) > (unsigned)cl_size(cl))
		cl_relbd(cl, cl_size(cl));

	if (i == 1) {
		*removed = true;
		return ergo_enqueue(s, cl_at(cl, 0), AREF_NIL) && ergo_propagate(s) == AREF_NIL;
	}

	ergo_stock_cl(s, clr);
	return true;
}

// vivifies every non-yet-vivified learnt clause
//=============================================================================
static bool ergo_vivify(struct ergo *s)
{
	aref  *cls = clset_begin(&s->learnts);
	size_t n   = clset_size(&s->learnts);
	size_t i, j;

	for (i = j = 0; i < n; ++i) {
		struct clause *c = arena_deref(&s->arena, cls[i]);
		bool removed;

		if (cl_vivified(c)) {
			cl_setidx(c, (unsigned)j);
			cls[j++] = cls[i];
			continue;
		}

		bool ok = ergo_vivify_cl(s, cls[i], &removed);

		if (removed) {
			// already fully detached by 'ergo_vivify_cl()', so
			// free it directly rather than through
			// ergo_remove_cl()'s lazy watch-list sweep
			s->stat.learnts--;
			s->stat.learnts_literals -= cl_size(c);
			clmm_free(&s->learnts.storage, cls[i]);
		}
		else if (ok) {
			cl_setvivified(c, true);
			cl_setidx(c, (unsigned)j);
			cls[j++] = cls[i];
		}

		if (!ok) {
			// formula proved UNSAT; still compact what's been
			// decided so far, since some of it (this clause
			// included, if 'removed') has already been freed
			clset_shrink(&s->learnts, j);
			return false;
		}
	}

	clset_shrink(&s->learnts, j);
	return true;
}

//
//=============================================================================
void ergo_reducedb(struct ergo *s)
{
	// remove any clause below this activity
	double extra_lim = s->cla_inc / clset_size(&s->learnts);
	aref  *cls        = clset_begin(&s->learnts);

	sort_arena = &s->arena;
	qsort(clset_begin(&s->learnts), clset_size(&s->learnts), sizeof(aref),
			s->keep_bin ? ergo_compare_acty_b : ergo_compare_acty);

	// qsort() permuted every clause's slot in 's->learnts.ptrs'; re-stamp
	// cl_idx() for all of them before anything below trusts it again
	for (size_t k = 0; k < clset_size(&s->learnts); ++k)
		cl_setidx(arena_deref(&s->arena, cls[k]), (unsigned)k);

	size_t i, j;
	for (i = j = 0; i < clset_size(&s->learnts) * s->reduce_by; ++i) {
		struct clause *c = arena_deref(&s->arena, cls[i]);

		if (cl_size(c) > 2 && !ergo_locked_cl(s, cls[i]))
			ergo_remove_cl(s, cls[i]);
		else {
			cl_setidx(c, (unsigned)j);
			cls[j++] = cls[i];
		}
	}

	for (; i < clset_size(&s->learnts); ++i) {
		struct clause *c = arena_deref(&s->arena, cls[i]);

		if (cl_size(c) > 2 && !ergo_locked_cl(s, cls[i]) &&
				cl_get_acty(c) < extra_lim)
			ergo_remove_cl(s, cls[i]);
		else {
			cl_setidx(c, (unsigned)j);
			cls[j++] = cls[i];
		}
	}

	clset_shrink(&s->learnts, j);
	ergo_clean_wlists(s);
	ergo_compact(s);
	ergo_ext_retire_pending(s);
}

//
//=============================================================================
void ergo_reducedb_gluc(struct ergo *s)
{
	aref *cls = clset_begin(&s->learnts);

	sort_arena = &s->arena;
	qsort(clset_begin(&s->learnts), clset_size(&s->learnts), sizeof(aref),
			ergo_compare_acty_g);

	// qsort() permuted every clause's slot in 's->learnts.ptrs'; re-stamp
	// cl_idx() for all of them before anything below trusts it again
	for (size_t k = 0; k < clset_size(&s->learnts); ++k)
		cl_setidx(arena_deref(&s->arena, cls[k]), (unsigned)k);

	// we have a lot of "good" clauses, it is difficult to compare them
	// thus, keep more
	if (cl_lbd(arena_deref(&s->arena, cls[clset_size(&s->learnts) / 2])) <= 3)
		s->reducedb_at += s->reducedb_inc_extra;

	if (cl_lbd(arena_deref(&s->arena, cls[clset_size(&s->learnts) - 1])) <= 5)
		s->reducedb_at += s->reducedb_inc_extra;

	size_t i, j;
	size_t limit = clset_size(&s->learnts) * s->reduce_by;
	for (i = j = 0; i < clset_size(&s->learnts); ++i) {
		struct clause *c = arena_deref(&s->arena, cls[i]);

		if (cl_lbd(c) > 2 && !cl_needed(c) &&
			!ergo_locked_cl(s, cls[i]) && i < limit)
			ergo_remove_cl(s, cls[i]);
		else {
			if (cl_needed(c))
				// keep clause, so we can delete another clause
				limit++;
			cl_setneeded(c, false);
			cl_setidx(c, (unsigned)j);
			cls[j++] = cls[i];
		}
	}

	clset_shrink(&s->learnts, j);
	ergo_clean_wlists(s);
	ergo_compact(s);
	ergo_ext_retire_pending(s);
}

// one-shot CDCL strategy switch at s->adapt_at conflicts: a low
// decisions-per-conflict ratio signals a propagation-heavy instance,
// where a chanseok-style permanent low-lbd pool helps; promotes
// qualifying learnts in one compaction pass instead of via
// 'ergo_promote_cl()' (O(n) per call, O(n^2) here).
//=============================================================================
static void ergo_adapt(struct ergo *s)
{
	if ((double)s->stat.decisions / (double)s->stat.conflicts > 1.2)
		return;

	if (s->verbosity)
		printf("c Adapting solver strategies\n");

	s->permanent_mode = true;
	s->perm_lbd_lb    = 4;
	s->reducedb_gluc  = true;
	s->reducedb_first = 2000;
	s->reducedb_at    = s->reducedb_first;
	s->reducedb_inc   = 0;
	s->curr_start     = s->stat.conflicts / s->reducedb_at + 1;

	bqint_clear(&s->lbd_queue);
	s->lbd_sum = 0;

	aref *cls = clset_begin(&s->learnts);
	size_t i, j;
	for (i = j = 0; i < clset_size(&s->learnts); ++i) {
		struct clause *c = arena_deref(&s->arena, cls[i]);

		if (cl_lbd(c) <= s->perm_lbd_lb) {
			cl_setlearnt(c, false);
			vect_append(&s->clauses.ptrs, cls[i]);
			cl_setidx(c, (unsigned)(vect_size(&s->clauses.ptrs) - 1));

			s->stat.learnts--;
			s->stat.learnts_literals -= cl_size(c);
			s->stat.clauses++;
			s->stat.clauses_literals += cl_size(c);
		}
		else {
			cl_setidx(c, (unsigned)j);
			cls[j++] = cls[i];
		}
	}
	clset_shrink(&s->learnts, j);
}

// IPASIR-UP: connect an external propagator at level 0, replaying root
// assignments after variables are observed; pending external units remain
// permanent facts across reconnection;
//=============================================================================
void ergo_connect_propagator(struct ergo *s, struct ergo_propagator *p)
{
	ergo_disconnect_propagator(s);
	s->propagator = p;
}

// disconnect an external propagator;
// discard non-root lazy reasons while their propagator is still connected;
//=============================================================================
void ergo_disconnect_propagator(struct ergo *s)
{
	ergo_cancel_until(s, 0);
	ergo_notify_pending(s);

	s->propagator = NULL;
	s->notified = 0;
	s->notify_backtrack_pending = false;

	for (int v = 0; v < s->size; ++v) {
		s->observed[v] = false;
		// remaining lazy assignments are permanent root facts
		if (ergo_reason_is_lazy(s->reasons[v])) {
			s->reasons[v] = AREF_NIL;
			s->ext_reason[v] = false;
		}
	}
}

// lets a caller (PySAT, in particular) retrieve whatever it last passed
// to 'ergo_connect_propagator()'; NULL if nothing is connected;
//=============================================================================
struct ergo_propagator *ergo_get_propagator(struct ergo *s)
{
	return s->propagator;
}

// marks 'var' as relevant to the connected propagator; only observed vars get
// reported through 'ergo_notify_assignments()'; a fresh variable can be
// observed too, per IPASIR-UP; 'ergo_setnvars()' grows to fit it;
//=============================================================================
void ergo_observe_var(struct ergo *s, int var)
{
	assert(s->propagator);

	if (var >= s->size)
		ergo_setnvars(s, var + 1);

	s->observed[var] = true;
}

//
//=============================================================================
void ergo_unobserve_var(struct ergo *s, int var)
{
	assert(var < s->size);
	s->observed[var] = false;
}

// true iff 'dimacs_lit' is currently assigned true by a decision, not a
// propagation
//=============================================================================
bool ergo_is_decision(struct ergo *s, int dimacs_lit)
{
	int l = ergo_dimacs_to_lit(dimacs_lit);
	return s->assigns[l] == ltrue && s->reasons[lit_var(l)] == AREF_NIL;
}

// lets a propagator force a backtrack from its own 'cb_decide()' callback
//=============================================================================
void ergo_force_backtrack(struct ergo *s, int new_level)
{
	ergo_cancel_until(s, new_level);
}

//
//=============================================================================
static lbool ergo_search(struct ergo *s, int nof_conflicts)
{
	lbool res = lundef;

	int btlevel   = 0;
	int conflictC = 0;
	unsigned lbd  = 0;
	struct vect learnt = vect_new(int);

	// no assert(ergo_dlevel(s) == 0) here due to warm starts
	s->stat.starts++;
	for (;;) {
		aref confl = ergo_propagate_ext(s);

		if (!s->ok) {
			// an injected external clause hit a level-0 contradiction
			res = lfalse;
			break;
		}

		if (!vect_empty(&s->external_units)) {
			// one or more unit-size external facts; discovered
			// either immediately or lazily while analyzing the
			// last conflict; not analyzable conflict clauses,
			// assert each directly;
			ergo_cancel_until(s, 0);

			bool fail = false;
			for (size_t i = 0; i < vect_size(&s->external_units); ++i) {
				int l = vect_memb(&s->external_units, int, i);
				if (!ergo_enqueue(s, l, AREF_NIL)) {
					// 'l' was already permanently false at
					// level 0; the formula must be unsatisfiable;
					fail = true;
					break;
				}
			}
			vect_clear(&s->external_units);

			if (fail) {
				s->ok = false;
				res = lfalse;
				break;
			}
			continue; // the next iteration propagates these and
				  // catches any resulting conflict
		}

		if (confl != AREF_NIL) {
			// CONFLICT
			conflictC++;
			s->stat.conflicts++;

			if (s->adapt && s->stat.conflicts == s->adapt_at) {
				ergo_adapt(s);
				s->adapt = false;
			}

			if (s->glucose_bump) {
				float vd = 1 / s->var_decay;
				if (s->stat.conflicts % 5000 == 0 && vd < 0.95)
					s->var_decay = 1 / (vd + 0.01);
			}

			if (ergo_dlevel(s) == 0) {
				res = lfalse;
				break;
			}

			if (s->restart_gluc) {
				bqint_push(&s->trail_queue, s->qtail);
				if (s->stat.conflicts > 10000 && bqint_isfull(&s->lbd_queue) &&
						s->qtail > s->restart_gluc_br * bqint_getavg(&s->trail_queue))
					bqint_clear(&s->lbd_queue);
			}

			vect_shrink(&learnt, 0);
			ergo_analyze(s, confl, &learnt, &btlevel, &lbd);
			if (s->ext)
				ergo_ext_mine_learnt(s, &learnt);
			ergo_cancel_until(s, btlevel);

			ergo_learn(s, &learnt, lbd);
			ergo_decay_act_v(s);
			ergo_decay_act_c(s);

			bqint_push(&s->lbd_queue, lbd);
			s->lbd_sum += lbd;

			if (s->proof_trace)
				ergo_trace_vect(&learnt, false, s->proof_trace);

			if (--s->ls_adjust_cnt == 0) {
				s->ls_adjust_confl *= s->ls_adjust_inc;
				s->ls_adjust_cnt    = s->ls_adjust_confl;
				s->max_learnts     *= s->learntsize_inc;

				if (s->verbosity)
					ergo_print_status(s);
			}
		}
		else {
			// NO CONFLICT
			// out of budget or interrupted takes priority over (and skips)
			// the ordinary restart-policy checks below
			bool restart = !ergo_within_budget(s);
			if (!restart) {
				if (!s->restart_gluc) {
					if (conflictC >= nof_conflicts)
						// reached bound on number of conflicts
						restart = true;
				}
				else if (bqint_isfull(&s->lbd_queue) && (bqint_getavg(&s->lbd_queue) * s->restart_gluc_fr > s->lbd_sum / s->stat.conflicts)) {
					// glucose-like restart
					bqint_clear(&s->lbd_queue);
					restart = true;
				}
			}

			if (restart) {
				s->progress_estimate = ergo_progress(s);
				ergo_cancel_until(s, 0);
				if (s->ext)
					ergo_ext_rewrite(s);
				if (!s->ok)
					res = lfalse;

				break;
			}

			int before = s->qtail;

			// simplify the set of problem clauses
			if (ergo_dlevel(s) == 0 && ergo_simplify(s) == false) {
				res = lfalse;
				break;
			}

			// vivify learnt clauses (LCM); tied to decision level
			// 0 like simplify above; its probe levels are not
			// to be announced to the propagator (if any);
			if (s->lcm && ergo_dlevel(s) == 0) {
				s->probing = true;
				bool ok = ergo_vivify(s);
				s->probing = false;

				if (!ok) {
					res = lfalse;
					break;
				}
			}

			// new permanent facts: propagate them -- external
			// propagator included -- before opening a decision level
			if (s->qtail != before)
				continue;

			if (!s->reducedb_gluc) {
				if ((int)ergo_nlearnts(s) - s->qtail >= s->max_learnts)
					// reduce the set of learnt clauses
					ergo_reducedb(s);
			}
			else if (s->stat.conflicts >= s->curr_start * s->reducedb_at) {
				assert(clset_size(&s->learnts));
				s->curr_start = s->stat.conflicts / s->reducedb_at + 1;
				ergo_reducedb_gluc(s);
				s->reducedb_at += s->reducedb_inc;
			}

			// making a new decision
			if ((res = ergo_assume(s)) != lundef)
				break;
		}
	}

	vect_destroy(&learnt);
	return res;
}

//
//=============================================================================
struct ergo *ergo_new(void)
{
	struct ergo *s = malloc(sizeof(struct ergo));

	// initialize clause storages; 'clauses' and 'learnts' share one arena
	arena_init(&s->arena);
	clset_init(&s->clauses, &s->arena, false);
	clset_init(&s->learnts, &s->arena, true);

	// initialize vectors
	vect_init(&s->order,          sizeof(int  ));
	vect_init(&s->trail_lim,      sizeof(int  ));
	vect_init(&s->assumps,        sizeof(int  ));
	vect_init(&s->model,          sizeof(lbool));
	vect_init(&s->conflict,       sizeof(int  ));
	vect_init(&s->tagged,         sizeof(int  ));
	vect_init(&s->stack_i,        sizeof(int  ));
	vect_init(&s->stack_p,        sizeof(int  ));
	vect_init(&s->wdirty,         sizeof(int  ));
	vect_init(&s->last_level,     sizeof(int  ));
	vect_init(&s->notify_buf,     sizeof(int  ));
	vect_init(&s->external_units, sizeof(int  ));

	// initialize arrays
	s->wlists     = NULL;
	s->wdirt_c    = NULL;
	s->activity   = NULL;
	s->polarity   = NULL;
	s->user_pol   = NULL;
	s->dec_var    = NULL;
	s->observed   = NULL;
	s->assigns    = NULL;
	s->orderpos   = NULL;
	s->reasons    = NULL;
	s->levels     = NULL;
	s->perm_diff  = NULL;
	s->tags       = NULL;
	s->trail      = NULL;

	// initialize other vars
	s->size               = 0;
	s->cap                = 0;
	s->cap_levels         = 0;
	s->qhead              = 0;
	s->qtail              = 0;
	s->dec_vars           = 0;
	s->ok                 = true;
	s->warm_start         = false;
	s->probing            = false;
	s->conflict_budget    = -1;
	s->propagation_budget = -1;
	s->asynch_interrupt   = false;
	s->cla_inc            = 1;
	s->cla_decay          = 1 / 0.999; // both are stored inverted, so a
	s->var_inc            = 1;         // literal 1 would mean "no decay";
	s->var_decay          = 1 / 0.95;  // cli.c overwrites them from options
	s->reduce_by          = 0.5;
	s->rnd_vfreq          = 0;
	s->simpdb_assigns     = 0;
	s->simpdb_props       = 0;
	s->progress_estimate  = 0;

	s->stat.starts           = 0;
	s->stat.decisions        = 0;
	s->stat.propagations     = 0;
	s->stat.conflicts        = 0;
	s->stat.clauses          = 0;
	s->stat.clauses_literals = 0;
	s->stat.learnts          = 0;
	s->stat.learnts_literals = 0;
	s->stat.max_literals     = 0;
	s->stat.tot_literals     = 0;

	// optional parameters
	s->restart_arif      = false;
	s->restart_luby      = false;
	s->restart_gluc      = false;
	s->restart_first     = 100;
	s->restart_inc       = 2;
	s->min_learnts_lim   = 0;
	s->learntsize_inc    = 1.1;
	s->learntsize_factor = (double)1 / 3;
	s->ls_adjust_start   = 100;
	s->ls_adjust_inc     = 1.5;

	s->verbosity        = 0;
	s->ccmin_mode       = 0;
	s->phase_saving     = 0;
	s->jw_acty          = false;
	s->jw_polar         = false;
	s->jw_hard          = false;
	s->keep_bin         = false;
	s->glucose_bump     = false;
	s->remove_satisfied = true;
	s->no_copy          = false;

	// DRUP proof related
	s->proof_trace = NULL;

	// IPASIR-UP
	s->propagator               = NULL;
	s->notified                 = 0;
	s->notify_backtrack_pending = false;

	// backported from glucose 3.0
	s->restart_gluc_fr    = 0.8;
	s->restart_gluc_br    = 1.4;
	s->lbd_queue_sz       = 50;
	s->trail_queue_sz     = 5000;
	s->reducedb_first     = 2000;
	s->reducedb_inc       = 300;
	s->reducedb_inc_extra = 1000;
	s->reducedb_gluc      = false;
	s->frozencl_lbd_lb    = 30;
	s->ccmin_sz_lb        = 30;
	s->ccmin_lbd_lb       = 6;
	s->curr_start         = 1;
	s->magic_counter      = 0;
	s->reducedb_at        = s->reducedb_first;
	s->lbd_sum            = 0;
	s->adapt              = false;
	s->adapt_at           = 100000;
	s->permanent_mode     = false;
	s->perm_lbd_lb        = 0;
	s->lcm                = false;

	ext_init(s);

	bqint_init(&s->lbd_queue,   s->lbd_queue_sz  );
	bqint_init(&s->trail_queue, s->trail_queue_sz);

	return s;
}

// writes a DRUP trace to 'fp'; the caller keeps ownership of the stream
// and should close it;
//=============================================================================
void ergo_set_proof(struct ergo *s, FILE *fp)
{
	s->proof_trace = fp;
}

//
//=============================================================================
void ergo_delete(struct ergo *s)
{
	// delete clause sets, then the arena they share
	clset_destroy(&s->clauses);
	clset_destroy(&s->learnts);
	arena_destroy(&s->arena);

	// delete vectors
	vect_destroy(&s->order         );
	vect_destroy(&s->trail_lim     );
	vect_destroy(&s->tagged        );
	vect_destroy(&s->stack_i       );
	vect_destroy(&s->stack_p       );
	vect_destroy(&s->assumps       );
	vect_destroy(&s->model         );
	vect_destroy(&s->conflict      );
	vect_destroy(&s->wdirty        );
	vect_destroy(&s->last_level    );
	vect_destroy(&s->notify_buf    );
	vect_destroy(&s->external_units);
	ext_destroy(s);

	// delete arrays
	if (s->wlists != NULL) {
		for (int i = 0; i < s->size * 2; ++i)
			vect_destroy(&s->wlists[i]);

		// if one is different from null, all are
		free(s->wlists    );
		free(s->wdirt_c   );
		free(s->activity  );
		free(s->polarity  );
		free(s->user_pol  );
		free(s->dec_var   );
		free(s->observed  );
		free(s->assigns   );
		free(s->orderpos  );
		free(s->reasons   );
		free(s->levels    );
		free(s->perm_diff );
		free(s->trail     );
		free(s->tags      );
	}

	bqint_destroy(&s->lbd_queue  );
	bqint_destroy(&s->trail_queue);

	free(s);
}

//
//=============================================================================
static bool ergo_prepare_cl(struct ergo *s, struct clause *cl, int **e)
{
	int *begin = cl_begin(cl);
	int *end   = cl_end  (cl);

	// insertion sort
	int *i, *j;
	int maxvar = lit_var(*cl_begin(cl));
	for (i = begin + 1; i < end; ++i) {
		int l = *i;
		maxvar = lit_var(l) > maxvar ? lit_var(l) : maxvar;
		for (j = i; j > begin && *(j - 1) > l; --j)
			*j = *(j - 1);
		*j = l;
	}
	ergo_setnvars(s, maxvar + 1);

	bool cl_modified = false;  // check if the clause is modified
	struct vect cl_del;        // copy of original clause

	if (s->proof_trace) {
		vect_init(&cl_del, sizeof(int));
		cl_litvect_copy(cl, &cl_del);

		for (i = j = begin; i < end; ++i) {
			if (s->assigns[*i] != lundef)
				cl_modified = true;
		}
	}

	// delete duplicates
	int last = lit_undef;
	for (i = j = begin; i < end; ++i) {
		if (*i == lit_neg(last) || s->assigns[*i] == ltrue) {
			if (s->proof_trace)
				vect_destroy(&cl_del);
			return true;   // tautology
		}
		else if (*i != last && s->assigns[*i] == lundef)
			last = *j++ = *i;
	}

	if (s->proof_trace) {
		if (cl_modified) {
			ergo_trace_cl(cl, false, s->proof_trace);
			ergo_trace_vect(&cl_del, true, s->proof_trace);
		}

		vect_destroy(&cl_del);
	}

	*e = j;
	return false;
}

// like ergo_prepare_cl(), but for a warm-start clause (trail non-empty): a
// literal dies only if permanently false (at level 0);
//=============================================================================
static bool ergo_prepare_cl_warm(
	struct ergo *s,
	struct clause *cl,
	int **e,
	int *ws,
	int *nws,
	int *max_i
)
{
	int *begin = cl_begin(cl);
	int *end   = cl_end  (cl);

	// insertion sort
	int *i, *j;
	int maxvar = lit_var(*begin);
	for (i = begin + 1; i < end; ++i) {
		int l = *i;
		maxvar = lit_var(l) > maxvar ? lit_var(l) : maxvar;
		for (j = i; j > begin && *(j - 1) > l; --j)
			*j = *(j - 1);
		*j = l;
	}
	ergo_setnvars(s, maxvar + 1);

	int last = lit_undef;
	*nws   = 0;
	*max_i = 0;

	for (i = j = begin; i < end; ++i) {
		int l = *i;
		int v = lit_var(l);

		if ((s->assigns[l] == ltrue && s->levels[v] == 0) || l == lit_neg(last))
			return true;   // permanently satisfied, or tautology

		if ((s->assigns[l] != lfalse || s->levels[v] > 0) && l != last) {
			if (s->assigns[l] != lfalse && *nws < 2)
				ws[(*nws)++] = (int)(j - begin);
			if (s->levels[v] > s->levels[lit_var(*(begin + *max_i))])
				*max_i = (int)(j - begin);

			last = *j++ = l;
		}
	}

	*e = j;
	return false;
}

// finishes resolving a conflict caused by a clause just added under warm start
//=============================================================================
static bool ergo_resolve_conflicts(struct ergo *s, aref confl)
{
	struct vect learnt = vect_new(int);
	unsigned    lbd;
	int         btlevel;

	while (confl != AREF_NIL) {
		s->stat.conflicts++;

		if (ergo_dlevel(s) == 0) {
			vect_destroy(&learnt);
			return false;
		}

		vect_shrink(&learnt, 0);
		ergo_analyze(s, confl, &learnt, &btlevel, &lbd);
		ergo_cancel_until(s, btlevel);
		ergo_learn(s, &learnt, lbd);

		if (s->proof_trace)
			ergo_trace_vect(&learnt, false, s->proof_trace);

		ergo_decay_act_v(s);
		ergo_decay_act_c(s);

		confl = ergo_propagate(s);
	}

	vect_destroy(&learnt);
	return true;
}

// adds a clause mid-search without unwinding the trail; if not already
// falsified, just attach it watching non-false literals; if falsified, watch
// its two highest-level literals and backtrack to the second one's level
//=============================================================================
static bool ergo_add_cl_warm(struct ergo *s, struct clause *cl)
{
	int *beg = cl_begin(cl);
	int *end = NULL;
	int  ws[2];
	int  nws, max_i;

	if (ergo_prepare_cl_warm(s, cl, &end, ws, &nws, &max_i))
		return true;

	int n = (int)(end - beg);

	if (n == 0) {
		ergo_cancel_until(s, 0);
		s->ok = false;
		return false;
	}
	else if (n == 1) {
		// a permanent fact can only be asserted at decision level 0
		ergo_cancel_until(s, 0);
		if (!ergo_enqueue(s, *beg, AREF_NIL) || ergo_propagate(s) != AREF_NIL) {
			s->ok = false;
			return false;
		}
		return true;
	}

	if (nws) {
		int t = beg[0]; beg[0] = beg[ws[0]]; beg[ws[0]] = t;
		if (nws == 2) {
			t = beg[1]; beg[1] = beg[ws[1]]; beg[ws[1]] = t;
		}
	}
	else {
		int t = beg[0]; beg[0] = beg[max_i]; beg[max_i] = t;

		max_i = 1;
		for (int i = 2; i < n; ++i)
			if (s->levels[lit_var(beg[i])] > s->levels[lit_var(beg[max_i])])
				max_i = i;

		t = beg[1]; beg[1] = beg[max_i]; beg[max_i] = t;

		ergo_cancel_until(s, s->levels[lit_var(beg[1])]);
	}

	struct vect cl_v;
	cl_v.ptr   = cl->lits;
	cl_v.nmemb = cl_size(cl);
	vect_shrink(&cl_v, n);
	aref clr = ergo_new_cl(s, &cl_v, 0);

	if (!nws) {
		if (s->assigns[beg[0]] == lundef)
			ergo_enqueue(s, beg[0], clr);
		else if (s->assigns[beg[0]] == lfalse && !ergo_resolve_conflicts(s, clr))
			s->ok = false;
	}

	return s->ok;
}

//
//=============================================================================
bool ergo_add_cl(struct ergo *s, struct clause *cl)
{
	if (!s->ok)
		return false;

	if (cl_empty(cl)) {
		s->ok = false;
		return false;
	}

	if (s->warm_start && ergo_dlevel(s) > 0)
		return ergo_add_cl_warm(s, cl);

	assert(ergo_dlevel(s) == 0);

	int *beg = cl_begin(cl);
	int *end = NULL;

	if (ergo_prepare_cl(s, cl, &end))
		return true;

	if (end == beg) {          // empty clause
		s->ok = false;
		return false;
	}
	else if (end - beg == 1) { // unit clause
		// this fact can immediately contradict an existing one
		if (!ergo_enqueue(s, *beg, AREF_NIL) || ergo_propagate(s) != AREF_NIL) {
			s->ok = false;
			return false;
		}
		return true;
	}

	// create new clause
	struct vect cl_v;
	cl_v.ptr   = cl->lits;
	cl_v.nmemb = cl_size(cl);
	vect_shrink(&cl_v, end - beg);
	ergo_new_cl(s, &cl_v, 0);

	return true;
}

// appends the formula to the current set of clauses
//=============================================================================
bool ergo_append_formula(struct ergo *s, struct clset *formula)
{
	bool res = true;

	for (size_t i = 0; res && i < clset_size(formula); ++i)
		res = ergo_add_cl(s, clset_deref(formula, clset_at(formula, i)));

	return res && ergo_simplify(s);
}

// cleans the current formula first
//=============================================================================
bool ergo_import_formula(struct ergo *s, struct clset *formula)
{
	if (!clset_empty(&s->clauses)) {
		clset_destroy(&s->clauses);
		clset_init   (&s->clauses, &s->arena, false);
	}

	return ergo_append_formula(s, formula);
}

// uses the current formula without importing it;
// the corresponding clset is supposed to be preserved in memory and not copied
//=============================================================================
bool ergo_use_formula(struct ergo *s, struct clset *formula)
{
	clset_destroy(&s->clauses);

	s->clauses = *formula;
	aref *cls = clset_begin(&s->clauses);

	size_t i, j;
	for (i = j = 0; i < clset_size(&s->clauses); ++i) {
		struct clause *c = arena_deref(&s->arena, cls[i]);

		if (cl_empty(c)) {
			s->ok = false;
			return false;
		}

		int *beg = cl_begin(c), *end = NULL;

		if (ergo_prepare_cl(s, c, &end))  // tautology
			clmm_free(&s->clauses.storage, cls[i]);
		else if (end == beg) {  // empty clause
			s->ok = false;
			return false;
		}
		else if (end - beg == 1) {
			// unit clause
			if (!ergo_enqueue(s, *beg, AREF_NIL)) {
				s->ok = false;
				return false;
			}

			clmm_free(&s->clauses.storage, cls[i]);
		}
		else {
			// keep clause
			cl_shrink(c, end - beg);
			ergo_stock_cl(s, cls[i]);
			cl_setidx(c, (unsigned)j);
			cls[j++] = cls[i];

			s->stat.clauses++;
			s->stat.clauses_literals += cl_size(c);
		}
	}

	clset_shrink(&s->clauses, j);
	return ergo_simplify(s);
}

//
//=============================================================================
bool ergo_load_formula(struct ergo *s, FILE *fp)
{
	struct clset formula = clset_new(&s->arena, false);
	cnffmt_parse(fp, &formula);

	if (s->proof_trace)
		fprintf(s->proof_trace, "o proof DRUP\n");

	bool res;
	if (s->no_copy)
		res = ergo_use_formula(s, &formula);
	else {
		// doubling memory consumption here
		res = ergo_import_formula(s, &formula);
		clset_destroy(&formula);
	}

	return res;
}

//
//=============================================================================
bool ergo_simplify(struct ergo *s)
{
	assert(ergo_dlevel(s) == 0);

	if (!s->ok || ergo_propagate(s) != AREF_NIL) {
		s->ok = false;
		return false;
	}

	if (s->qhead == s->simpdb_assigns || s->simpdb_props > 0)
		return true;

	for (int type = 1 - (int)s->remove_satisfied; type < 2; ++type) {
		struct clset *cs  = type ? &s->learnts : &s->clauses;
		aref         *cls = clset_begin(cs);
		size_t i, j;
		for (i = j = 0; i < clset_size(cs); ++i) {
			struct clause *c = arena_deref(&s->arena, cls[i]);

			if (type == 0 && s->ext && ext_cl_protected(s, c)) {
				cl_setidx(c, (unsigned)j);
				cls[j++] = cls[i];
				continue;
			}

			if (ergo_cl_satisfied(s, cls[i]))
				ergo_remove_cl(s, cls[i]);
			else {
				cl_setidx(c, (unsigned)j);
				cls[j++] = cls[i];
			}
		}

		clset_shrink(cs, j);
	}

	ergo_clean_wlists(s);
	ergo_compact(s);
	ergo_ext_retire_pending(s);
	order_rebuild(s);

	s->simpdb_assigns = s->qhead;
	s->simpdb_props   = s->stat.clauses_literals + s->stat.learnts_literals;

	return true;
}

//
//=============================================================================
void ergo_clear_learnts(struct ergo *s)
{
	if (clset_size(&s->learnts)) {
		aref *cls = clset_begin(&s->learnts);
		for (size_t i = 0; i < clset_size(&s->learnts); ++i)
			ergo_remove_cl(s, cls[i]);

		clset_shrink(&s->learnts, 0);
		ergo_clean_wlists(s);
		ergo_compact(s);
		ergo_ext_retire_pending(s);
	}
}

//
//=============================================================================
static inline double ergo_luby(double y, int x)
{
	// find the finite subsequence that contains index 'x'
	// and the size of that subsequence
	int size, seq;
	for (size = 1, seq = 0; size < x + 1; seq++, size = 2 * size + 1)
		;

	while (size - 1 != x) {
		size = (size - 1) >> 1;
		seq--;
		x = x % size;
	}

	return pow(y, seq);
}

//
//=============================================================================
void ergo_jw_activity(struct ergo *s, double *var_a)
{
	for (int v = 0; v < ergo_nvars(s); ++v) {
		if (s->dec_var[v]) {
			s->activity[v] = var_a[v];

			if (s->activity[v] > 1e100)
				ergo_rescale_act_v(s);

			if (s->orderpos[v] != -1)
				order_percolate_up(s, s->orderpos[v]);
		}
	}
}

//
//=============================================================================
void ergo_jw_polarity(struct ergo *s, double *var_p)
{
	// in order to get longer propagation
	// setting the opposite (!) JW polarities to decision vars

	// if the value of jw_hard is true:
	// setting user defined polarities, which
	// won't be changed during the search process
	// otherwise:
	// setting polarities "softy", i.e.
	// polarities can be modified by phase saving

	int *pol_arr = s->jw_hard ? s->user_pol : s->polarity;

	for (int v = 0; v < ergo_nvars(s); ++v) {
		if (s->dec_var[v])
			pol_arr[v] = var_p[v] < 0 ? lit_of(v) : lit_neg(lit_of(v));
	}
}

//
//=============================================================================
void ergo_jw_compute(struct ergo *s, double *var_a, double *var_p)
{
	aref *cls = clset_begin(&s->clauses);
	for (size_t i = 0; i < ergo_nclauses(s); ++i) {
		struct clause *c  = arena_deref(&s->arena, cls[i]);
		int            sz = cl_size(c);

		// first, computing a real clause size
		// disregarding falsified literals
		for (size_t j = 0; j < cl_size(c); ++j) {
			int l = cl_at(c, j);

			if (s->assigns[l] != lundef) {
				if (s->assigns[l] == lfalse)
					--sz;
				else {
					sz = 0;
					break;
				}
			}
		}

		if (sz) {
			// the clause is not already satisfied
			double cl_w = pow(2, -sz);
			assert(cl_w < 1);

			for (size_t j = 0; j < cl_size(c); ++j) {
				int l = cl_at(c, j);
				int v = lit_var(l);
				var_a[v] += cl_w;

				if (lit_sign(l))
					var_p[v] -= cl_w;
				else
					var_p[v] += cl_w;
			}
		}
	}
}

//
//=============================================================================
void ergo_set_jwmode(struct ergo *s)
{
	double *var_a = calloc(ergo_nvars(s), sizeof(double));
	double *var_p = calloc(ergo_nvars(s), sizeof(double));
	ergo_jw_compute(s, var_a, var_p);

	if (s->jw_acty)
		ergo_jw_activity(s, var_a);
	if (s->jw_polar)
		ergo_jw_polarity(s, var_p);

	free(var_a);
	free(var_p);
}

// shared by ergo_solve() and ergo_solve_lim(); the only difference between
// the two is whether the budget is forced and whether the caller
// gets to see an 'lundef' (unknown) instead of it collapsing to false
//=============================================================================
static lbool ergo_solve_(struct ergo *s, struct vect *assumps)
{
	lbool res = lundef;

	if (!s->ok)
		return lfalse;

	vect_clear(&s->conflict);

	s->max_learnts = ergo_nclauses(s) * s->learntsize_factor;
	if (s->max_learnts < s->min_learnts_lim)
		s->max_learnts = s->min_learnts_lim;

	s->ls_adjust_confl = s->ls_adjust_start;
	s->ls_adjust_cnt   = (int)s->ls_adjust_confl;

	// reconciliation only ever matters under warm start; without it,
	// dlevel is always already 0 here, so skip the snapshot entirely
	if (s->warm_start) {
		struct vect old_assumps = vect_new(int);
		vect_copy_to(&s->assumps, &old_assumps);

		if (assumps)
			vect_copy_to(assumps, &s->assumps);

		ergo_reconcile_assumps(s, &old_assumps);
		vect_destroy(&old_assumps);
	}
	else if (assumps)
		vect_copy_to(assumps, &s->assumps);

	if (s->verbosity)
		ergo_print_head();

	for (int restart = 0; res == lundef; ++restart) {
		double rest_base = 0;

		if (s->restart_gluc == false) {
			if (s->restart_luby == false)
				if (s->restart_arif == false)
					rest_base = pow(s->restart_inc, restart);
				else
					rest_base = restart + 1;
			else
				rest_base = ergo_luby(s->restart_inc, restart);
		}

		res = ergo_search(s, rest_base * s->restart_first);

		if (!ergo_within_budget(s))
			break;
	}

	if (s->verbosity)
		ergo_print_tail();

	if (res == ltrue) {
		vect_clear(&s->model);
		for (int i = 0; i < s->size; ++i)
			vect_append(&s->model, s->assigns[2 * i]);
	}
	else if (res == lfalse) {
		if (s->proof_trace)
			// formula is unsatisfiable
			// so add an empty resolvent
			fprintf(s->proof_trace, "0\n");

		if (vect_empty(&s->conflict))
			s->ok = false;
	}
	// res == lundef: out of budget or interrupted before a verdict was
	// reached; nothing above can be concluded; status stays unknown;

	// under warm start, a SAT result keeps the trail: the next ergo_solve()
	// (or a warm ergo_add_cl()) picks up from here instead of from scratch
	if (!s->warm_start || res != ltrue)
		ergo_cancel_until(s, 0);

	return res;
}

//
//=============================================================================
bool ergo_solve(struct ergo *s, struct vect *assumps)
{
	ergo_budget_off(s);
	return ergo_solve_(s, assumps) == ltrue;
}

// like ergo_solve(), but honors whatever budget/interrupt state the caller
// has set via ergo_set_cbudget()/ergo_set_pbudget()/ergo_interrupt() instead of
// forcing it off, and returns the genuine tristate result: lundef means the
// budget ran out or the solve was interrupted before reaching a verdict;
// not that the formula is unsatisfiable
//=============================================================================
lbool ergo_solve_lim(struct ergo *s, struct vect *assumps)
{
	return ergo_solve_(s, assumps);
}

// pushes each of 'assumps' as its own decision and propagates, collecting
// every literal this implies into 'prop' (including, on conflict, the
// falsified clause's first literal); always backtracks back to the level
// it started at before returning, so unlike ergo_solve() this never commits
// anything; a quick, side-effect-free "what would follow from these" probe
//=============================================================================
bool ergo_prop_check(
	struct ergo *s,
	struct vect *assumps,
	struct vect *prop,
	int psaving
)
{
	vect_clear(prop);

	if (!s->ok)
		return false;

	bool st    = true;
	int  level = ergo_dlevel(s);
	aref confl = AREF_NIL;

	int psaving_save = s->phase_saving;
	s->phase_saving  = psaving;

	for (size_t i = 0; st && confl == AREF_NIL && i < vect_size(assumps); ++i) {
		int *p = vect_at(assumps, i);

		if (s->assigns[*p] == lfalse)
			st = false;
		else if (s->assigns[*p] != ltrue) {
			ergo_new_dlevel(s);
			ergo_enqueue(s, *p, AREF_NIL);
			confl = ergo_propagate(s);
		}
	}

	if (ergo_dlevel(s) > level) {
		int bound = vect_memb(&s->trail_lim, int, level);
		for (int i = bound; i < s->qtail; ++i)
			vect_append(prop, s->trail[i]);

		if (confl != AREF_NIL)
			vect_append(prop, cl_at(arena_deref(&s->arena, confl), 0));

		ergo_cancel_until(s, level);
	}

	s->phase_saving = psaving_save;

	return st && confl == AREF_NIL;
}

//
//=============================================================================
int ergo_nvars(struct ergo *s)
{
	return s->size;
}

//
//=============================================================================
size_t ergo_nclauses(struct ergo *s)
{
	return clset_size(&s->clauses);
}

//
//=============================================================================
size_t ergo_nlearnts(struct ergo *s)
{
	return clset_size(&s->learnts);
}

//
//=============================================================================
uint64_t ergo_nconflicts(struct ergo *s)
{
	return s->stat.conflicts;
}

//
//=============================================================================
uint64_t ergo_ndecisions(struct ergo *s)
{
	return s->stat.decisions;
}

//
//=============================================================================
uint64_t ergo_npropagations(struct ergo *s)
{
	return s->stat.propagations;
}

//
//=============================================================================
uint64_t ergo_nstarts(struct ergo *s)
{
	return s->stat.starts;
}
