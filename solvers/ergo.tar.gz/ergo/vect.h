/*
 * vect.h
 *
 *  Created on: Sep 19, 2011
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef VECT_H_
#define VECT_H_

// system includes:
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
// local defines:

// local types:
//=============================================================================

// typed vectors share operations; element sizes are compile-time constants
//=============================================================================
#define DECLARE_VECT(__name, __type, __size_type)                             \
static_assert(sizeof(__size_type) <= sizeof(size_t) &&                        \
		(__size_type)-1 > 0 && (__size_type)2 > 1,                    \
		"vector counters must be unsigned and fit size_t");           \
struct __name {                                                               \
	__size_type cap;                                                      \
	__size_type nmemb;                                                    \
	__type *ptr;                                                          \
}

// some common vector types
//=============================================================================
DECLARE_VECT(int_vect,       int, size_t);
DECLARE_VECT(char_vect,     char, size_t);
DECLARE_VECT(double_vect, double, size_t);

// allocation checks stay off the append fast path
//=============================================================================
static inline void vect_overflow(void)
{
	fputs("ergo: vector capacity overflow\n", stderr);
	abort();
}

//
//=============================================================================
static inline void *vect_realloc(void *ptr, size_t count, size_t size)
{
	if (count && size > SIZE_MAX / count)
		vect_overflow();

	void *mem = realloc(ptr, count * size);
	if (!mem && count) {
		fputs("ergo: out of memory allocating vector\n", stderr);
		abort();
	}
	return mem;
}

// keep allocation and growth checks out of hot loops
//=============================================================================
static __attribute__((noinline, cold)) void *vect_grow(void *ptr,
		size_t *capacity, size_t size, size_t limit)
{
	size_t cap = *capacity;

	if (cap == limit)
		vect_overflow();

	*capacity = !cap ? 4 : cap > limit / 2 ? limit : cap * 2;
	return vect_realloc(ptr, *capacity, size);
}

//
//=============================================================================
#define vect_init(__self)                                                     \
({	__typeof__(__self) __i = (__self);                                    \
	__i->cap   = 4;                                                       \
	__i->nmemb = 0;                                                       \
	__i->ptr   = vect_realloc(NULL, 4, sizeof(*__i->ptr));                \
	(void)0; })

//
//=============================================================================
#define vect_new(__name)                                                      \
({	struct __name __v;                                                    \
	vect_init(&__v);                                                      \
	__v; })

//
//=============================================================================
#define vect_new_p(__name)                                                    \
({	struct __name *__v = vect_realloc(NULL, 1, sizeof(struct __name));    \
	vect_init(__v);                                                       \
	__v; })

//
//=============================================================================
#define vect_limit(__self) ((size_t)((__typeof__((__self)->cap))-1))

// reserve space for n entries
//=============================================================================
#define vect_reserve(__self, __n)                                             \
({	__typeof__(__self) __r = (__self);                                    \
	size_t __c = (__n);                                                   \
	if (__c > vect_capacity(__r)) {                                       \
		if (__c > vect_limit(__r))                                    \
			vect_overflow();                                      \
		__r->ptr = vect_realloc(__r->ptr, __c,                        \
				sizeof(*__r->ptr));                           \
		__r->cap = __c;                                               \
	} })

//
//=============================================================================
#define vect_destroy(__self) free(vect_data(__self))

//
//=============================================================================
#define vect_destroy_p(__self)                                                \
({	__typeof__(__self) __v = (__self);                                    \
	vect_destroy(__v);                                                    \
	free(__v); })

// copy live elements without discarding destination capacity
//=============================================================================
#define vect_copy_to(__self, __dest)                                          \
({	__typeof__(__self) __s = (__self);                                    \
	__typeof__(__dest) __d = (__dest);                                    \
	static_assert(__builtin_types_compatible_p(                           \
			__typeof__(*__s->ptr), __typeof__(*__d->ptr)),        \
			"incompatible vector element types");                 \
	vect_reserve(__d, vect_size(__s));                                    \
	if (!vect_empty(__s) && vect_data(__d) != vect_data(__s))             \
		memcpy(vect_data(__d), vect_data(__s),                        \
				vect_size(__s) * sizeof(*__s->ptr));          \
	__d->nmemb = __s->nmemb;                                              \
	(void)0; })

//
//=============================================================================
#define vect_copy_lazy(__self, __dest) vect_copy_to(__self, __dest)

//
//=============================================================================
#define vect_empty(__self) (vect_size(__self) == 0)

//
//=============================================================================
#define vect_size(__self) ((size_t)(__self)->nmemb)

//
//=============================================================================
#define vect_shrink(__self, __to)                                             \
({	__typeof__(__self) __s = (__self);                                    \
	size_t __n = (__to);                                                  \
	assert(__n <= vect_size(__s));                                        \
	__s->nmemb = __n;                                                     \
	(void)0; })

//
//=============================================================================
#define vect_clear(__self) vect_shrink(__self, 0)

//
//=============================================================================
#define vect_capacity(__self) ((size_t)(__self)->cap)

//
//=============================================================================
#define vect_data(__self) ((__self)->ptr)

//
//=============================================================================
#define vect_at(__self, __pos) (vect_data(__self) + (__pos))

// deprecated; use *vect_at() instead
//=============================================================================
#define vect_memb(__self, __type, __pos) (*(__type *)vect_at(__self, __pos))

//
//=============================================================================
#define vect_begin(__self) vect_data(__self)

//
//=============================================================================
#define vect_end(__self)                                                      \
({	__typeof__(__self) __t = (__self);                                    \
	vect_at(__t, vect_size(__t)); })

//
//=============================================================================
#define vect_rbegin(__self)                                                   \
({	__typeof__(__self) __b = (__self);                                    \
	!vect_empty(__b) ? vect_at(__b, vect_size(__b)-1) : vect_begin(__b); })

//
//=============================================================================
#define vect_rend(__self) (vect_begin(__self) - 1)

//
//=============================================================================
#define vect_front(__self) vect_begin(__self)

//
//=============================================================================
#define vect_back(__self)  vect_rbegin(__self)

//
//=============================================================================
#define vect_append(__self, __ent)                                            \
({	__typeof__(__self   ) __a = (__self);                                 \
	__typeof__(*__a->ptr) __e = (__ent );                                 \
	if (vect_size(__a) == vect_capacity(__a)) {                           \
		size_t __c = __a->cap;                                        \
		__a->ptr = vect_grow(__a->ptr, &__c,                          \
				sizeof(*__a->ptr), vect_limit(__a));          \
		__a->cap = __c;                                               \
	}                                                                     \
	*vect_at(__a, __a->nmemb++) = __e;                                    \
	(void)0; })

//
//=============================================================================
#define vect_pop(__self, __dest)                                              \
({	__typeof__(__self) __v = (__self);                                    \
	__typeof__(__dest) __d = (__dest);                                    \
	assert(!vect_empty(__v));                                             \
	*__d = *vect_at(__v, --__v->nmemb);                                   \
	(void)0; })

// compare the entry's bytes, allowing a prefix of a vector element
//=============================================================================
#define vect_index(__self, __entry)                                           \
({	__typeof__(__self ) __x = (__self );                                  \
	__typeof__(__entry) __e = (__entry);                                  \
	static_assert(sizeof(__e) <= sizeof(*__x->ptr), "entry too large");   \
	size_t __p = 0;                                                       \
	while (__p < vect_size(__x) &&                                        \
			memcmp(vect_at(__x, __p), &__e, sizeof(__e)))         \
		++__p;                                                        \
	__p == vect_size(__x) ? SIZE_MAX : __p; })

//
//=============================================================================
#define vect_count(__self, __entry)                                           \
({	__typeof__(__self ) __v = (__self );                                  \
	__typeof__(__entry) __e = (__entry);                                  \
	static_assert(sizeof(__e) <= sizeof(*__v->ptr), "entry too large");   \
	size_t __c = 0;                                                       \
	for (size_t __i = 0; __i < vect_size(__v); ++__i)                     \
		if (!memcmp(vect_at(__v, __i), &__e, sizeof(__e)))            \
			++__c;                                                \
	__c; })

//
//=============================================================================
#define vect_insert(__self, __pos, __ent)                                     \
({	__typeof__(__self) __v = (__self);                                    \
	size_t __p = (__pos);                                                 \
	__typeof__(*__v->ptr) __x = (__ent);                                  \
	assert(__p <= vect_size(__v));                                        \
	vect_append(__v, __x);                                                \
	size_t __n = vect_size(__v) - 1 - __p;                                \
	if (__n)                                                              \
		memmove(vect_at(__v, __p + 1), vect_at(__v, __p),             \
				__n * sizeof(*__v->ptr));                     \
	*vect_at(__v, __p) = __x;                                             \
	(void)0; })

//
//=============================================================================
#define vect_remove(__self, __entry)                                          \
({	__typeof__(__self   ) __v = (__self );                                \
	__typeof__(*__v->ptr) __r = (__entry);                                \
	size_t __i = vect_index(__v, __r);                                    \
	if (__i != SIZE_MAX) {                                                \
		size_t __n = vect_size(__v) - __i - 1;                        \
		if (__n)                                                      \
			memmove(vect_at(__v, __i), vect_at(__v, __i + 1),     \
					__n * sizeof(*__v->ptr));             \
		--__v->nmemb;                                                 \
	} })

//
//=============================================================================
#define vect_replace(__self, __pos, __entry)                                  \
({	__typeof__(__self) __v = (__self);                                    \
	size_t __p = (__pos);                                                 \
	__typeof__(*__v->ptr) __e = (__entry);                                \
	assert(__p < vect_size(__v));                                         \
	*vect_at(__v, __p) = __e;                                             \
	(void)0; })

#endif // VECT_H_
