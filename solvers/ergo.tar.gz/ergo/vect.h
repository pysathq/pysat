/*
 * vect.h
 *
 *  Created on: Sep 19, 2011
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef VECT_H_
#define VECT_H_

// system includes:
#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
// local includes:
// local defines:

// local types:
//=============================================================================

struct vect {
	size_t cap;
	size_t nmemb;
	size_t size;
	void *ptr;
};

//
//=============================================================================
static inline void vect_init(struct vect *self, size_t szof)
{
	self->nmemb = 0;
	self->cap   = 4;
	self->size  = szof;
	self->ptr   = malloc(self->size * self->cap);
}

//
//=============================================================================
#define vect_new(__type)                                                      \
({	struct vect __self;                                                   \
	vect_init(&__self, sizeof(__type));                                   \
	__self; })

//
//=============================================================================
#define vect_new_p(__type)                                                    \
({	struct vect *__self = malloc(sizeof(struct vect));                    \
	vect_init(__self, sizeof(__type));                                    \
	__self; })

// makes room for 'n' entries up front, so filling a vector of known size
// doesn't walk the doubling ladder;
//=============================================================================
static inline void vect_reserve(struct vect *self, size_t n)
{
	if (n <= self->cap)
		return;

	self->ptr = realloc(self->ptr, self->size * n);
	self->cap = n;
}

//
//=============================================================================
static inline void vect_destroy(struct vect *self)
{
	free(self->ptr);
}

//
//=============================================================================
static inline void vect_destroy_p(struct vect *self)
{
	vect_destroy(self);
	free(self);
}

//
//=============================================================================
static inline void vect_copy_to(struct vect *self, struct vect *dest)
{
	assert(dest->cap );
	assert(dest->ptr );
	assert(dest->size);

	dest->cap   = self->cap;
	dest->nmemb = self->nmemb;
	dest->size  = self->size;

	dest->ptr = realloc(dest->ptr, dest->size * dest->cap);
	memcpy(dest->ptr, self->ptr, self->size * self->nmemb);
}

//
//=============================================================================
static inline void vect_copy_lazy(struct vect *self, struct vect *dest)
{
	assert(dest->cap );
	assert(dest->ptr );
	assert(dest->size);

	if (dest->cap < self->nmemb)
		dest->ptr = realloc(dest->ptr, self->size * self->nmemb);

	dest->cap  = dest->nmemb = self->nmemb;
	dest->size = self->size;

	memcpy(dest->ptr, self->ptr, self->size * self->nmemb);
}

//
//=============================================================================
static inline bool vect_empty(struct vect *self)
{
	return self->nmemb == 0;
}

//
//=============================================================================
static inline size_t vect_size(struct vect *self)
{
	return self->nmemb;
}

//
//=============================================================================
static inline void vect_shrink(struct vect *self, size_t to)
{
	assert(self->nmemb >= to);
	self->nmemb = to;
}

//
//=============================================================================
static inline void vect_clear(struct vect *self)
{
	vect_shrink(self, 0);
}

//
//=============================================================================
static inline size_t vect_capacity(struct vect *self)
{
	return self->cap;
}

//
//=============================================================================
static inline void *vect_data(struct vect *self)
{
	return self->ptr;
}

//
//=============================================================================
static inline void *vect_at(struct vect *self, size_t pos)
{
	return self->ptr + pos * self->size;
}

// deprecated; use vect_at() instead.
//=============================================================================
#define vect_memb(__self, __type, __pos)                                      \
({	*(__type *)vect_at(__self, __pos); })

//
//=============================================================================
static inline void *vect_begin(struct vect *self)
{
	return self->ptr;
}

//
//=============================================================================
static inline void *vect_end(struct vect *self)
{
	return vect_at(self, vect_size(self));
}

//
//=============================================================================
static inline void *vect_rbegin(struct vect *self)
{
	if (vect_size(self))
		return vect_at(self, vect_size(self) - 1);
	else
		return vect_begin(self);
}

//
//=============================================================================
static inline void *vect_rend(struct vect *self)
{
	return self->ptr - self->size;
}

//
//=============================================================================
static inline void *vect_front(struct vect *self)
{
	return vect_begin(self);
}

//
//=============================================================================
static inline void *vect_back(struct vect *self)
{
	return vect_rbegin(self);
}

//
//=============================================================================
#define vect_append(__self, __ent)                                            \
({	assert(sizeof(__ent) == (__self)->size);                              \
	if ((__self)->nmemb == (__self)->cap) {                               \
		size_t __sz = (__self)->cap * 2;                              \
		(__self)->ptr = realloc((__self)->ptr, (__self)->size * __sz);\
		(__self)->cap = __sz;                                         \
	}                                                                     \
	__typeof(__ent) __obj = (__ent);                                      \
	memcpy(vect_at(__self, (__self)->nmemb++), &__obj, sizeof(__obj)); })

//
//=============================================================================
#define vect_pop(__self, __dest)                                              \
({	assert((__self)->nmemb);                                              \
	assert(sizeof(*(__dest)) == (__self)->size);                          \
	*(__dest) = *(__typeof(*(__dest)) *)vect_back(__self);                \
	vect_shrink(__self, vect_size(__self) - 1); })

// comparison makes use of sizeof(__entry) instead of (__self)->size to enable
// the search to succeed using only some first bytes of the vector elements.
//=============================================================================
#define vect_index(__self, __entry)                                           \
({	__typeof(__entry) __o = (__entry);                                    \
                                                                              \
	size_t __p = 0;                                                       \
	while (__p < vect_size(__self) &&                                     \
			memcmp(vect_at(__self, __p), &__o, sizeof(__entry)))  \
		++__p;                                                        \
                                                                              \
	if (__p == vect_size(__self))                                         \
		__p = -1;                                                     \
	__p; })

//
//=============================================================================
#define vect_count(__s, __ent)                                                \
({	size_t __res = 0;                                                     \
	__typeof(__ent) __obj = (__ent);                                      \
	for (__typeof(__ent) *_e = vect_begin(__s); _e < vect_end(__s); ++_e) \
		if (memcmp(_e, &__obj, sizeof(__ent)) == 0)                   \
			++__res;                                              \
	__res; })

//
//=============================================================================
#define vect_insert(__self, __pos, __ent)                                     \
({	assert((__pos) < (__self)->nmemb);                                    \
	assert(sizeof(__ent) == (__self)->size);                              \
	if ((__self)->nmemb == (__self)->cap) {                               \
		size_t __sz = (__self)->cap * 2;                              \
		(__self)->ptr = realloc((__self)->ptr, (__self)->size * __sz);\
		(__self)->cap = __sz;                                         \
	}                                                                     \
                                                                              \
	for (size_t __i = (__self)->nmemb - 1; __i > (__pos); --__i)          \
		memcpy(vect_at(__self, __i + 1), vect_at(__self, __i),        \
						sizeof(__ent));               \
	__typeof(__ent) __obj = (__ent);                                      \
	memcpy(vect_at(__self, __pos), &__obj, sizeof(__obj)); })

//
//=============================================================================
#define vect_remove(__self, __entry)                                          \
({	assert(sizeof(__entry) == (__self)->size);                            \
	size_t __i = vect_index(__self, __entry);                             \
                                                                              \
	if (__i != -1) {                                                      \
		for (; __i < vect_size(__self) - 1; ++__i)                    \
			memcpy(vect_at(__self, __i), vect_at(__self, __i + 1),\
						sizeof(__entry));             \
                                                                              \
		vect_shrink(__self, vect_size(__self) - 1);                   \
	} })

//
//=============================================================================
#define vect_replace(__self, __pos, __new_entry)                              \
({	assert((__pos) < (__self)->nmemb);                                    \
	assert(sizeof(__new_entry) == (__self)->size);                        \
                                                                              \
	__typeof(__new_entry) __obj = (__new_entry);                          \
	memcpy(vect_at(__self, __pos), &__obj, sizeof(__obj)); })

#endif // VECT_H_
