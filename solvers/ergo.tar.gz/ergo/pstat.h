/*
 * pstat.h
 *
 *  Created on: Jan 22, 2013
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef PSTAT_H_
#define PSTAT_H_

// system includes:
#include <sys/time.h>
#include <sys/resource.h>
// local includes:

// local defines:
//=============================================================================
#if defined(__linux__) || defined(__FreeBSD__) || defined(__FreeBSD_kernel__) || defined(__gnu_hurd__)

# define RUSAGE_MAXRSS_FACTOR 1024

#elif defined(__APPLE__)

# define RUSAGE_MAXRSS_FACTOR (1024 * 1024)

#endif

// local types:
//=============================================================================
enum time_type {
	TTYPE_USER,
	TTYPE_SYS,
	TTYPE_TOTAL
};

//
//=============================================================================
static inline double process_utime_(struct rusage *ru)
{
	return (double)ru->ru_utime.tv_sec + (double)ru->ru_utime.tv_usec / 1000000;
}

//
//=============================================================================
static inline double process_stime_(struct rusage *ru)
{
	return (double)ru->ru_stime.tv_sec + (double)ru->ru_stime.tv_usec / 1000000;
}

//
//=============================================================================
static inline double process_ttime_(struct rusage *ru)
{
	return process_utime_(ru) + process_stime_(ru);
}

//
//=============================================================================
static inline double process_time(enum time_type ttype)
{
	struct rusage ru;
	getrusage(RUSAGE_SELF, &ru);

	switch (ttype) {
	case TTYPE_USER:
		return process_utime_(&ru);
	case TTYPE_SYS:
		return process_stime_(&ru);
	case TTYPE_TOTAL:
		return process_ttime_(&ru);
	default:
		break;
	}

	return 0;
}

//
//=============================================================================
static inline void process_time_both(double *utime, double *stime)
{
	struct rusage ru;
	getrusage(RUSAGE_SELF, &ru);

	*utime = process_utime_(&ru);
	*stime = process_stime_(&ru);
}

//
//=============================================================================
static inline double process_memory_used(void)
{
	struct rusage ru;
	getrusage(RUSAGE_SELF, &ru);

	return (double)ru.ru_maxrss / RUSAGE_MAXRSS_FACTOR;
}

#endif // PSTAT_H_
