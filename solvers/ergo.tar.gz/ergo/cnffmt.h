/*
 * cnffmt.h
 *
 *  Created on: Apr 2, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef CNF_FMT_H_
#define CNF_FMT_H_

// system includes:
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
#include "clset.h"
#include "lit.h"
#include "parse_util.h"
#include "printfd.h"

//
//=============================================================================
static inline int cnffmt_parse_int(char **expr)
{
	int val = 0;
	int neg = 0;

	prsutil_skip_space(expr);

	if (**expr == '-') {
		neg = 1;
		++(*expr);
	}
	else if (**expr == '+')
		++(*expr);

	if (!isdigit(**expr)) {
		printfd("Unexpected char: %c\n", **expr);
		exit(EXIT_FAILURE);
	}

	while (isdigit(**expr)) {
		val = val * 10 + (**expr - '0');
		++(*expr);
	}

	return neg ? -val : val;
}

//
//=============================================================================
static inline void cnffmt_parse_clause(char **expr, struct vect *cl)
{
	vect_shrink(cl, 0);

	for (;;) {
		int i = cnffmt_parse_int(expr);
		if (i == 0)
			break;

		int var = abs(i) - 1;
		vect_append(cl, (i > 0 ? lit_of(var) : lit_neg(lit_of(var))));
	}
}

//
//=============================================================================
static inline void cnffmt_parse_main(char *expr, struct clset *cls)
{
	struct vect cl = vect_new(int);

	for (;;) {
		prsutil_skip_space(&expr);

		if (*expr == '\0')
			break;
		else if (*expr == 'c' || *expr == 'p')
			prsutil_skip_line(&expr);
		else {
			cnffmt_parse_clause(&expr, &cl);
			clset_add(cls, &cl, false);
		}
	}

	vect_destroy(&cl);
}

//
//=============================================================================
static inline void cnffmt_parse(FILE *fp, struct clset *cls)
{
	char *text = prsutil_read_file(fp);
	cnffmt_parse_main(text, cls);
	free(text);
}

#endif /* CNF_FMT_H_ */
