/*
 * arena.h
 *
 *  Created on: Sep 13, 2026
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@monash.edu
 */

#ifndef ARENA_H_
#define ARENA_H_

// system includes:
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
// local includes:
// local defines:

// number of 32-bit words per chunk (must be a power of 2)
#define ARENA_CHUNK_WORDS_LOG2 20
#define ARENA_CHUNK_WORDS      (1u << ARENA_CHUNK_WORDS_LOG2)
#define ARENA_CHUNK_MASK       (ARENA_CHUNK_WORDS - 1)

// fraction of live-vs-garbage words that triggers a compaction
#define ARENA_GC_FRAC 0.5

// local types:
//=============================================================================

// a reference into an arena: a word index shifted left by 1, with bit 0 left
// free for a caller-defined tag (e.g. universe's existing binary-clause tag
// on watcher pointers)
typedef uint32_t aref;

#define AREF_NIL      ((aref) - 1)
#define AREF_TAG      ((aref)   1)
#define AREF_UNTAG(r) ((aref)(r) & ~AREF_TAG)

// one block of raw storage; once allocated, 'mem' never moves or is resized
struct achunk {
	uint32_t *mem;
	uint32_t  used;     // bump high-water mark, in words
	uint32_t  garbage;  // words of 'mem' currently known to be dead
};

// a growable set of chunks, bump-allocated into and, occasionally,
// compacted via reference relocation
struct arena {
	struct achunk *chunks;
	uint32_t       nchunks;
	uint32_t       chunks_cap;
	uint32_t       active;   // index of the chunk currently being bumped into
	uint32_t       used;     // total live+garbage words across all chunks
	uint32_t       garbage;  // total garbage words across all chunks

	// only meaningful between arena_compact_begin() and arena_compact_end()
	struct achunk *old_chunks;
	uint32_t       old_nchunks;
};

//
//=============================================================================
static inline void arena_init(struct arena *self)
{
	self->chunks      = NULL;
	self->nchunks     = 0;
	self->chunks_cap  = 0;
	self->active      = 0;
	self->used        = 0;
	self->garbage     = 0;
	self->old_chunks  = NULL;
	self->old_nchunks = 0;
}

//
//=============================================================================
static inline void arena_destroy(struct arena *self)
{
	for (uint32_t i = 0; i < self->nchunks; ++i)
		free(self->chunks[i].mem);

	free(self->chunks);
	self->chunks  = NULL;
	self->nchunks = self->chunks_cap = 0;
}

// appends a fresh, empty chunk and returns its index
//=============================================================================
static inline uint32_t arena_new_chunk(struct arena *self)
{
	// the new chunk's index still has to fit in an aref
	assert(self->nchunks < (1u << (31 - ARENA_CHUNK_WORDS_LOG2)));

	if (self->nchunks == self->chunks_cap) {
		self->chunks_cap = self->chunks_cap ? self->chunks_cap * 2 : 4;
		self->chunks     = realloc(self->chunks, self->chunks_cap * sizeof(struct achunk));
	}

	struct achunk *c = &self->chunks[self->nchunks];
	c->mem     = malloc(ARENA_CHUNK_WORDS * sizeof(uint32_t));
	c->used    = 0;
	c->garbage = 0;

	return self->nchunks++;
}

//
//=============================================================================
static inline aref arena_encode(uint32_t chunk, uint32_t offset)
{
	return (aref)(((chunk << ARENA_CHUNK_WORDS_LOG2) | offset) << 1);
}

// bump-allocates 'words' from the active chunk, appending a new chunk if
// the active one has no room; the returned reference has its tag bit clear;
//=============================================================================
static inline aref arena_alloc(struct arena *self, int words)
{
	assert((unsigned)words <= ARENA_CHUNK_WORDS);

	if (self->nchunks == 0)
		self->active = arena_new_chunk(self);

	struct achunk *c = &self->chunks[self->active];

	if (c->used + words > ARENA_CHUNK_WORDS) {
		self->active = arena_new_chunk(self);
		c = &self->chunks[self->active];
	}

	aref r = arena_encode(self->active, c->used);
	c->used   += words;
	self->used += words;

	return r;
}

//
//=============================================================================
static inline void *arena_deref(struct arena *self, aref r)
{
	uint32_t idx    = AREF_UNTAG(r) >> 1;
	uint32_t chunk  = idx >> ARENA_CHUNK_WORDS_LOG2;
	uint32_t offset = idx &  ARENA_CHUNK_MASK;

	assert(chunk < self->nchunks);
	return &self->chunks[chunk].mem[offset];
}

// accounts 'words' as garbage; does not reclaim anything by itself; see
// arena_needs_compact()/arena_compact_begin();
//=============================================================================
static inline void arena_free(struct arena *self, int words)
//
//-----------------------------------------------------------------------------
{
	self->garbage += words;
}

// the mirror of arena_free(): credits 'words' back out of 'garbage' when a
// previously-freed slot is reused in place rather than actually reclaimed
//=============================================================================
static inline void arena_unfree(struct arena *self, int words)
{
	self->garbage -= words;
}

//
//=============================================================================
static inline bool arena_needs_compact(struct arena *self)
{
	return self->used > 0 &&
			(double)self->garbage / (double)self->used > ARENA_GC_FRAC;
}

// sets the arena up to receive relocated (still-live) references
//=============================================================================
static inline void arena_compact_begin(struct arena *self)
{
	assert(self->old_chunks == NULL);

	self->old_chunks  = self->chunks;
	self->old_nchunks = self->nchunks;

	self->chunks     = NULL;
	self->nchunks    = 0;
	self->chunks_cap = 0;
	self->active     = 0;
	self->used       = 0;
	self->garbage    = 0;
}

//
//=============================================================================
static inline void *arena_old_deref(struct arena *self, aref r)
{
	uint32_t idx    = AREF_UNTAG(r) >> 1;
	uint32_t chunk  = idx >> ARENA_CHUNK_WORDS_LOG2;
	uint32_t offset = idx &  ARENA_CHUNK_MASK;

	assert(chunk < self->old_nchunks);
	return &self->old_chunks[chunk].mem[offset];
}

// copies one 'old'-chunk object of 'words' words to a fresh location in the
// (new, growing) chunk set and returns its reference
//=============================================================================
static inline aref arena_reloc(struct arena *self, aref old, int words)
{
	assert(self->old_chunks != NULL);

	uint32_t *src  = arena_old_deref(self, old);
	aref      dst  = arena_alloc(self, words);
	uint32_t *dstp = arena_deref(self, dst);

	for (int i = 0; i < words; ++i)
		dstp[i] = src[i];

	return dst;
}

//
//=============================================================================
static inline void arena_compact_end(struct arena *self)
{
	for (uint32_t i = 0; i < self->old_nchunks; ++i)
		free(self->old_chunks[i].mem);

	free(self->old_chunks);
	self->old_chunks  = NULL;
	self->old_nchunks = 0;
}

#endif /* ARENA_H_ */
