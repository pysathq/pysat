/*
 * arena.h
 *
 *  Created on: Sep 13, 2026
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@monash.edu
 */

#ifndef ARENA_H_
#define ARENA_H_

// system includes:
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
// local includes:
// local defines:

// default chunk size in 32-bit words
#define ARENA_CHUNK_WORDS_LOG2 20
#define ARENA_CHUNK_WORDS      (1u << ARENA_CHUNK_WORDS_LOG2)
#define ARENA_CHUNK_MASK       (ARENA_CHUNK_WORDS - 1)

// garbage fraction triggering compaction
#define ARENA_GC_FRAC 0.5

// local types:
//=============================================================================

// reference layout: chunk index | word offset | caller's tag bit
typedef uint32_t aref;

#define AREF_NIL      ((aref) - 1)
#define AREF_TAG      ((aref)   1)
#define AREF_UNTAG(r) ((aref)(r) & ~AREF_TAG)

// fixed storage block
struct achunk {
	uint32_t *mem;
	uint32_t  used;     // allocated words
};

// chunked bump allocator
struct arena {
	struct achunk *chunks;
	uint32_t       nchunks;
	uint32_t       chunks_cap;
	uint32_t       active;   // allocation chunk
	uint64_t       used;     // live + garbage words
	uint64_t       garbage;  // garbage words

	// source chunks during compaction
	struct achunk *old_chunks;
	uint32_t       old_nchunks;
};

//
//=============================================================================
static inline void arena_init(struct arena *self)
{
	self->chunks      = NULL;
	self->nchunks     = 0;
	self->chunks_cap  = 0;
	self->active      = 0;
	self->used        = 0;
	self->garbage     = 0;
	self->old_chunks  = NULL;
	self->old_nchunks = 0;
}

//
//=============================================================================
static inline void arena_destroy(struct arena *self)
{
	for (uint32_t i = 0; i < self->nchunks; ++i)
		free(self->chunks[i].mem);

	free(self->chunks);
	self->chunks  = NULL;
	self->nchunks = self->chunks_cap = 0;
}

// append a chunk and return its index
//=============================================================================
static inline uint32_t arena_new_chunk(struct arena *self, uint32_t words)
{
	// chunk index must fit in an aref
	if (self->nchunks >= (1u << (31 - ARENA_CHUNK_WORDS_LOG2))) {
		fputs("ergo: arena reference space exhausted\n", stderr);
		abort();
	}

	if (self->nchunks == self->chunks_cap) {
		self->chunks_cap = self->chunks_cap ? self->chunks_cap * 2 : 4;
		struct achunk *chunks = realloc(self->chunks, self->chunks_cap * sizeof(struct achunk));
		if (!chunks) {
			fputs("ergo: out of memory allocating arena chunks\n", stderr);
			abort();
		}
		self->chunks = chunks;
	}

	struct achunk *c = &self->chunks[self->nchunks];
	size_t capacity = words > ARENA_CHUNK_WORDS ? words : ARENA_CHUNK_WORDS;
	c->mem     = malloc(capacity * sizeof(uint32_t));
	if (!c->mem) {
		fputs("ergo: out of memory allocating arena storage\n", stderr);
		abort();
	}
	c->used    = 0;

	return self->nchunks++;
}

//
//=============================================================================
static inline aref arena_encode(uint32_t chunk, uint32_t offset)
{
	return (aref)(((chunk << ARENA_CHUNK_WORDS_LOG2) | offset) << 1);
}

// allocate words; oversized objects start at offset 0 in a dedicated chunk
//=============================================================================
static inline aref arena_alloc(struct arena *self, int words)
{
	if (words <= 0) {
		fputs("ergo: invalid arena allocation size\n", stderr);
		abort();
	}

	if (self->nchunks == 0)
		self->active = arena_new_chunk(self, (uint32_t)words);

	struct achunk *c = &self->chunks[self->active];

	if (c->used && (c->used >= ARENA_CHUNK_WORDS ||
			(uint32_t)words > ARENA_CHUNK_WORDS - c->used)) {
		self->active = arena_new_chunk(self, (uint32_t)words);
		c = &self->chunks[self->active];
	}

	aref r = arena_encode(self->active, c->used);
	// reserve NIL, lazy external reasons, and their untagged forms
	if (r >= AREF_NIL - 3) {
		fputs("ergo: arena reference space exhausted\n", stderr);
		abort();
	}
	c->used   += words;
	self->used += words;

	return r;
}

//
//=============================================================================
static inline void *arena_deref(struct arena *self, aref r)
{
	uint32_t idx    = AREF_UNTAG(r) >> 1;
	uint32_t chunk  = idx >> ARENA_CHUNK_WORDS_LOG2;
	uint32_t offset = idx &  ARENA_CHUNK_MASK;

	assert(chunk < self->nchunks);
	return &self->chunks[chunk].mem[offset];
}

// count garbage without reclaiming storage
//=============================================================================
static inline void arena_free(struct arena *self, int words)
//
//-----------------------------------------------------------------------------
{
	assert(words >= 0 && (uint64_t)words <= self->used - self->garbage);
	self->garbage += words;
}

// subtract garbage when reusing a freed slot
//=============================================================================
static inline void arena_unfree(struct arena *self, int words)
{
	assert(words >= 0 && (uint64_t)words <= self->garbage);
	self->garbage -= words;
}

//
//=============================================================================
static inline bool arena_needs_compact(struct arena *self)
{
	return self->used > 0 &&
			(double)self->garbage / (double)self->used > ARENA_GC_FRAC;
}

// retain old chunks and start a fresh arena
//=============================================================================
static inline void arena_compact_begin(struct arena *self)
{
	assert(self->old_chunks == NULL);

	self->old_chunks  = self->chunks;
	self->old_nchunks = self->nchunks;

	self->chunks     = NULL;
	self->nchunks    = 0;
	self->chunks_cap = 0;
	self->active     = 0;
	self->used       = 0;
	self->garbage    = 0;
}

//
//=============================================================================
static inline void *arena_old_deref(struct arena *self, aref r)
{
	uint32_t idx    = AREF_UNTAG(r) >> 1;
	uint32_t chunk  = idx >> ARENA_CHUNK_WORDS_LOG2;
	uint32_t offset = idx &  ARENA_CHUNK_MASK;

	assert(chunk < self->old_nchunks);
	return &self->old_chunks[chunk].mem[offset];
}

// copy an old object into the new arena and return its reference
//=============================================================================
static inline aref arena_reloc(struct arena *self, aref old, int words)
{
	assert(self->old_chunks != NULL);

	uint32_t *src  = arena_old_deref(self, old);
	aref      dst  = arena_alloc(self, words);
	uint32_t *dstp = arena_deref(self, dst);

	for (int i = 0; i < words; ++i)
		dstp[i] = src[i];

	return dst;
}

//
//=============================================================================
static inline void arena_compact_end(struct arena *self)
{
	for (uint32_t i = 0; i < self->old_nchunks; ++i)
		free(self->old_chunks[i].mem);

	free(self->old_chunks);
	self->old_chunks  = NULL;
	self->old_nchunks = 0;
}

#endif /* ARENA_H_ */
