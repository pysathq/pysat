/*
 * parse_util.h
 *
 *  Created on: Apr 18, 2013
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef PARSE_UTIL_H_
#define PARSE_UTIL_H_

// system includes:
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
#include "printfd.h"

//
//=============================================================================
static inline char *prsutil_read_file(FILE *ifp)
{
	char *data = malloc(65536 * sizeof(char));
	int   cap  = 65536;
	int   size = 0;

	while (!feof(ifp)) {
		if (size == cap) {
			cap *= 2;
			data = realloc(data, cap);
		}
		size += fread(&data[size], sizeof(char), 65536, ifp);
	}
	data = realloc(data, size + 1);
	data[size] = '\0';

	return data;
}

//
//=============================================================================
static inline void prsutil_skip_space(char **expr)
{
	while (isspace(**expr))
		++(*expr);
}

//
//=============================================================================
static inline void prsutil_skip_line(char **expr)
{
	for (;;) {
		if (**expr == '\0')
			return;

		if (**expr == '\n') {
			++(*expr);
			return;
		}

		++(*expr);
	}
}

//
//=============================================================================
static inline void prsutil_skip_char(char **expr, char c)
{
	if (**expr != c) {
		printfd("Unexpected char: %c\n", **expr);
		exit(EXIT_FAILURE);
	}
		++(*expr);
}

//
//=============================================================================
static inline void prsutil_skip_word(char **expr, char *word)
{
	while (*word != '\0') {
		if (isspace(**expr) || **expr == '\0' || **expr != *word) {
			printfd("Unexpected char: %c\n", **expr);
			exit(EXIT_FAILURE);
		}

		++(*expr);
		++word;
	}
}

#endif /* PARSE_UTIL_H_ */
