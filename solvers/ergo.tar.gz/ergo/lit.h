/*
 * lit.h
 *
 *  Created on: Jul 12, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef LIT_H_
#define LIT_H_

// system includes:
#include <stdbool.h>
#include <stdio.h>
// local includes:
// local defines:

// local types:
//=============================================================================
typedef char lbool;

// local constants:
//=============================================================================
static const lbool lundef  =  0;
static const lbool ltrue   =  1;
static const lbool lfalse  = -1;

static const int var_undef = -1;
static const int lit_undef = -2;

// literal manipulations
//=============================================================================
static inline int  lit_of   (int v) { return v << 1;                }
static inline int  lit_neg  (int l) { return l  ^ 1;                }
static inline int  lit_var  (int l) { return l >> 1;                }
static inline int  lit_sign (int l) { return l  & 1;                }
static inline int  lit_abs  (int l) { return l  & 0xfffffffe;       }
static inline bool lit_val  (int l) { return l  & 1 ? false : true; }

// literal dumping
//=============================================================================
static inline void lit_dump(int l, FILE *fp)
{
	if (lit_sign(l))
		fprintf(fp, "-");

	fprintf(fp, "%d", lit_var(l) + 1);
}

#endif // LIT_H_
