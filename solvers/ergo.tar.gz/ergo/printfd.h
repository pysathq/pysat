/*
 * printfd.h
 *
 *  Created on: Jul 12, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef PRINTFD_H_
#define PRINTFD_H_

// system includes:
#include <stdio.h>
// local includes:

// local defines:
//=============================================================================

#ifndef NDEBUG

# define printfd(format, ...)                                                 \
({	fprintf(stderr, "Line %d of %s: ", __LINE__, __FILE__);               \
	fprintf(stderr, format, ## __VA_ARGS__); })

#else

# define DEBUG_VOID_CAST (void)
# define printfd(format, ...) (DEBUG_VOID_CAST (0))

#endif // NDEBUG

#endif // PRINTFD_H_
