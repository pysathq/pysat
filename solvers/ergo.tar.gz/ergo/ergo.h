/*
 * ergo.h
 *
 *  Created on: Oct 5, 2026
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@monash.edu
 */

#ifndef SAT_INTERNAL_H_
#define SAT_INTERNAL_H_

// internal solver state and primitives; public interface in api.h
//
// local includes:
#include "arena.h"
#include "bqint.h"
#include "clause.h"
#include "lit.h"
#include "api.h"
#include "vect.h"

// local types:
//=============================================================================

// opaque extension-related structures (see ext.{h,c})
struct ext_cand;
struct ext_hash_slot;
struct ext_def;

struct watcher {
	aref cl;
	int blocker;
};

DECLARE_VECT(watcher_vect, struct watcher, uint32_t);

// solver statistics
struct stats {
	uint64_t starts, decisions, propagations, conflicts;
	uint64_t clauses, clauses_literals, learnts, learnts_literals,
	max_literals, tot_literals;
};

// solver representation
struct ergo {
	int  size;       // number of variables.
	int  cap;        // size of varmaps.
	int  cap_levels; // perm_diff capacity; warm-start dummy levels can exceed nvars
	int  qhead;      // head index of queue.
	int  qtail;      // tail index of queue.
	int  dec_vars;   // number of decision variables.
	bool ok;         // false once the formula is permanently UNSAT
	bool warm_start; // retain the SAT trail and allow clause additions on it
	bool probing;    // suppress propagator notifications during internal probing

	int64_t conflict_budget;    // -1 means no budget.
	int64_t propagation_budget; // -1 means no budget.
	bool    asynch_interrupt;   // interrupt flag polled between decisions

	// clauses; 'clauses' and 'learnts' share 'arena', since watchers and
	// reasons cross-reference both from the same lists/array
	struct arena arena;
	struct clset clauses; // set of problem constraints. (contains: aref)
	struct clset learnts; // set of learnt clauses. (contains: aref)

	// activities
	double *activity;  // heuristic measurement of the activity of a variable.
	int    *polarity;  // default polarity of a variable.
	int    *user_pol;  // user-preferred polarity.
	bool   *dec_var;   // decision variable flag.
	double  var_inc;   // amount to bump next variable with.
	double  var_decay; // INVERSE decay factor for variable activity: stores 1/decay.
	double  cla_inc;   // amount to bump next clause with.
	double  cla_decay; // INVERSE decay factor for clause activity: stores 1/decay.
	float   reduce_by; // Amount of learnt clauses to remove.
	float   rnd_vfreq; // frequency of random decisions.

	// restarts and learntsize params
	bool   restart_arif;
	bool   restart_luby;
	bool   restart_gluc;
	int    restart_first;
	double restart_inc;
	double max_learnts;
	int    min_learnts_lim;

	double learntsize_inc;
	double learntsize_factor;
	int    ls_adjust_start;
	double ls_adjust_confl;
	double ls_adjust_inc;
	int    ls_adjust_cnt;

	struct watcher_vect    *wlists;    //
	struct int_vect         wdirty;
	char                   *wdirt_c;
	aref                   *reasons;   // AREF_NIL if the variable has none
	lbool                  *assigns;   // current values of variables.
	struct int_vect         order;     // variable order. (heap) (contains: var)
	int                    *orderpos;  // index in variable order.
	int                    *levels;    //
	int                    *trail;
	struct int_vect         trail_lim; // separator indices for different decision levels in 'trail'. (contains: int)

	char                   *tags;      //
	struct int_vect         tagged;    // (contains: var)
	struct int_vect         stack_i;   // (contains: var)
	struct int_vect         stack_p;   // (contains: lit)

	struct int_vect         assumps;   // vector containing user assumptions.
	struct char_vect        model;     // if problem is satisfiable, this vector contains the model (contains: lbool).
	struct int_vect         conflict;  // if problem is unsatisfiable, this vector contains conflicting assumptions (contains: int).
	FILE *proof_trace;

	// IPASIR-UP: NULL means no propagator connected
	struct ergo_propagator *propagator;
	bool                   *observed;                 // [cap], variables reported to the propagator
	int                     notified;                 // first unreported trail index
	struct int_vect         notify_buf;               // assignment notification buffer
	bool                    notify_backtrack_pending; // backtrack notification deferred until ergo_assume()
	struct int_vect         external_units;           // pending external unit facts (contains: lit)

	// statistics
	struct stats stat;
	int          simpdb_assigns; // number of top-level assignments at last 'simplifyDB()'.
	int          simpdb_props;   // number of propagations before next 'simplifyDB()'.
	double       progress_estimate;

	int verbosity;
	int phase_saving;
	int ccmin_mode;
	bool jw_acty;
	bool jw_polar;
	bool jw_hard;
	bool keep_bin;
	bool remove_satisfied;
	bool no_copy;

	// fields backported from glucose
	// constants for managing restarts
	double   restart_gluc_fr;  // restart force ratio
	double   restart_gluc_br;  // restart block ratio
	double   lbd_queue_sz;
	double   trail_queue_sz;
	// constants for reduce DB
	int      reducedb_first;
	int      reducedb_limit;
	int      reducedb_inc;
	int      reducedb_inc_extra;
	int      reducedb_at;
	bool     reducedb_gluc;
	unsigned frozencl_lbd_lb;
	// constants for reducing clause
	int      ccmin_sz_lb;
	int      ccmin_lbd_lb;
	uint64_t curr_start;
	uint32_t magic_counter;
	// adaptive strategy switching and the permanent (chanseok) clause pool
	bool     adapt;          // whether to evaluate the strategy switch
	uint64_t adapt_at;       // conflict count at which it's evaluated (once)
	bool     permanent_mode; // permanent low-lbd pool active
	unsigned perm_lbd_lb;    // lbd bound below which learnts are kept forever
	bool     lcm;            // vivify learnts (LCM) at each return to decision level 0

	struct bqint   trail_queue;
	struct bqint   lbd_queue;
	float lbd_sum;

	unsigned *perm_diff;
	struct int_vect last_level;
	bool glucose_bump;

	// --ext candidate-pair mining/eviction machinery -- see ext.h's
	// top-of-file comment for the full design;
	bool                   ext;
	struct ext_cand       *ext_cands;         // [EXT_CAND_CAP], dense pool
	int                   *ext_cand_free;     // [EXT_CAND_CAP] free-list of recycled record ids
	int                    ext_cand_nfree;
	int                   *ext_cand_heap;     // [EXT_CAND_CAP] min-heap of record ids, by activity
	double                *ext_cand_heap_act; // activity indexed by heap position
	int                    ext_cand_heap_sz;
	int                   *ext_cand_heap_pos; // [EXT_CAND_CAP] record id -> heap position, -1 if untracked
	struct ext_hash_slot  *ext_cand_hash;     // [EXT_HASH_CAP]
	int                    ext_cand_hash_dead;
	double                 ext_cand_inc;      // VSIDS-style growing bump, see ext_cand_bump()
	uint64_t               ext_rewrites;      // diagnostic only -- cumulative pairs rewritten
	int                    ext_orig_nvars;    // diagnostic only -- nvars() just before
						  // the first-ever rewrite, -1 if none yet

	// per-solver mining tuning, defaulted from #defines in ext_init(),
	// overridable via ergo_setxthreshold/warmup/escalate();
	double                 ext_threshold;
	int64_t                ext_warmup;
	double                 ext_escalate;

	// rewriting requires equivalence; without rewriting, new names are pinned
	bool                   ext_rewrite;
	bool                   ext_equiv;

	// mine only pairs whose variables are both in scope, unless ext_scope_all
	bool                   ext_scope_all;
	bool                  *ext_scope;     // [cap], parallel to 'observed'

	// external-propagator reason flag; independent of extension mining
	bool                  *ext_reason;    // [cap], parallel to 'observed'

	// growable (la,lb) -> z registry; entries leave when z retires
	struct ext_hash_slot  *ext_var_hash;      // [ext_var_hash_cap]
	int                    ext_var_hash_cap;  // power of two
	int                    ext_var_hash_live;
	int                    ext_var_hash_dead;

	// extension definitions: la != lit_undef marks a live definition;
	// individual clause references may be AREF_NIL for permanent facts
	struct ext_def        *ext_defs;         // [cap]

	// currently-live extension variables -- for incremental PySAT use
	struct int_vect         ext_active;       // of int, 0-based var ids

	// retired extension-variable ids available for reuse by the next
	// promotion instead of growing nvars() forever;
	struct int_vect         ext_free_vars;    // of int, 0-based var ids

	// variables whose refcount just dropped to 0 (ergo_ext_die());
	struct int_vect         ext_zero_pending; // of int, 0-based var ids
};

// local functions prototypes:
//=============================================================================

extern void  ergo_trace_vect    (struct int_vect *, bool, FILE *);
extern int   ergo_dlevel        (struct ergo *s);
extern aref  ergo_new_cl        (struct ergo *s, struct int_vect *c, bool lf);
extern void  ergo_remove_cl     (struct ergo *s, aref clr);
extern bool  ergo_enqueue       (struct ergo *s, int l, aref from);
extern void  ergo_rescale_act_v (struct ergo *s);
extern void  ergo_set_dvar      (struct ergo *s, int var);
extern void  order_unassign    (struct ergo *s, int v);
extern void  ergo_clean_wlist   (struct ergo *s, int l);
extern void  ergo_clean_wlists  (struct ergo *s);
extern void  ergo_compact       (struct ergo *s);
extern int   ergo_lit_to_dimacs (int l);
extern int   ergo_dimacs_to_lit (int d);
extern void  ergo_init_var      (struct ergo *s, int var);
extern aref  ergo_propagate     (struct ergo *s);

#endif // SAT_INTERNAL_H_
