/*
 * cli.c
 *
 *  Created on: Apr 2, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

// system includes:
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
#include "ext.h"
#include "iread.h"
#include "options.h"
#include "owrite.h"
#include "pstat.h"
#include "api.h"
#include "ergo.h"
#include "ergodbg.h"

struct ergo        *solver_ref;
struct readin     *ri_ref = NULL; // NULL until main() has opened the input
struct writeout   *wo_ref = NULL; // NULL until main() has opened the proof trace

//
//=============================================================================
void print_version(bool as_comment)
{
	printf("%sErgo SAT solver\n", as_comment ? "c " : "");
	printf("%sCopyright (C) 2011-2026 Alexey Ignatiev, FIT, "
		"Monash University, Australia\n", as_comment ? "c " : "");
	printf("%s\n", as_comment ? "c " : "");

	printf("%sVersion:  %s\n", as_comment ? "c " : "", RELEASE);
	printf("%sReleased: %s\n", as_comment ? "c " : "", RELEASE_DATE);
	printf("%sCompiled: %s\n", as_comment ? "c " : "", COMPILE_DATE);
	printf("%sPlatform: %s\n", as_comment ? "c " : "", OS_NAME);
	printf("%sCompiler: %s\n", as_comment ? "c " : "", COMPILER);
	printf("%sCompiler options: %s\n",  as_comment ? "c " : "",
		COMP_OPTS);
	printf("%s", as_comment ? "c\n" : "");
}

//
//=============================================================================
void print_stats(struct stats *stat)
{
	double t = process_time(TTYPE_USER);
	double m = process_memory_used();

	printf("c Restarts          : %12u\n", (unsigned)(stat->starts));
	printf("c Conflicts         : %12.0f           (%9.0f / sec      )\n",
			(double)stat->conflicts,
			(double)stat->conflicts / t);
	printf("c Decisions         : %12.0f           (%9.0f / sec      )\n",
			(double)stat->decisions,
			(double)stat->decisions / t);
	printf("c Propagations      : %12.0f           (%9.0f / sec      )\n",
			(double)stat->propagations,
			(double)stat->propagations / t);
	printf("c Conflict literals : %12.0f           (%9.2f %% deleted  )\n",
			(double)stat->tot_literals,
			(double)(stat->max_literals - stat->tot_literals) * 100.0 /
			(double)stat->max_literals);
	printf("c Memory used       : %12.2f MB\n", m);
	printf("c CPU time          : %12.6f sec\nc\n", t);
}

//
//=============================================================================
void signal_handler(int signal)
{
	// handling only SIGINT and SIGTERM
	printf("\nc Caught SIG%s\n", signal == 2 ? "INT" : "TERM");

	if (solver_ref->verbosity)
		print_stats(&solver_ref->stat);

	printf("s INDETERMINATE\n");

	// ri_ref/wo_ref are still NULL if the signal arrived before main()
	// had finished opening them (e.g. during option parsing) -- nothing
	// to close in that case
	if (ri_ref)
		ri_close(ri_ref);
	if (wo_ref)
		wo_close(wo_ref);

	ergo_delete(solver_ref);

	exit(EXIT_SUCCESS);
}

//
//=============================================================================
static inline void bind_signal_handler(void)
{
	signal(SIGINT,  signal_handler);
	signal(SIGTERM, signal_handler);
}

//
//=============================================================================
static inline void set_emulation_mode(struct options* opt, char *mode)
{
	if (strcmp(mode, "m2.0") == 0) {
		if (!opt->cla_decay_set)
			opt->cla_decay = 0.999;
		if (!opt->var_decay_set)
			opt->var_decay = 0.95;

		if (!opt->restart_inc_set)
			opt->restart_inc  = 1.5;
		if (!opt->restart_policy_set) {
			opt->restart_policy = realloc(opt->restart_policy, 5 * sizeof(char));
			strcpy(opt->restart_policy, "geom");
		}

		if (!opt->ccmin_mode_set)
			opt->ccmin_mode   = 2;
		if (!opt->phase_saving_set)
			opt->phase_saving = 0;

		opt->keep_binary = true;
	}
	else if (strcmp(mode, "m2.2") == 0) {
		if (!opt->cla_decay_set)
			opt->cla_decay = 0.999;
		if (!opt->var_decay_set)
			opt->var_decay = 0.95;

		if (!opt->restart_inc_set)
			opt->restart_inc  = 2.0;
		if (!opt->restart_policy_set) {
			opt->restart_policy = realloc(opt->restart_policy, 5 * sizeof(char));
			strcpy(opt->restart_policy, "luby");
		}

		if (!opt->ccmin_mode_set)
			opt->ccmin_mode   = 2;
		if (!opt->phase_saving_set)
			opt->phase_saving = 2;

		opt->keep_binary = true;
	}
	else if (strcmp(mode, "g3") == 0) {
		if (!opt->cla_decay_set)
			opt->cla_decay = 0.999;
		if (!opt->var_decay_set)
			opt->var_decay = 0.8;

		if (!opt->restart_inc_set)
			opt->restart_inc  = 2.0;
		if (!opt->restart_policy_set) {
			opt->restart_policy = realloc(opt->restart_policy, 5 * sizeof(char));
			strcpy(opt->restart_policy, "gluc");
		}
		if (!opt->reducedb_policy_set) {
			opt->reducedb_policy = realloc(opt->reducedb_policy, 11 * sizeof(char));
			strcpy(opt->reducedb_policy, "aggressive");
		}

		if (!opt->ccmin_mode_set)
			opt->ccmin_mode   = 2;
		if (!opt->phase_saving_set)
			opt->phase_saving = 2;

		opt->glucose_bump = true;
	}
	else if (strcmp(mode, "g4.2") == 0) {
		if (!opt->cla_decay_set)
			opt->cla_decay = 0.999;
		if (!opt->var_decay_set)
			opt->var_decay = 0.8;

		if (!opt->restart_inc_set)
			opt->restart_inc  = 2.0;
		if (!opt->restart_policy_set) {
			opt->restart_policy = realloc(opt->restart_policy, 5 * sizeof(char));
			strcpy(opt->restart_policy, "gluc");
		}
		if (!opt->reducedb_policy_set) {
			opt->reducedb_policy = realloc(opt->reducedb_policy, 11 * sizeof(char));
			strcpy(opt->reducedb_policy, "aggressive");
		}

		if (!opt->ccmin_mode_set)
			opt->ccmin_mode   = 2;
		if (!opt->phase_saving_set)
			opt->phase_saving = 2;

		opt->glucose_bump = true;

		// glucose 4.2.1 defaults its own LCM ('opt_lcm') to on
		opt->lcm = true;

		// glucose 4.2.1 defaults to evaluating the adaptive strategy
		// switch at 100000 conflicts (its 'adapt' option is on by
		// default) -- see solvers/glucose421/core/Solver.cc:117
		if (!opt->adapt_at_set) {
			opt->adapt_at = realloc(opt->adapt_at, 7 * sizeof(char));
			strcpy(opt->adapt_at, "100000");
		}
	}
}

//
//=============================================================================
void parse_options(
	int argc,
	char *argv[],
	struct ergo *s,
	struct readin *ri_obj,
	struct writeout *wo_obj
)
{
	struct options *opt = opt_new();

	if (opt_parse(opt, argc, argv) == false || opt->help) {
		opt_usage(stdout, argv[0]);
		opt_del(opt);
		exit(EXIT_SUCCESS);
	}

	if (opt->version) {
		print_version(false);
		opt_del(opt);
		exit(EXIT_SUCCESS);
	}

	// emulating minisat 2.0, minisat 2.2, or whatnot
	if (strcmp(opt->emulate, "none"))
		set_emulation_mode(opt, opt->emulate);

	// --ext only gets a real chance to nest extension variables
	// (z from (la,lb), then w from (z,y), and so on) if it gets many
	// restarts to work with -- the default geometric schedule spaces
	// restarts out increasingly widely, starving it after the first few;
	// default to glucose-style restarts when auto-mining is on, same as
	// set_emulation_mode()'s own presets do, but respect an explicit
	// --rpolicy if the user gave one.
	if (opt->ext && !opt->restart_policy_set) {
		opt->restart_policy = realloc(opt->restart_policy, 5 * sizeof(char));
		strcpy(opt->restart_policy, "gluc");
	}

	// variable and clause decays
	s->cla_decay = 1 / opt->cla_decay;
	s->var_decay = 1 / opt->var_decay;

	// restart strategy
	if (!strcmp(opt->restart_policy, "luby")) {
		s->restart_arif = false;
		s->restart_gluc = false;
		s->restart_luby = true;
	}
	else if (!strcmp(opt->restart_policy, "arif")) {
		s->restart_arif = true;
		s->restart_gluc = false;
		s->restart_luby = false;
	}
	else if (!strcmp(opt->restart_policy, "gluc")) {
		s->restart_arif = false;
		s->restart_gluc = true;
		s->restart_luby = false;
	}
	else {
		s->restart_arif = false;
		s->restart_gluc = false;
		s->restart_luby = false;
	}

	s->restart_first   = opt->restart_first;
	s->restart_inc     = opt->restart_inc;
	s->min_learnts_lim = opt->min_learnts;

	// other options
	s->keep_bin     = opt->keep_binary;
	s->lcm          = opt->lcm;
	s->no_copy      = opt->no_copy;
	s->verbosity    = opt->verbose;
	s->ccmin_mode   = opt->ccmin_mode;
	s->phase_saving = opt->phase_saving;
	s->reduce_by    = opt->reduce_by;

	if (!strcmp(opt->reducedb_policy, "aggressive"))
		s->reducedb_gluc = true;

	if (opt->glucose_bump)
		s->glucose_bump  = true;

	if (opt->ext)
		ergo_xenable(s, true);

	if (strcmp(opt->adapt_at, "never")) {
		s->adapt    = true;
		s->adapt_at = atoi(opt->adapt_at);
	}

	// starting polarity strategy
	if (strcmp(opt->jw_mode, "none")) {
		// choosing JW mode
		if (!strcmp(opt->jw_mode, "act"))
			s->jw_acty = true;
		else if (!strcmp(opt->jw_mode, "pol-soft"))
			s->jw_polar = true;
		else if (!strcmp(opt->jw_mode, "pol-hard"))
			s->jw_polar = s->jw_hard = true;
		else if (!strcmp(opt->jw_mode, "full-soft"))
			s->jw_acty = s->jw_polar = true;
		else if (!strcmp(opt->jw_mode, "full-hard"))
			s->jw_acty = s->jw_polar = s->jw_hard = true;
	}

	*ri_obj = ri_open(opt->restc ? opt->restv[0] : NULL);

	// turning proof tracing on
	if (opt->proof_trace[0])
		*wo_obj = wo_open(opt->proof_trace);
	else
		*wo_obj = wo_null();

	ergo_set_proof(s, wo_obj->wo_fp);

	opt_del(opt);
}

//
//=============================================================================
int main(int argc, char *argv[])
{
	setbuf(stdout, NULL);

	// linking to a termination handler
	bind_signal_handler();

	// making solver
	struct ergo *s = solver_ref = ergo_new();

	// parsing options
	struct readin   ri_obj;  // input formula
	struct writeout wo_obj;  // proof trace
	parse_options(argc, argv, s, &ri_obj, &wo_obj);
	ri_ref = &ri_obj;
	wo_ref = &wo_obj;

	if (s->verbosity)
		print_version(true);

	// loading formula
	if (ergo_load_formula(s, ri_obj.ri_fp) == false) {
		printf("c Solved by unit propagation\ns UNSATISFIABLE\n");

		ri_close(&ri_obj);
		wo_close(&wo_obj);
		ri_ref = NULL; // closed already -- a signal from here on has nothing to do
		wo_ref = NULL;
		ergo_delete(s);

		exit(20);  // formula is unsatisfiable
	}

	// solving
	ergo_set_dvars_all(s);
	// ergo_bump_first(s, 64);

	// Jeroslow-Wang heuristic is expensive to apply within `solve()`
	if (s->jw_acty || s->jw_polar)
		ergo_set_jwmode(s);

	bool res = ergo_solve(s, NULL);

	if (s->verbosity)
		print_stats(&s->stat);

	printf(res == true ? "s SATISFIABLE\n" : "s UNSATISFIABLE\n");

	// print the sat assignment or proof
	if (s->verbosity > 1 && res == true) {
		printf("c\n");
		ergo_print_model(s);
	}

	// check the sat assignment
	if (res == true)
		dbg_check_model(s, ri_obj.ri_fp);

	ri_close(&ri_obj);
	wo_close(&wo_obj);
	ri_ref = NULL; // closed already -- a signal from here on has nothing to do
	wo_ref = NULL;
	ergo_delete(s);

	exit(res == true ? 10 : 20);
}
