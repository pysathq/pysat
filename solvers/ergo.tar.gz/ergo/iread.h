/*
 * iread.h
 *
 *  Created on: Feb 2, 2013
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef IREAD_H_
#define IREAD_H_

// system includes:
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
// local defines:

// local types:
//=============================================================================

enum iread_type {
	READ_REGULAR,
	READ_STDIN,
	READ_PIPE
};

struct readin {
	FILE *ri_fp;
	enum iread_type ri_type;
};

//
//=============================================================================
static inline bool ri_exists(char *name)
{
	FILE *fp = fopen(name, "r");

	if (fp == NULL)
		return false;

	fclose(fp);
	return true;
}

//
//=============================================================================
static inline struct readin ri_open(char *name)
{
	struct readin fobj = { .ri_fp = stdin, .ri_type = READ_STDIN };

	if (name) {
		if (ri_exists(name) == false)
			goto ri_error;

		size_t len = strlen(name);
		char arc_cmd[len + 20]; memset(arc_cmd, 0, len + 20);

		if (len >= 3 && !strcmp(name + len - 3, ".gz"))
			sprintf(arc_cmd, "gunzip -c %s", name);
		else if (len >= 4 && !strcmp(name + len - 4, ".bz2"))
			sprintf(arc_cmd, "bzcat %s", name);
		else if (len >= 5 && !strcmp(name + len - 5, ".lzma"))
			sprintf(arc_cmd, "lzcat %s", name);
		else if (len >= 3 && !strcmp(name + len - 3, ".xz"))
			sprintf(arc_cmd, "xzcat %s", name);

		if (arc_cmd[0]) {
			fobj.ri_fp   = popen(arc_cmd, "r");
			fobj.ri_type = READ_PIPE;
		}
		else {
			fobj.ri_fp   = fopen(name, "r");
			fobj.ri_type = READ_REGULAR;
		}

		if (fobj.ri_fp == NULL)
			goto ri_error;
	}

	return fobj;

	ri_error:
		fprintf(stderr, "ERROR! Could not open file: %s\n", name);
		exit(EXIT_FAILURE);
}

//
//=============================================================================
static inline struct readin ri_open_pipe(char *name, char *cmd)
{
	struct readin fobj = { .ri_fp = NULL, .ri_type = READ_PIPE };

	if (name) {
		if (ri_exists(name) == false)
			goto ri_file_error;

		if (cmd && cmd[0]) {
			char cmd_full[strlen(cmd) + strlen(name) + 2];

			strcpy(cmd_full, cmd);
			strcat(cmd_full, " ");
			strcat(cmd_full, name);

			fobj.ri_fp = popen(cmd_full, "r");
		}

		if (fobj.ri_fp == NULL)
			goto ri_pipe_error;
	}

	return fobj;

	ri_file_error:
		fprintf(stderr, "ERROR! Could not open file: %s\n", name);
		exit(EXIT_FAILURE);

	ri_pipe_error:
		fprintf(stderr, "ERROR! Could not create pipe: %s\n", cmd);
		exit(EXIT_FAILURE);
}

//
//=============================================================================
static inline void ri_close(struct readin *fobj)
{
	switch (fobj->ri_type) {
	case READ_REGULAR:
		fclose(fobj->ri_fp);
		break;
	case READ_PIPE:
		pclose(fobj->ri_fp);
		break;
	default: // READ_STDIN
		break;
	}
}

#endif // IREAD_H_
