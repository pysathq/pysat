/*
 * clause.h
 *
 *  Created on: Jul 12, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef CLAUSE_H_
#define CLAUSE_H_

// system includes:
#include <stdbool.h>
#include <stdio.h>
// local includes:
#include "arena.h"
#include "lit.h"
#include "vect.h"
// local defines:

// local types:
//=============================================================================

// clause representation
struct clause {
	struct {
		unsigned mark     : 2;
		unsigned learnt   : 1;
		unsigned reloced  : 1;
		unsigned lbd      : 24;
		unsigned ext      : 1; // has an extension-variable literal
		unsigned needed   : 1;
		unsigned vivified : 1;
		unsigned has_acty : 1; // useful for when a learnt clause
				       // is "promoted" to the permanent pool
		unsigned size     : 32;
		unsigned idx      : 32; // this clause's aref's position in
					// its owning clset's 'ptrs' array
	} header;
	int lits[];
};

// dumping format
enum oformat {
	FMT_SIMPLE,
	FMT_DIMACS,
	FMT_BF
};

//
//=============================================================================
static inline int cl_size(struct clause *self)
{
	return self->header.size;
}

//
//=============================================================================
static inline bool cl_empty(struct clause *self)
{
	return cl_size(self) == 0;
}

// total 32-bit words a clause of 'nlits' literals occupies in the arena
//=============================================================================
static inline int cl_words(int nlits, bool has_acty)
{
	return (int)(sizeof(struct clause) / sizeof(int)) + nlits + (has_acty ? 1 : 0);
}

//
//=============================================================================
static inline int *cl_begin(struct clause *self)
{
	return self->lits;
}

//
//=============================================================================
static inline int *cl_end(struct clause *self)
{
	return self->lits + cl_size(self);
}

//
//=============================================================================
static inline int cl_at(struct clause *self, int pos)
{
	return self->lits[pos];
}

//
//=============================================================================
static inline int cl_learnt(struct clause *self)
{
	return self->header.learnt;
}

// whether this clause's slot reserves a trailing activity word
//=============================================================================
static inline bool cl_has_acty(struct clause *self)
{
	return self->header.has_acty;
}

//
//=============================================================================
static inline int cl_marked(struct clause *self)
{
	return self->header.mark;
}

//
//=============================================================================
static inline int cl_mark(struct clause *self)
{
	return self->header.mark += 1;
}

//
//=============================================================================
static inline bool cl_reloced(struct clause *self)
{
	return self->header.reloced;
}

// only meaningful once cl_reloced() is true
//=============================================================================
static inline aref cl_relocation(struct clause *self)
{
	return *(aref *)&self->lits[0];
}

// marks a clause for relocation
//=============================================================================
static inline void cl_relocate(struct clause *self, aref to)
{
	self->header.reloced = 1;
	*(aref *)&self->lits[0] = to;
}

//
//=============================================================================
static inline unsigned cl_lbd(struct clause *self)
{
	return self->header.lbd;
}

//
//=============================================================================
static inline void cl_relbd(struct clause *self, unsigned lbd)
{
	self->header.lbd = lbd;
}

//
//=============================================================================
static inline bool cl_ext(struct clause *self)
{
	return self->header.ext;
}

//
//=============================================================================
static inline void cl_setext(struct clause *self, bool ext)
{
	self->header.ext = ext;
}

//
//=============================================================================
static inline bool cl_needed(struct clause *self)
{
	return self->header.needed;
}

//
//=============================================================================
static inline void cl_setlearnt(struct clause *self, bool learnt)
{
	self->header.learnt = learnt;
}

//
//=============================================================================
static inline void cl_setneeded(struct clause *self, bool needed)
{
	self->header.needed = needed;
}

//
//=============================================================================
static inline unsigned cl_idx(struct clause *self)
{
	return self->header.idx;
}

//
//=============================================================================
static inline void cl_setidx(struct clause *self, unsigned idx)
{
	self->header.idx = idx;
}

//
//=============================================================================
static inline bool cl_vivified(struct clause *self)
{
	return self->header.vivified;
}

//
//=============================================================================
static inline void cl_setvivified(struct clause *self, bool vivified)
{
	self->header.vivified = vivified;
}

//
//=============================================================================
static inline float cl_get_acty(struct clause *self)
{
	assert(self->header.learnt);
	return *((float *)&self->lits[cl_size(self)]);
}

//
//=============================================================================
static inline void cl_set_acty(struct clause *self, float a)
{
	assert(self->header.learnt);
	*((float *)&self->lits[cl_size(self)]) = a;
}

//
//=============================================================================
static inline int cl_compare_acty_g(const void *cl1, const void *cl2)
{
	int sz1 = cl_size(*(void **)cl1);
	int sz2 = cl_size(*(void **)cl2);

	if (sz1 == 2)
		return  1;
	if (sz1  > 2 && sz2 == 2)
		return -1;

	float act1 = cl_get_acty(*(void **)cl1);
	float act2 = cl_get_acty(*(void **)cl2);

	unsigned lbd1 = cl_lbd(*(void **)cl1);
	unsigned lbd2 = cl_lbd(*(void **)cl2);

	return lbd1 > lbd2 || (lbd1 == lbd2 && act1 < act2) ? -1 : 1;
}

//
//=============================================================================
static inline int cl_compare_acty_b(const void *cl1, const void *cl2)
{
	int sz1 = cl_size(*(void **)cl1);
	int sz2 = cl_size(*(void **)cl2);

	float act1 = cl_get_acty(*(void **)cl1);
	float act2 = cl_get_acty(*(void **)cl2);

	return sz1 > 2 && (sz2 == 2 || act1 < act2) ? -1 : 1;
}

//
//=============================================================================
static inline int cl_compare_acty(const void *cl1, const void *cl2)
{
	float act1 = cl_get_acty(*(void **)cl1);
	float act2 = cl_get_acty(*(void **)cl2);

	return (act1 > act2) - (act1 < act2);
}

// fills everything but 'lits'; useful when a caller needs write the literals
// on its own, in place, instead of copying them in;
//=============================================================================
static inline void cl_init_hdr(struct clause *self, size_t n, bool learnt)
{
	self->header.size     = n;
	self->header.mark     = 0;
	self->header.learnt   = learnt;
	self->header.reloced  = 0;
	self->header.lbd      = 0;
	self->header.ext      = 0;
	self->header.needed   = 0;
	self->header.vivified = 0;
	self->header.has_acty = learnt;
	self->header.idx      = 0; // set for real by the caller's clset_add()

	if (learnt)
		*((float *)&self->lits[n]) = 0.0;
}

//
//=============================================================================
static inline void cl_init(struct clause *self, struct vect *lits, bool learnt)
{
	memcpy(self->lits, lits->ptr, sizeof(int) * vect_size(lits));
	cl_init_hdr(self, vect_size(lits), learnt);
}

//
//=============================================================================
static inline void cl_shrink(struct clause *self, int new_sz)
{
	if (self->header.has_acty)
		*((float *)&self->lits[new_sz]) = cl_get_acty(self);

	self->header.size = new_sz;
}

//
//=============================================================================
static inline void cl_litvect_ref(struct clause *self, struct vect *dest)
{
	assert(dest->cap );
	assert(dest->ptr );
	assert(dest->size);

	dest->cap   = cl_size (self);
	dest->nmemb = cl_size (self);
	dest->ptr   = cl_begin(self);
	dest->size  = sizeof  (int);
}

//
//=============================================================================
static inline void cl_litvect_copy(struct clause *self, struct vect *dest)
{
	assert(dest->cap );
	assert(dest->ptr );
	assert(dest->size);

	dest->cap   = cl_size(self);
	dest->nmemb = cl_size(self);
	dest->size  = sizeof (int);

	dest->ptr = realloc(dest->ptr, dest->size * dest->cap);
	memcpy(dest->ptr, self->lits, dest->size * dest->nmemb);
}

//
//=============================================================================
static inline void cl_dump(struct clause* self, enum oformat fmt, FILE *fp)
{
	char *delim = "", *last = "";

	if (fmt == FMT_DIMACS)
		last = " 0";
	else if (fmt == FMT_BF)
		delim = " v";

	int *l = self->lits, i = 0;

	for (; i < self->header.size - 1; ++i) {
		lit_dump(l[i], fp);
		fprintf(fp, "%s ", delim);
	}
	lit_dump(l[i], fp);
	fprintf(fp, "%s\n", last);
}

#endif // CLAUSE_H_
