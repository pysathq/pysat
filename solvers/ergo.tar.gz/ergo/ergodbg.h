/*
 * ergodbg.h
 *
 *  Created on: Apr 4, 2011
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef ERGODBG_H_
#define ERGODBG_H_

// system includes:
#include <stdio.h>
// local includes:
// local defines:
// local types:

#ifndef NDEBUG

struct clause;
enum oformat;
struct ergo;
struct vect;

extern void dbg_print_vect         (struct vect *, enum oformat, FILE *);
extern void dbg_print_clauses      (struct ergo *, enum oformat, FILE *);
extern void dbg_write_clauses      (struct ergo *, char *);
extern void dbg_print_learnts      (struct ergo *, enum oformat, FILE *);
extern void dbg_write_learnts      (struct ergo *, char *);
extern void dbg_print_reason       (struct ergo *, int, FILE *, int);
extern void dbg_enqueue_reason     (struct ergo *, int, int *, int **, int *, int *);
extern void dbg_print_backtrace    (struct ergo *, int, FILE *);
extern int  dbg_check_enqueue_part (struct ergo *, int);
extern void dbg_check_model        (struct ergo *, FILE *);

#else

# define DEBUG_VOID_CAST (void)

# define dbg_print_vect(a, b, c)           (DEBUG_VOID_CAST (0))
# define dbg_print_clauses(a, b, c)        (DEBUG_VOID_CAST (0))
# define dbg_write_clauses(a, b)           (DEBUG_VOID_CAST (0))
# define dbg_print_learnts(a, b, c)        (DEBUG_VOID_CAST (0))
# define dbg_write_learnts(a, b)           (DEBUG_VOID_CAST (0))
# define dbg_print_reason(a, b, c, d)      (DEBUG_VOID_CAST (0))
# define dbg_enqueue_reason(a, b, c, d, e) (DEBUG_VOID_CAST (0))
# define dbg_print_backtrace(a, b, c)      (DEBUG_VOID_CAST (0))
# define dbg_check_enqueue_part(a, b)      (DEBUG_VOID_CAST (0))
# define dbg_check_model(a, b)             (DEBUG_VOID_CAST (0))

#endif // NDEBUG

// CaDiCaL-style trace
#ifdef LOGGING

struct ergo;

extern void ergo_log(struct ergo *, const char *, ...);
# define LOG(s, ...) ergo_log((s), __VA_ARGS__)

extern void ergo_log_begin(struct ergo *);

#else

# ifndef DEBUG_VOID_CAST
#  define DEBUG_VOID_CAST (void)
# endif

# define LOG(s, ...) (DEBUG_VOID_CAST (0))

#endif // LOGGING

#endif // ERGODBG_H_

