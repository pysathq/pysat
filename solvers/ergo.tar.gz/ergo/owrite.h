/*
 * owrite.h
 *
 *  Created on: Mar 31, 2014
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef OWRITE_H_
#define OWRITE_H_

// system includes:
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
#include "uniqfn.h"
// local defines:

// local types:
//=============================================================================

enum write_type {
	WRITE_NULL,
	WRITE_REGULAR,
	WRITE_STDOUT,
	WRITE_PIPE
};

struct writeout {
	FILE *wo_fp;
	enum write_type wo_type;
};

//
//=============================================================================
static inline struct writeout wo_null()
{
	return (struct writeout){ .wo_fp = NULL, .wo_type = WRITE_NULL };
}

//
//=============================================================================
static inline struct writeout wo_open(char *name)
{
	struct writeout fobj = { .wo_fp = stdout, .wo_type = WRITE_STDOUT };

	if (name) {
		fobj.wo_fp   = fopen(name, "w");
		fobj.wo_type = WRITE_REGULAR;

		if (fobj.wo_fp == NULL)
			goto wo_error;
	}

	return fobj;

	wo_error:
		fprintf(stderr, "ERROR! Could not open file: %s\n", name);
		exit(EXIT_FAILURE);
}

//
//=============================================================================
static inline struct writeout wo_open_uniq(char *beg, char *ext)
{
	char *name = get_unique_filename(beg, ext);
	struct writeout fobj = wo_open(name);

	free(name);  // name is not freed if wo_open() calls exit()
	return fobj;
}

//
//=============================================================================
static inline struct writeout wo_open_pipe(char *cmd)
{
	struct writeout fobj = { .wo_fp = NULL, .wo_type = WRITE_PIPE };

	if (cmd) {
		fobj.wo_fp = popen(cmd, "w");

		if (fobj.wo_fp == NULL)
			goto wo_error;
	}

	return fobj;

	wo_error:
		fprintf(stderr, "ERROR! Could not create pipe: %s\n", cmd);
		exit(EXIT_FAILURE);
}

//
//=============================================================================
static inline void wo_close(struct writeout *fobj)
{
	switch (fobj->wo_type) {
	case WRITE_REGULAR:
		fclose(fobj->wo_fp);
		break;
	case WRITE_PIPE:
		pclose(fobj->wo_fp);
		break;
	default: // WRITE_STDOUT or WRITE_NULL
		break;
	}
}

#endif // OWRITE_H_
