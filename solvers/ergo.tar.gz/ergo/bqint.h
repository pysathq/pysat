/*
 * bqint.h
 *
 * Description: 8byte integer bounded queue
 *  Created on: May 23, 2015
 *      Author: Alexey Ignatiev
 *      E-mail: aignatiev@ciencias.ulisboa.pt
 */

#ifndef BQINT_H_
#define BQINT_H_

// system includes:
#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
// local includes:
// local defines:

// local types:
//=============================================================================

struct bqint {
	size_t cap;
	size_t nmemb;
	size_t first;
	size_t last;
	size_t sumof;
	size_t *ptr;
};

//
//=============================================================================
static inline void bqint_init(struct bqint *self, size_t cap)
{
	self->cap   = cap;
	self->nmemb = 0;
	self->first = 0;
	self->last  = 0;
	self->sumof = 0;
	self->ptr   = calloc(self->cap, sizeof(size_t));
}

//
//=============================================================================
static inline struct bqint *bqint_new(size_t cap)
{
	struct bqint *self = malloc(sizeof(struct bqint));
	bqint_init(self, cap);

	return self;
}

//
//=============================================================================
static inline void bqint_destroy(struct bqint *self)
{
	if (self->ptr)
		free(self->ptr);
}

//
//=============================================================================
static inline void bqint_delete(struct bqint *self)
{
	if (self) {
		bqint_destroy(self);
		free(self);
	}
}

//
//=============================================================================
static inline size_t bqint_size(struct bqint *self)
{
	return self->nmemb;
}

//
//=============================================================================
static inline size_t bqint_cap(struct bqint *self)
{
	return self->cap;
}

//
//=============================================================================
static inline bool bqint_isfull(struct bqint *self)
{
	return self->cap == self->nmemb;
}

//
//=============================================================================
static inline void bqint_shrink(struct bqint *self, size_t to)
{
	assert(self->nmemb >= to);

	self->nmemb = to;
	self->last  = to;
}

//
//=============================================================================
static inline void bqint_clear(struct bqint *self)
{
	bqint_shrink(self, 0);

	self->first = 0;
	self->sumof = 0;
}

//
//=============================================================================
static inline size_t bqint_getsum(struct bqint *self)
{
	return self->sumof;
}

//
//=============================================================================
static inline size_t bqint_getavg(struct bqint *self)
{
	return self->sumof / self->nmemb;
}

//
//=============================================================================
static inline size_t bqint_peek(struct bqint *self)
{
	return self->ptr[self->last];
}

//
//=============================================================================
static inline void bqint_push(struct bqint *self, size_t elem)
{
	if (self->nmemb == self->cap) {
		assert(self->last == self->first);
		self->sumof -= self->ptr[self->last];

		if (++(self->last) == self->cap)
			self->last = 0;
	} else
		self->nmemb++;

	self->sumof           += elem;
	self->ptr[self->first] = elem;

	if (++(self->first) == self->cap)
		self->first = self->last = 0;
}

//
//=============================================================================
static inline void bqint_pop(struct bqint *self)
{
	self->sumof -= self->ptr[self->last];
	self->nmemb--;

	if (++(self->last) == self->cap)
		self->last = 0;
}

#endif // BQINT_H_
