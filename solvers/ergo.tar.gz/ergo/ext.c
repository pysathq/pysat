/*
 * ext.c
 *
 *  Created on: Oct 5, 2026
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@monash.edu
 */

// system includes:
#include <stdint.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
// local includes:
#include "ext.h"
#include "ergo.h"
#include "ergodbg.h"

// candidate-pair mining machinery; see ext.h's top-of-file comment
// for the full design (including a pseudocode and an example);
//=============================================================================
#define EXT_MAX_LEARNT_FOR_MINING  48

// tuning constants for automatic mining.
#define EXT_PROMOTE_THRESHOLD      60    // co-occurrences before a pair
                                         // self-registers (lifetime count,
                                         // separate from decayed 'activity')
#define EXT_WARMUP_CONFLICTS       1500  // conflicts to let pass unmined
                                         // before mining starts at all

// raise the promotion threshold as the number of rewrites grows
#define EXT_ESCALATE_UNIT          10000 // effective threshold = base *
                                         // (1 + ext_rewrites/this)

#define EXT_CAND_CAP                4096 // max not-yet-promoted pairs tracked at once
#define EXT_HASH_CAP               16384 // power of two, >= 4x EXT_CAND_CAP to keep
                                         // probe sequences short between rebuilds
#define EXT_HASH_MASK (EXT_HASH_CAP - 1)
#define EXT_REHASH_DEAD             4096 // rebuild the hash index once tombstones
                                         // reach this many

// forward declaration: tombstones (la,lb) out of 's->ext_var_hash'
static void ext_var_delete(struct ergo *s, int la, int lb);

// removes 'v' from 's->ext_active' (swap-with-last).
//=============================================================================
static void ergo_ext_active_remove(struct ergo *s, int v)
{
	int pos      = s->ext_defs[v].active_pos;
	int last_idx = (int)vect_size(&s->ext_active) - 1;
	int last_var = *(int *)vect_at(&s->ext_active, (size_t)last_idx);

	if (pos != last_idx) {
		*(int *)vect_at(&s->ext_active, (size_t)pos) = last_var;
		s->ext_defs[last_var].active_pos = pos;
	}

	vect_shrink(&s->ext_active, (size_t)last_idx);
}

// mark dying (refc = -1); keep the name registered until physical removal
//=============================================================================
void ergo_ext_die(struct ergo *s, int v)
{
	struct ext_def *d = &s->ext_defs[v];

	d->refc = -1;

	vect_append(&s->ext_zero_pending, v);
}

//
//=============================================================================
void ext_init(struct ergo *s)
{
	s->ext_scope  = NULL;
	s->ext_defs   = NULL;

	s->ext           = false;
	s->ext_rewrites       = 0;
	s->ext_orig_nvars     = -1;

	s->ext_threshold      = EXT_PROMOTE_THRESHOLD;
	s->ext_warmup         = EXT_WARMUP_CONFLICTS;
	s->ext_escalate       = EXT_ESCALATE_UNIT;

	s->ext_rewrite        = true;
	s->ext_equiv          = true;

	s->ext_scope_all = true;

	// allocate lazily in ergo_xenable()
	s->ext_cands          = NULL;
	s->ext_cand_free      = NULL;
	s->ext_cand_heap      = NULL;
	s->ext_cand_heap_act  = NULL;
	s->ext_cand_heap_pos  = NULL;
	s->ext_cand_hash      = NULL;
	s->ext_cand_nfree     = 0;
	s->ext_cand_heap_sz   = 0;

	s->ext_var_hash       = NULL; // grown lazily, see ext_var_insert()
	s->ext_var_hash_cap   = 0;
	s->ext_var_hash_live  = 0;
	s->ext_var_hash_dead  = 0;
	s->ext_cand_hash_dead = 0;
	s->ext_cand_inc       = 1;

	vect_init(&s->ext_active);
	vect_init(&s->ext_free_vars);
	vect_init(&s->ext_zero_pending);
}

// discard formula-specific extension state, retaining tuning and scope
//=============================================================================
void ext_reset(struct ergo *s)
{
	vect_clear(&s->ext_active      );
	vect_clear(&s->ext_free_vars   );
	vect_clear(&s->ext_zero_pending);

	s->ext_rewrites      = 0;
	s->ext_orig_nvars    = -1;
	s->ext_cand_inc      = 1;
	s->ext_cand_heap_sz  = s->ext_cand_hash_dead = 0;
	s->ext_var_hash_live = s->ext_var_hash_dead  = 0;

	for (int i = 0; i < s->ext_var_hash_cap; ++i)
		s->ext_var_hash[i].la = var_undef;

	for (int i = 0; i < EXT_CAND_CAP; ++i) {
		s->ext_cand_free[i] = i;
		s->ext_cand_heap_pos[i] = -1;
	}

	for (int i = 0; i < EXT_HASH_CAP; ++i)
		s->ext_cand_hash[i].la = var_undef;

	s->ext_cand_nfree = EXT_CAND_CAP;
	for (int v = 0; v < s->size; ++v) {
		bool scoped = s->ext_scope[v];
		ext_init_var(s, v);
		s->ext_scope[v] = scoped;
	}
}

// grows the per-variable ext arrays to 's->cap'
//=============================================================================
void ext_grow_vars(struct ergo *s)
{
	if (s->ext_scope)
		s->ext_scope = realloc(s->ext_scope, s->cap * sizeof(bool));
	if (s->ext) {
		if (!s->ext_scope)
			s->ext_scope = calloc(s->cap, sizeof(bool));
		s->ext_defs = realloc(s->ext_defs, s->cap * sizeof(struct ext_def));
	}
}

//
//=============================================================================
void ext_destroy(struct ergo *s)
{
	free(s->ext_cands        );
	free(s->ext_cand_free    );
	free(s->ext_cand_heap    );
	free(s->ext_cand_heap_act);
	free(s->ext_cand_heap_pos);
	free(s->ext_cand_hash    );
	free(s->ext_var_hash     );

	vect_destroy(&s->ext_active      );
	vect_destroy(&s->ext_free_vars   );
	vect_destroy(&s->ext_zero_pending);

	free(s->ext_scope);
	free(s->ext_defs );
}

//
//=============================================================================
static uint32_t ext_hash(int la, int lb, uint32_t mask)
{
	uint32_t h = (uint32_t)la * 2654435761u;
	h ^= (uint32_t)lb * 2246822519u;
	h ^= h >> 15;
	return h & mask;
}

// find a matching or empty slot; tombstones do not end a probe
//=============================================================================
static struct ext_hash_slot *ext_find_slot(struct ext_hash_slot *table,
		uint32_t mask, int la, int lb)
{
	uint32_t h = ext_hash(la, lb, mask);

	while (table[h].la != var_undef && !(table[h].la == la && table[h].lb == lb))
		h = (h + 1) & mask;

	return &table[h];
}

//
//=============================================================================
static void ext_hash_rebuild(struct ergo *s)
{
	for (int i = 0; i < EXT_HASH_CAP; ++i)
		s->ext_cand_hash[i].la = var_undef;
	s->ext_cand_hash_dead = 0;

	for (int i = 0; i < s->ext_cand_heap_sz; ++i) {
		int rec = s->ext_cand_heap[i];
		struct ext_cand *c = &s->ext_cands[rec];

		uint32_t h = ext_hash(c->la, c->lb, EXT_HASH_MASK);
		while (s->ext_cand_hash[h].la != var_undef)
			h = (h + 1) & EXT_HASH_MASK;

		s->ext_cand_hash[h] = (struct ext_hash_slot){ c->la, c->lb, rec };
	}
}

// -1 if 'la','lb' (already normalized la <= lb) isn't currently tracked
//=============================================================================
static int ext_hash_find(struct ergo *s, int la, int lb)
{
	struct ext_hash_slot *slot = ext_find_slot(s->ext_cand_hash, EXT_HASH_MASK, la, lb);
	return slot->la == var_undef ? -1 : slot->rec;
}

//
//=============================================================================
static void ext_hash_insert(struct ergo *s, int la, int lb, int rec)
{
	uint32_t h = ext_hash(la, lb, EXT_HASH_MASK);
	while (s->ext_cand_hash[h].la != var_undef)
		h = (h + 1) & EXT_HASH_MASK;

	s->ext_cand_hash[h] = (struct ext_hash_slot){ la, lb, rec };
}

//
//=============================================================================
static void ext_hash_delete(struct ergo *s, int la, int lb)
{
	struct ext_hash_slot *slot = ext_find_slot(s->ext_cand_hash, EXT_HASH_MASK, la, lb);
	assert(slot->la != var_undef);
	slot->la = lit_undef;
	s->ext_cand_hash_dead++;
}

// growable (la,lb) -> z registry for live extension variables
//=============================================================================
static int ext_var_find(struct ergo *s, int la, int lb)
{
	if (!s->ext_var_hash_cap)
		return lit_undef;
	if (la > lb) { int t = la; la = lb; lb = t; }

	struct ext_hash_slot *slot = ext_find_slot(s->ext_var_hash,
			(uint32_t)(s->ext_var_hash_cap - 1), la, lb);
	return slot->la == var_undef ? lit_undef : slot->rec;
}

// rebuilds the table, dropping every tombstone;
// 'new_cap' lets the caller grow or hold steady in the same pass;
//=============================================================================
static void ext_var_hash_rebuild(struct ergo *s, int new_cap)
{
	int old_cap = s->ext_var_hash_cap;
	struct ext_hash_slot *old = s->ext_var_hash;

	s->ext_var_hash_cap = new_cap;
	s->ext_var_hash = malloc((size_t)new_cap * sizeof(struct ext_hash_slot));
	for (int i = 0; i < new_cap; ++i)
		s->ext_var_hash[i].la = var_undef;

	uint32_t mask = (uint32_t)(new_cap - 1);
	for (int i = 0; i < old_cap; ++i)
		if (old[i].la != var_undef && old[i].la != lit_undef) {
			uint32_t h = ext_hash(old[i].la, old[i].lb, mask);
			while (s->ext_var_hash[h].la != var_undef)
				h = (h + 1) & mask;
			s->ext_var_hash[h] = old[i];
		}
	free(old);
	s->ext_var_hash_dead = 0;
}

//
//=============================================================================
static void ext_var_insert(struct ergo *s, int la, int lb, int zlit)
{
	if (la > lb) { int t = la; la = lb; lb = t; }

	if (s->ext_var_hash_cap == 0 ||
			(s->ext_var_hash_live + s->ext_var_hash_dead) * 2 >= s->ext_var_hash_cap) {
		int old_cap = s->ext_var_hash_cap;
		// still mostly live (not just garbage tombstones) -- actually grow;
		// otherwise a same-size compaction is enough to make room again;
		int new_cap = old_cap == 0 ? 1024
				: s->ext_var_hash_live * 2 >= old_cap ? old_cap * 2 : old_cap;
		ext_var_hash_rebuild(s, new_cap);
	}

	uint32_t mask = (uint32_t)(s->ext_var_hash_cap - 1);
	uint32_t h = ext_hash(la, lb, mask);
	while (s->ext_var_hash[h].la != var_undef)
		h = (h + 1) & mask;
	s->ext_var_hash[h] = (struct ext_hash_slot){ la, lb, zlit };
	s->ext_var_hash_live++;
}

// tombstone the pair so it can be mined again
//=============================================================================
static void ext_var_delete(struct ergo *s, int la, int lb)
{
	if (la > lb) { int t = la; la = lb; lb = t; }

	struct ext_hash_slot *slot = ext_find_slot(s->ext_var_hash,
			(uint32_t)(s->ext_var_hash_cap - 1), la, lb);
	assert(slot->la != var_undef);
	slot->la = lit_undef;
	s->ext_var_hash_live--;
	s->ext_var_hash_dead++;
}

// substitute named pairs in lits[start..n) to a fixed point;
// start = 1 preserves an asserting literal
//=============================================================================
void ergo_ext_subst(struct ergo *s, struct int_vect *lits, size_t start)
{
	if (!s->ext_var_hash_cap || !s->ext_rewrite)
		return;

	bool again = true;
	while (again) {
		again = false;
		int *l = vect_begin(lits);
		size_t n = vect_size(lits);

		for (size_t i = start; i < n && !again; ++i)
			for (size_t j = i + 1; j < n; ++j) {
				int zlit = ext_var_find(s, l[i], l[j]);
				if (zlit < 0) // none, or the caller's blocked pair
					continue;

				l[i] = zlit;
				l[j] = l[n - 1];
				vect_shrink(lits, n - 1);
				again = true;
				break;
			}
	}
}

// indexed min-heap over 'ext_cands[]', ordered by 'activity';
// same shape as order_percolate_up/down for VSIDS;
//=============================================================================
static void ext_cand_heap_up(struct ergo *s, int i)
{
	int *heap = s->ext_cand_heap;
	double *act = s->ext_cand_heap_act;
	int  x    = heap[i];
	double value = act[i];

	while (i != 0) {
		int parent = (i - 1) / 2;
		if (act[parent] <= value)
			break;

		act[i] = act[parent];
		heap[i] = heap[parent];
		s->ext_cand_heap_pos[heap[i]] = i;
		i = parent;
	}

	act[i] = value;
	heap[i] = x;
	s->ext_cand_heap_pos[x] = i;
}

//
//=============================================================================
static void ext_cand_heap_down(struct ergo *s, int i)
{
	int *heap = s->ext_cand_heap;
	double *act = s->ext_cand_heap_act;
	int  sz   = s->ext_cand_heap_sz;
	int  x    = heap[i];
	double value = act[i];

	for (;;) {
		int child = 2 * i + 1;
		if (child >= sz)
			break;
		if (child + 1 < sz &&
				act[child + 1] < act[child])
			++child;
		if (value <= act[child])
			break;

		act[i] = act[child];
		heap[i] = heap[child];
		s->ext_cand_heap_pos[heap[i]] = i;
		i = child;
	}

	act[i] = value;
	heap[i] = x;
	s->ext_cand_heap_pos[x] = i;
}

// remove from hash and heap, then recycle the record
//=============================================================================
static void ext_cand_remove_at(struct ergo *s, int pos)
{
	int rec = s->ext_cand_heap[pos];

	ext_hash_delete(s, s->ext_cands[rec].la, s->ext_cands[rec].lb);

	int last = --s->ext_cand_heap_sz;
	s->ext_cand_heap_pos[rec] = -1;
	if (pos != last) {
		s->ext_cand_heap_act[pos] = s->ext_cand_heap_act[last];
		s->ext_cand_heap[pos] = s->ext_cand_heap[last];
		s->ext_cand_heap_pos[s->ext_cand_heap[pos]] = pos;
		// the record moved into 'pos' could belong either above or below
		// its new spot; try both, only one will ever actually move it
		ext_cand_heap_down(s, pos);
		ext_cand_heap_up  (s, pos);
	}

	s->ext_cand_free[s->ext_cand_nfree++] = rec;
}

//
//=============================================================================
static void ext_cand_insert(struct ergo *s, int la, int lb, double weight)
{
	int rec = s->ext_cand_free[--s->ext_cand_nfree];

	// rebuild before adding rec to the heap to avoid indexing it twice
	if (s->ext_cand_hash_dead >= EXT_REHASH_DEAD)
		ext_hash_rebuild(s);

	s->ext_cands[rec] = (struct ext_cand){ .la = la, .lb = lb,
			.count = weight };

	int pos = s->ext_cand_heap_sz++;
	s->ext_cand_heap[pos] = rec;
	s->ext_cand_heap_act[pos] = s->ext_cand_inc;
	ext_cand_heap_up(s, pos);

	ext_hash_insert(s, la, lb, rec);
}

//
//=============================================================================
static void ext_cand_rescale(struct ergo *s)
{
	for (int i = 0; i < s->ext_cand_heap_sz; ++i)
		s->ext_cand_heap_act[i] *= 1e-100;
	s->ext_cand_inc *= 1e-100;
}

// VSIDS-style bump: grows 'activity' by the current increment, rescaling
// on overflow like ergo_bump_var();
//=============================================================================
static void ext_cand_bump(struct ergo *s, int rec)
{
	int pos = s->ext_cand_heap_pos[rec];

	s->ext_cand_heap_act[pos] += s->ext_cand_inc;
	if (s->ext_cand_heap_act[pos] > 1e100)
		ext_cand_rescale(s);

	ext_cand_heap_down(s, pos);
}

#define EXT_CAND_DECAY_INV (1.0 / 0.95) // matches var_decay's own default

// bumps (la,lb)'s tracking record
//=============================================================================
static void ergo_ext_mine(struct ergo *s, int la, int lb, double weight)
{
	if (la > lb) { int t = la; la = lb; lb = t; }

	// already extended (propagated independently of this mining path);
	// nothing to do, it already has a 'z'.
	if (ext_var_find(s, la, lb) != lit_undef)
		return;

	int rec = ext_hash_find(s, la, lb);

	if (rec < 0) {
		if (s->ext_cand_nfree == 0) {
			// evict only if the new occurrence outweighs the weakest candidate
			if (s->ext_cand_inc <= s->ext_cand_heap_act[0])
				return;
			ext_cand_remove_at(s, 0);
		}
		ext_cand_insert(s, la, lb, weight);
		LOG(s, "extmine %d %d", ergo_lit_to_dimacs(la), ergo_lit_to_dimacs(lb));
		return;
	}

	ext_cand_bump(s, rec);
	s->ext_cands[rec].count += weight;
}

// true iff 'var' is eligible for mining
//=============================================================================
static inline bool ext_in_scope(struct ergo *s, int var)
{
	return s->ext_scope_all || s->ext_scope[var];
}

// mine scoped pairs: inverse level-gap weight, or unit weight for assumptions
//=============================================================================
void ergo_ext_mine_cl(struct ergo *s, int *lits, size_t n, size_t start)
{
	// filter by scope before the quadratic pair scan
	int    in[EXT_MAX_LEARNT_FOR_MINING];
	size_t m = 0;

	for (size_t i = start; i < n; ++i)
		if (ext_in_scope(s, lit_var(lits[i]))) {
			// Bound the quadratic work by eligible literals. A long
			// clause can still carry a small, useful scoped pair.
			if (m == EXT_MAX_LEARNT_FOR_MINING)
				return;
			in[m++] = lits[i];
		}

	for (size_t i = 0; i < m; ++i)
		for (size_t j = i + 1; j < m; ++j) {
			int vi = lit_var(in[i]), vj = lit_var(in[j]);
			int gap = abs(s->levels[vi] - s->levels[vj]);

			// skip same-level pairs
			if (!gap)
				continue;

			// use unit weight for two assumption decisions: their level gap
			// reflects input order, not search distance
			int nas = (int)vect_size(&s->assumps);
			bool au = s->reasons[vi] == AREF_NIL && s->levels[vi] <= nas;
			bool av = s->reasons[vj] == AREF_NIL && s->levels[vj] <= nas;

			ergo_ext_mine(s, in[i], in[j],
					(au && av) ? 1.0 : 1.0 / (double)gap);
		}
}

//
//=============================================================================
void ergo_ext_mine_learnt(struct ergo *s, struct int_vect *learnt)
{
	s->ext_cand_inc *= EXT_CAND_DECAY_INV; // once per conflict, mirroring
	                                        // ergo_decay_act_v()'s cadence
	// rescale even if no pairs were bumped, before the increment overflows
	if (s->ext_cand_inc > 1e100)
		ext_cand_rescale(s);

	if (s->stat.conflicts < (uint64_t)s->ext_warmup)
		return;

	ergo_ext_mine_cl(s, vect_begin(learnt), vect_size(learnt), 0);
}

// turn the extension mode on; fixed at setup time
//=============================================================================
void ergo_xenable(struct ergo *s, bool on)
{
	assert(!s->ext);
	s->ext = on;

	if (on) {
		ext_grow_vars(s);
		for (int v = 0; v < s->size; ++v) {
			bool scoped = s->ext_scope[v];
			ext_init_var(s, v);
			s->ext_scope[v] = scoped;
		}

		s->ext_cands         = malloc(EXT_CAND_CAP * sizeof(struct ext_cand));
		s->ext_cand_free     = malloc(EXT_CAND_CAP * sizeof(int));
		s->ext_cand_heap     = malloc(EXT_CAND_CAP * sizeof(int));
		s->ext_cand_heap_act = malloc(EXT_CAND_CAP * sizeof(double));
		s->ext_cand_heap_pos = malloc(EXT_CAND_CAP * sizeof(int));
		s->ext_cand_hash     = malloc(EXT_HASH_CAP * sizeof(struct ext_hash_slot));

		for (int i = 0; i < EXT_CAND_CAP; ++i) {
			s->ext_cand_free[i]     = i;
			s->ext_cand_heap_pos[i] = -1;
		}

		for (int i = 0; i < EXT_HASH_CAP; ++i)
			s->ext_cand_hash[i].la = var_undef;

		s->ext_cand_nfree = EXT_CAND_CAP;
	}
}

//
//=============================================================================
void ergo_setxthreshold(struct ergo *s, double val)
{
	s->ext_threshold = val;
}

//
//=============================================================================
void ergo_setxwarmup(struct ergo *s, int64_t val)
{
	s->ext_warmup = val;
}

//
//=============================================================================
void ergo_setxescalate(struct ergo *s, double val)
{
	s->ext_escalate = val;
}

// disabling rewriting pins newly promoted names instead
//=============================================================================
void ergo_setxrewrite(struct ergo *s, bool on)
{
	s->ext_rewrite = on && s->ext_equiv;
}

// disabling equivalence omits z -> (la v lb) and disables rewriting
//=============================================================================
void ergo_setxequiv(struct ergo *s, bool on)
{
	s->ext_equiv = on;

	if (!on)
		s->ext_rewrite = false;
}

// remove out-of-scope extension variables to a fixed point
//=============================================================================
static void ext_scope_cascade(struct ergo *s)
{
	assert(!s->ext_scope_all); // or every test below is trivially true

	bool again = true;
	while (again) {
		again = false;

		for (size_t i = 0; i < vect_size(&s->ext_active); ++i) {
			int             v = *(int *)vect_at(&s->ext_active, i);
			struct ext_def *d = &s->ext_defs[v];

			if (!ext_in_scope(s, v))
				continue;
			if (ext_in_scope(s, lit_var(d->la)) ||
					ext_in_scope(s, lit_var(d->lb)))
				continue;

			s->ext_scope[v] = false;
			again = true;
		}
	}
}

//
//=============================================================================
void ergo_setxscope(struct ergo *s, struct int_vect *add, struct int_vect *rem)
{
	size_t nadd = vect_size (add),  nrem = vect_size (rem);
	int   *ap   = vect_begin(add), *rp   = vect_begin(rem);

#ifndef NDEBUG
	for (size_t i = 0; i < nadd; ++i)
		for (size_t j = 0; j < nrem; ++j)
			assert(ap[i] != rp[j]); // the two must not overlap
#endif

	if (!nadd && !nrem) {
		s->ext_scope_all = true;
		if (!s->ext_scope)
			return;
		for (int v = 0; v < s->size; ++v)
			s->ext_scope[v] = false;
		return;
	}

	if (!s->ext_scope)
		s->ext_scope = calloc(s->cap, sizeof(bool));
	if (s->ext_scope_all && nrem) {
		for (int v = 0; v < s->size; ++v)
			s->ext_scope[v] = true;
	}
	s->ext_scope_all = false;

	for (size_t i = 0; i < nrem; ++i) {
		assert(rp[i] < s->size);
		s->ext_scope[rp[i]] = false;
	}

	for (size_t i = 0; i < nadd; ++i) {
		assert(ap[i] < s->size);
		s->ext_scope[ap[i]] = true;
	}

	if (nrem)
		ext_scope_cascade(s);
}

// walks the whole registry and then the heap, keeping what 'mark' selects
// ('mark' NULL keeps everything); indexed by literal, so polarity counts
//=============================================================================
static void ext_xpairs_dump(struct ergo *s, struct xpair_vect *out, const bool *mark)
{
	for (size_t i = 0; i < vect_size(&s->ext_active); ++i) {
		int             v = *(int *)vect_at(&s->ext_active, i);
		struct ext_def *d = &s->ext_defs[v];

		if (d->refc < 0 || (mark && !(mark[d->la] && mark[d->lb])))
			continue;

		vect_append(out, ((struct ergo_xpair){
					.la = ergo_lit_to_dimacs(d->la),
					.lb = ergo_lit_to_dimacs(d->lb),
					.z  = ergo_lit_to_dimacs(d->zlit),
					.count = 0.0 }));
	}

	for (int i = 0; i < s->ext_cand_heap_sz; ++i) {
		struct ext_cand *c = &s->ext_cands[s->ext_cand_heap[i]];

		if (mark && !(mark[c->la] && mark[c->lb]))
			continue;

		vect_append(out, ((struct ergo_xpair){
					.la = ergo_lit_to_dimacs(c->la),
					.lb = ergo_lit_to_dimacs(c->lb),
					.z  = 0,
					.count = c->count }));
	}
}

// reports the one pair (la,lb), promoted or candidate, if it is tracked
//=============================================================================
static void ext_xpairs_one(struct ergo *s, struct xpair_vect *out, int da, int db)
{
	if (abs(da) > s->size || abs(db) > s->size)
		return; // the caller may ask about ids it has not handed over yet

	int la = ergo_dimacs_to_lit(da);
	int lb = ergo_dimacs_to_lit(db);

	if (la > lb) { int t = la; la = lb; lb = t; }

	int zl = ext_var_find(s, la, lb);

	// the orientation the dump reports, so the two paths stay swappable
	int da_ = ergo_lit_to_dimacs(la), db_ = ergo_lit_to_dimacs(lb);

	// a name whose last reference is gone is already spoken for: its id is
	// on its way back to the pool, exactly as the dump's 'refc' test says
	if (zl >= 0 && s->ext_defs[lit_var(zl)].refc >= 0) {
		vect_append(out, ((struct ergo_xpair){ .la = da_, .lb = db_,
					.z = ergo_lit_to_dimacs(zl), .count = 0.0 }));
		return;
	}

	int rec = s->ext ? ext_hash_find(s, la, lb) : -1;

	if (rec >= 0)
		vect_append(out, ((struct ergo_xpair){ .la = da_, .lb = db_,
					.z = 0, .count = s->ext_cands[rec].count }));
}

// report named pairs first, then candidates ranked by count;
// of restricts results to the supplied literals
//=============================================================================
void ergo_xpairs(struct ergo *s, struct xpair_vect *out, struct int_vect *of)
{
	vect_clear(out);

	if (!of) {
		ext_xpairs_dump(s, out, NULL);
		return;
	}

	if (!s->size)
		return; // nothing is tracked yet, so nothing can be asked about

	size_t n = vect_size(of);

	// probing 'of' pairwise costs C(n,2) lookups and dumping costs the
	// registry plus the heap -- take whichever is the smaller of the two
	if (n * (n - 1) / 2 > vect_size(&s->ext_active) + (size_t)s->ext_cand_heap_sz) {
		bool *mark = calloc(2 * (size_t)s->size, sizeof(bool));
		int  *lp   = vect_begin(of);

		for (size_t i = 0; i < n; ++i)
			if (abs(lp[i]) <= s->size)
				mark[ergo_dimacs_to_lit(lp[i])] = true;

		ext_xpairs_dump(s, out, mark);
		free(mark);
		return;
	}

	int *lp = vect_begin(of);

	for (size_t i = 0; i < n; ++i)
		for (size_t j = i + 1; j < n; ++j) {
			assert(lp[i] != lp[j]); // or the pair comes back twice
			ext_xpairs_one(s, out, lp[i], lp[j]);
		}
}

// an extra reference, held on the caller's behalf: the refcount can no
// longer fall to 0, so these variables never retire / die;
//=============================================================================
void ergo_xpin(struct ergo *s, struct int_vect *vars)
{
	if (!s->ext)
		return;
	int *vp = vect_begin(vars);

	for (size_t i = 0; i < vect_size(vars); ++i) {
		assert(vp[i] < s->size);
		struct ext_def *d = &s->ext_defs[vp[i]];

		if (d->la != lit_undef && d->refc >= 0)
			d->refc++;
	}
}

// release pins; each variable must have been pinned previously
//=============================================================================
void ergo_xunpin(struct ergo *s, struct int_vect *vars)
{
	if (!s->ext)
		return;
	int *vp = vect_begin(vars);

	for (size_t i = 0; i < vect_size(vars); ++i) {
		assert(vp[i] < s->size);
		struct ext_def *d = &s->ext_defs[vp[i]];

		if (d->la != lit_undef && d->refc > 0 && --d->refc == 0)
			ergo_ext_die(s, vp[i]);
	}
}

// scans one clause pool for every live clause containing both 'la' and 'lb',
// replacing each with (clause \ {la,lb}) U {zlit};
//=============================================================================
static void ergo_ext_rewrite_pool(struct ergo *s, struct clset *pool, int la, int lb, int zlit)
{
	size_t n = clset_size(pool);
	if (!n)
		return;

	struct int_vect vnew = { 0 };
	for (size_t i = n; i-- && s->ok; ) {
		aref clr = clset_at(pool, i);
		struct clause *c = arena_deref(&s->arena, clr);
		if (cl_marked(c))
			continue;

		int *lits = cl_begin(c);
		int  size = cl_size(c);
		bool has_la = false, has_lb = false;

		for (int k = 0; k < size; ++k) {
			if (lits[k] == la)
				has_la = true;
			else if (lits[k] == lb)
				has_lb = true;
		}
		if (!has_la || !has_lb)
			continue;

#ifdef LOGGING
		ergo_log_begin(s);
		fprintf(stderr, "extrewrite");
		for (int k = 0; k < size; ++k)
			fprintf(stderr, " %d", ergo_lit_to_dimacs(lits[k]));
		fprintf(stderr, " 0\n");
#endif

		vect_reserve(&vnew, (size_t)size - 1);
		int *newlits = vect_begin(&vnew);
		int  j = 0;
		newlits[j++] = zlit;
		for (int k = 0; k < size; ++k)
			if (lits[k] != la && lits[k] != lb)
				newlits[j++] = lits[k];
		assert(j == size - 1);

#ifdef LOGGING
		ergo_log_begin(s);
		fprintf(stderr, "extrewrite (rewritten)");
		for (int k = 0; k < j; ++k)
			fprintf(stderr, " %d", ergo_lit_to_dimacs(newlits[k]));
		fprintf(stderr, " 0\n");
#endif

		bool     learnt  = cl_learnt(c);
		unsigned old_lbd = cl_lbd(c);

		vnew.nmemb = j;
		if (s->proof_trace)
			ergo_trace_vect(&vnew, false, s->proof_trace);

		ergo_remove_cl(s, clr);
		clset_detach(pool, clr);

		if (j == 1) {
			if (!ergo_enqueue(s, newlits[0], AREF_NIL))
				s->ok = false;
		}
		else {
			aref newcl = ergo_new_cl(s, &vnew, learnt);

			// preserve the original clause's LBD
			cl_relbd(arena_deref(&s->arena, newcl), old_lbd);
		}

	}

	vect_destroy(&vnew);
}

// true iff literal 'l' is the phase its variable would actually be set to
// on the next decision;
//=============================================================================
static inline bool ergo_lit_pref(struct ergo *s, int l)
{
	int v = lit_var(l);
	int pref = s->user_pol[v] != lit_undef ? s->user_pol[v] : s->polarity[v];
	return pref == l;
}

// add a definition clause at level 0, watching non-false literals;
// a unit becomes a permanent fact and returns AREF_NIL
//=============================================================================
static aref ergo_ext_def_cl(struct ergo *s, int *lits, int n)
{
	if (s->proof_trace) {
		// RAT pivot first; preserve the watch order below
		int t = lits[0]; lits[0] = lits[n - 1]; lits[n - 1] = t;
		struct int_vect v = { .cap = n, .nmemb = n, .ptr = lits };
		ergo_trace_vect(&v, false, s->proof_trace);
		t = lits[0]; lits[0] = lits[n - 1]; lits[n - 1] = t;
	}
	int nlive = 0;
	for (int i = 0; i < n && nlive < 2; ++i)
		if (s->assigns[lits[i]] != lfalse) {
			int t = lits[nlive]; lits[nlive] = lits[i]; lits[i] = t;
			++nlive;
		}

	if (!nlive) {
		s->ok = false;
		return AREF_NIL;
	}
	if (nlive == 1) {
		if (!ergo_enqueue(s, lits[0], AREF_NIL))
			s->ok = false;
		return AREF_NIL;
	}

	struct int_vect v = { .cap = n, .nmemb = n, .ptr = lits };
	return ergo_new_cl(s, &v, false);
}

// add the naming implications, optionally including their converse
//=============================================================================
static void ext_define(struct ergo *s, int la, int lb, int zlit, aref def[3])
{
	int b1[2] = { lit_neg(la), zlit };
	int b2[2] = { lit_neg(lb), zlit };
	int b3[3] = { la, lb, lit_neg(zlit) };
	def[0] = def[1] = def[2] = AREF_NIL;
	def[0] = ergo_ext_def_cl(s, b1, 2);
	if (s->ok) def[1] = ergo_ext_def_cl(s, b2, 2);
	if (s->ok && s->ext_equiv) def[2] = ergo_ext_def_cl(s, b3, 3);
}

// define z <-> (la v lb) at level 0; rewrite learnts if enabled
//=============================================================================
static void ergo_extend(struct ergo *s, int la, int lb)
{
	assert(ergo_dlevel(s) == 0);
	assert(la != lit_neg(lb));

	if (s->ext_orig_nvars < 0)
		s->ext_orig_nvars = s->size;

	// a retired variable's id is only freed once nothing references it
	int zvar;
	if (vect_size(&s->ext_free_vars)) {
		vect_pop(&s->ext_free_vars, &zvar);
		ergo_init_var(s, zvar);
	} else {
		zvar = s->size;
		ergo_setnvars(s, s->size + 1);
	}
	int zlit = lit_of(zvar);

	// remembered permanently, and marked unless the scope is everything
	ext_var_insert(s, la, lb, zlit);
	s->ext_scope[zvar] = !s->ext_scope_all;

	assert(zvar != lit_var(la) && zvar != lit_var(lb));
	aref def[3];
	ext_define(s, la, lb, zlit, def);
	if (!s->ok)
		return;

	// without rewriting, pin z to keep its name alive
	s->ext_defs[zvar] = (struct ext_def){ .refc = s->ext_rewrite ? 0 : 1,
			.def = { def[0], def[1], def[2] }, .la = la, .lb = lb, .zlit = zlit,
			.active_pos = (int)vect_size(&s->ext_active) };
	vect_append(&s->ext_active, zvar);

	// substitute the pair la/lb with the extension variable
	if (s->ext_rewrite)
		ergo_ext_rewrite_pool(s, &s->learnts, la, lb, zlit);

	// retire unreferenced z now, before later pairs can nest on it
	if (s->ext_defs[zvar].refc == 0)
		ergo_ext_die(s, zvar);

	double aa = s->activity[lit_var(la)], ab = s->activity[lit_var(lb)];
	s->activity[zvar] = (aa + ab) / 2;

	if (s->activity[zvar] > 1e100)
		ergo_rescale_act_v(s);

	ergo_set_dvar(s, zvar);
	order_unassign(s, zvar);

	++s->ext_rewrites;
}

// define and pin a caller-owned name for (la v lb);
// register it and rewrite learnts if enabled
//=============================================================================
void ergo_xname(struct ergo *s, struct xpair_vect *pairs)
{
	if (!s->ok || !s->ext)
		return;

	ergo_force_backtrack(s, 0);

	struct ergo_xpair *p = vect_begin(pairs);
	int n = 0;

	for (size_t i = 0; i < vect_size(pairs); ++i) {
		int la = ergo_dimacs_to_lit(p[i].la);
		int lb = ergo_dimacs_to_lit(p[i].lb);
		int zl = ergo_dimacs_to_lit(p[i].z);
		int zv = lit_var(zl);

		if (lit_var(la) == lit_var(lb) || zv == lit_var(la) ||
				zv == lit_var(lb) || zv >= s->size)
			continue;
		if (s->ext_defs[zv].la != lit_undef)
			continue; // 'z' is already a name; nothing to define

		aref def[3];
		ext_define(s, la, lb, zl, def);
		if (!s->ok)
			break;

		++n;

		// the pair got a name of its own since the caller last looked;
		// 'z' stays an ordinary variable, defined but not tracked
		if (ext_var_find(s, la, lb) != lit_undef)
			continue;

		// the mined candidate, if there still is one, is now redundant
		if (la > lb) { int t = la; la = lb; lb = t; }
		int rec = ext_hash_find(s, la, lb);
		if (rec >= 0)
			ext_cand_remove_at(s, s->ext_cand_heap_pos[rec]);

		ext_var_insert(s, la, lb, zl);
		s->ext_scope[zv] = !s->ext_scope_all;

		// the caller's variable: never retired, so its clauses need no count
		s->ext_defs[zv] = (struct ext_def){ .refc = EXT_OWNED,
				.def = { def[0], def[1], def[2] }, .la = la, .lb = lb, .zlit = zl,
				.active_pos = (int)vect_size(&s->ext_active) };
		vect_append(&s->ext_active, zv);

		if (s->ext_rewrite)
			ergo_ext_rewrite_pool(s, &s->learnts, la, lb, zl);

		LOG(s, "extname %d %d -> %d", p[i].la, p[i].lb, p[i].z);
	}

	if (n) {
		ergo_clean_wlists(s);
		ergo_compact(s);
		ergo_ext_retire_pending(s); // a rewrite above may have just zeroed
		                            // out a nested variable
		if (ergo_propagate(s) != AREF_NIL)
			s->ok = false;
	}
}

// pairs named by a caller never get mined again; the corresponding variables
// are set to `var_undef` in the registry, as the caller's variable is none
// of Ergo's business
//=============================================================================
void ergo_xblock(struct ergo *s, struct xpair_vect *pairs)
{
	if (!s->ext)
		return;

	struct ergo_xpair *p = vect_begin(pairs);

	for (size_t i = 0; i < vect_size(pairs); ++i) {
		if (!p[i].la || !p[i].lb || abs(p[i].la) == abs(p[i].lb))
			continue;

		int la = ergo_dimacs_to_lit(p[i].la);
		int lb = ergo_dimacs_to_lit(p[i].lb);
		if (la > lb) { int t = la; la = lb; lb = t; }

		int rec = ext_hash_find(s, la, lb);
		if (rec >= 0)
			ext_cand_remove_at(s, s->ext_cand_heap_pos[rec]);

		// a name of ours stays alive, but the pair is the caller's now
		if (ext_var_find(s, la, lb) == lit_undef)
			ext_var_insert(s, la, lb, var_undef);
		else
			ext_find_slot(s->ext_var_hash, (uint32_t)(s->ext_var_hash_cap - 1),
					la, lb)->rec = var_undef;
	}
}

// drain pending retirements; removing definitions can retire nested variables
//=============================================================================
void ergo_ext_retire_pending(struct ergo *s)
{
	while (vect_size(&s->ext_zero_pending)) {
		int v;
		vect_pop(&s->ext_zero_pending, &v);

		// queued at refc==-1, but ergo_new_cl() revives (refc>=0 again)
		if (s->ext_defs[v].refc >= 0)
			continue;

		// defer removal while the variable is assigned, including at level 0
		if (s->assigns[lit_of(v)] != lundef)
			continue;

		aref def0 = s->ext_defs[v].def[0];
		aref def1 = s->ext_defs[v].def[1];
		aref def2 = s->ext_defs[v].def[2];
		int  la   = s->ext_defs[v].la;
		int  lb   = s->ext_defs[v].lb;

		// unless ergo_xblock() has given the pair to the caller since
		if (ext_var_find(s, la, lb) == s->ext_defs[v].zlit)
			ext_var_delete(s, la, lb);
		for (int rec = 0; rec < EXT_CAND_CAP; ++rec)
			if (s->ext_cand_heap_pos[rec] >= 0 &&
					(lit_var(s->ext_cands[rec].la) == v ||
					 lit_var(s->ext_cands[rec].lb) == v))
				ext_cand_remove_at(s, s->ext_cand_heap_pos[rec]);

		// a definition that was already a permanent fact when 'v' was
		// created (ergo_ext_def_cl()) was never given a clause object
		if (def0 != AREF_NIL) { ergo_remove_cl(s, def0); clset_detach(&s->clauses, def0); }
		if (def1 != AREF_NIL) { ergo_remove_cl(s, def1); clset_detach(&s->clauses, def1); }
		if (def2 != AREF_NIL) { ergo_remove_cl(s, def2); clset_detach(&s->clauses, def2); }

		ergo_clean_wlist(s, lit_of(v));
		ergo_clean_wlist(s, lit_neg(lit_of(v)));
		ergo_clean_wlist(s, la);
		ergo_clean_wlist(s, lit_neg(la));
		ergo_clean_wlist(s, lb);
		ergo_clean_wlist(s, lit_neg(lb));

		// only now unlinked from 's->ext_active'
		ergo_ext_active_remove(s, v);
		s->ext_defs[v] = (struct ext_def){ .refc = 0,
				.def = { AREF_NIL, AREF_NIL, AREF_NIL },
				.la = lit_undef, .lb = lit_undef, .zlit = lit_undef, .active_pos = -1 };

		// the ID of this variable is now safe to reuse;
		// 'dec_var[v]' is cleared here too
		if (s->dec_var[v]) {
			s->dec_var[v] = false;
			s->dec_vars--;
		}
		vect_append(&s->ext_free_vars, v);
	}
}

// at level 0, collect qualifying pairs by value, then recheck the hash
//=============================================================================
void ergo_ext_rewrite(struct ergo *s)
{
	// Positive infinity is the caller's mining-only mode. No candidate
	// can qualify, so avoid allocating and scanning the table per restart.
	if (s->ext_threshold == INFINITY)
		return;
	if (s->stat.conflicts < (uint64_t)s->ext_warmup)
		return;
	if (!s->ext_cand_heap_sz)
		return;

	struct pending { int la, lb; };
	struct pending *ready = malloc((size_t)s->ext_cand_heap_sz * sizeof(*ready));
	int n = 0;
	double threshold = s->ext_threshold *
		(1.0 + (double)s->ext_rewrites / s->ext_escalate);

	for (int i = 0; i < s->ext_cand_heap_sz; ++i) {
		int rec = s->ext_cand_heap[i];
		if (s->ext_cands[rec].count < threshold)
			continue;

		int la = s->ext_cands[rec].la, lb = s->ext_cands[rec].lb;

		// the scope may have shrunk since the pair was mined
		if (!ext_in_scope(s, lit_var(la)) || !ext_in_scope(s, lit_var(lb)))
			continue;

		// skip if either literal now prefers true, to respect phase saving
		if (ergo_lit_pref(s, la) || ergo_lit_pref(s, lb)) {
			LOG(s, "extskip_phase %d %d", ergo_lit_to_dimacs(la), ergo_lit_to_dimacs(lb));
			continue;
		}

		ready[n].la = la;
		ready[n].lb = lb;
		++n;
	}

	for (int i = 0; i < n && s->ok; ++i) {
		int rec = ext_hash_find(s, ready[i].la, ready[i].lb);
		if (rec < 0)
			continue; // already consumed earlier in this same sweep;
		ext_cand_remove_at(s, s->ext_cand_heap_pos[rec]);
		LOG(s, "extpromote %d %d -> x%d",
				ergo_lit_to_dimacs(ready[i].la), ergo_lit_to_dimacs(ready[i].lb),
				s->size + 1);
		ergo_extend(s, ready[i].la, ready[i].lb);
	}

	free(ready);

	if (n) {
		ergo_clean_wlists(s);
		ergo_compact(s);
		ergo_ext_retire_pending(s); // this sweep's own rewrite_pool() calls
		                           // may have just zeroed out a nested var
		if (ergo_propagate(s) != AREF_NIL)
			s->ok = false;

		LOG(s, "extdiag restarts=%llu orig_nvars=%d nvars=%d ext_vars=%llu"
				" cand_heap=%d cand_hash_live=%d",
				(unsigned long long)s->stat.starts,
				s->ext_orig_nvars, s->size,
				(unsigned long long)s->ext_rewrites,
				s->ext_cand_heap_sz, s->ext_cand_heap_sz);
	}
}
