/*
 * ext.c
 *
 *  Created on: Oct 5, 2026
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@monash.edu
 */

// system includes:
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
// local includes:
#include "ext.h"
#include "ergo.h"
#include "ergodbg.h"

// candidate-pair mining machinery; see ext.h's top-of-file comment
// for the full design (including a pseudocode and an example);
//=============================================================================
#define EXT_MAX_LEARNT_FOR_MINING  48

// tuning constants for automatic mining.
#define EXT_PROMOTE_THRESHOLD      60    // co-occurrences before a pair
                                         // self-registers (lifetime count,
                                         // separate from decayed 'activity')
#define EXT_WARMUP_CONFLICTS       1500  // conflicts to let pass unmined
                                         // before mining starts at all

// growth control: the bar to cross EXT_PROMOTE_THRESHOLD escalates with
// how much has already been promoted, so runaway promotion chokes itself
// off.
#define EXT_ESCALATE_UNIT          10000 // effective threshold = base *
                                         // (1 + ext_rewrites/this)

#define EXT_CAND_CAP                4096 // max not-yet-promoted pairs tracked at once
#define EXT_HASH_CAP               16384 // power of two, >= 4x EXT_CAND_CAP to keep
                                         // probe sequences short between rebuilds
#define EXT_HASH_MASK (EXT_HASH_CAP - 1)
#define EXT_REHASH_DEAD             4096 // rebuild the hash index once tombstones
                                         // reach this many

// forward declaration: tombstones (la,lb) out of 's->ext_var_hash'
static void ext_var_delete(struct ergo *s, int la, int lb);

// removes 'v' from 's->ext_active' (swap-with-last).
//=============================================================================
void ergo_ext_active_remove(struct ergo *s, int v)
{
	int pos      = s->ext_defs[v].active_pos;
	int last_idx = (int)vect_size(&s->ext_active) - 1;
	int last_var = *(int *)vect_at(&s->ext_active, (size_t)last_idx);

	if (pos != last_idx) {
		*(int *)vect_at(&s->ext_active, (size_t)pos) = last_var;
		s->ext_defs[last_var].active_pos = pos;
	}

	vect_shrink(&s->ext_active, (size_t)last_idx);
}

// refcount hit 0 (ergo_remove_cl(), or 'born dead' in ergo_extend()): tombstone
// (la,lb) and mark 'v' dying (refc=-1), queuing it for
// ergo_ext_retire_pending() to actually remove its definition clauses later;
// 'def[]'/'ext_active' stay intact until then so ergo_compact() can still
// relocate them.
//=============================================================================
void ergo_ext_die(struct ergo *s, int v)
{
	struct ext_def *d = &s->ext_defs[v];

	ext_var_delete(s, d->la, d->lb);
	d->refc = -1;

	vect_append(&s->ext_zero_pending, v);
}

//
//=============================================================================
void ext_init(struct ergo *s)
{
	s->ext_scope  = NULL;
	s->ext_reason = NULL;
	s->ext_defs   = NULL;

	s->ext           = false;
	s->ext_rewrites       = 0;
	s->ext_orig_nvars     = -1;

	s->ext_threshold      = EXT_PROMOTE_THRESHOLD;
	s->ext_warmup         = EXT_WARMUP_CONFLICTS;
	s->ext_escalate       = EXT_ESCALATE_UNIT;

	s->ext_scope_all = true;

	// deliberately not allocated here;
	// ergo_xenable(s, true) does that,
	// and only when 's->ext' is actually turned on.
	s->ext_cands          = NULL;
	s->ext_cand_free      = NULL;
	s->ext_cand_heap      = NULL;
	s->ext_cand_heap_pos  = NULL;
	s->ext_cand_hash      = NULL;
	s->ext_cand_nfree     = 0;
	s->ext_cand_heap_sz   = 0;
	s->ext_cand_hash_live = 0;

	s->ext_var_hash       = NULL; // grown lazily, see ext_var_insert()
	s->ext_var_hash_cap   = 0;
	s->ext_var_hash_live  = 0;
	s->ext_var_hash_dead  = 0;
	s->ext_cand_hash_dead = 0;
	s->ext_cand_inc       = 1;

	vect_init(&s->ext_active,       sizeof(int));
	vect_init(&s->ext_free_vars,    sizeof(int));
	vect_init(&s->ext_zero_pending, sizeof(int));
}

// grows the per-variable ext arrays to 's->cap'
//=============================================================================
void ext_grow_vars(struct ergo *s)
{
	s->ext_scope  = realloc(s->ext_scope,  s->cap * sizeof(bool));
	s->ext_reason = realloc(s->ext_reason, s->cap * sizeof(bool));
	s->ext_defs   = realloc(s->ext_defs,   s->cap * sizeof(struct ext_def));
}

//
//=============================================================================
void ext_destroy(struct ergo *s)
{
	free(s->ext_cands);
	free(s->ext_cand_free);
	free(s->ext_cand_heap);
	free(s->ext_cand_heap_pos);
	free(s->ext_cand_hash);
	free(s->ext_var_hash);
	vect_destroy(&s->ext_active);
	vect_destroy(&s->ext_free_vars);
	vect_destroy(&s->ext_zero_pending);

	free(s->ext_scope);
	free(s->ext_reason);
	free(s->ext_defs);
}

//
//=============================================================================
static uint32_t ext_hash(int la, int lb)
{
	uint32_t h = (uint32_t)la * 2654435761u;
	h ^= (uint32_t)lb * 2246822519u;
	h ^= h >> 15;
	return h & EXT_HASH_MASK;
}

//
//=============================================================================
static void ext_hash_rebuild(struct ergo *s)
{
	for (int i = 0; i < EXT_HASH_CAP; ++i)
		s->ext_cand_hash[i].la = var_undef;
	s->ext_cand_hash_dead = 0;

	for (int i = 0; i < s->ext_cand_heap_sz; ++i) {
		int rec = s->ext_cand_heap[i];
		struct ext_cand *c = &s->ext_cands[rec];

		uint32_t h = ext_hash(c->la, c->lb);
		while (s->ext_cand_hash[h].la != var_undef)
			h = (h + 1) & EXT_HASH_MASK;

		s->ext_cand_hash[h] = (struct ext_hash_slot){ c->la, c->lb, rec };
	}
}

// -1 if 'la','lb' (already normalized la <= lb) isn't currently tracked
//=============================================================================
static int ext_hash_find(struct ergo *s, int la, int lb)
{
	uint32_t h = ext_hash(la, lb);

	for (;;) {
		struct ext_hash_slot *slot = &s->ext_cand_hash[h];

		if (slot->la == var_undef)
			return -1;
		if (slot->la == la && slot->lb == lb)
			return slot->rec;

		h = (h + 1) & EXT_HASH_MASK;
	}
}

//
//=============================================================================
static void ext_hash_insert(struct ergo *s, int la, int lb, int rec)
{
	uint32_t h = ext_hash(la, lb);
	while (s->ext_cand_hash[h].la != var_undef)
		h = (h + 1) & EXT_HASH_MASK;

	s->ext_cand_hash[h] = (struct ext_hash_slot){ la, lb, rec };
	s->ext_cand_hash_live++;
}

//
//=============================================================================
static void ext_hash_delete(struct ergo *s, int la, int lb)
{
	uint32_t h = ext_hash(la, lb);

	for (;;) {
		struct ext_hash_slot *slot = &s->ext_cand_hash[h];

		assert(slot->la != var_undef); // caller only deletes what it just found
		if (slot->la == la && slot->lb == lb) {
			slot->la = lit_undef; // tombstone
			s->ext_cand_hash_live--;
			s->ext_cand_hash_dead++;
			return;
		}

		h = (h + 1) & EXT_HASH_MASK;
	}
}

// permanent (la,lb) -> z registry; grows (doubles+rehashes) instead of
// evicting, since nothing here is ever stale; separate from 'ext_cand_hash'
// (the bounded, evicting candidate cache above);
//=============================================================================
static uint32_t ext_var_hash(int la, int lb, uint32_t mask)
{
	uint32_t h = (uint32_t)la * 2654435761u;
	h ^= (uint32_t)lb * 2246822519u;
	h ^= h >> 15;
	return h & mask;
}

//
//=============================================================================
static int ext_var_find(struct ergo *s, int la, int lb)
{
	if (!s->ext_var_hash_cap)
		return lit_undef;
	if (la > lb) { int t = la; la = lb; lb = t; }

	uint32_t mask = (uint32_t)(s->ext_var_hash_cap - 1);
	uint32_t h = ext_var_hash(la, lb, mask);
	for (;;) {
		struct ext_hash_slot *slot = &s->ext_var_hash[h];
		if (slot->la == var_undef)
			return lit_undef;
		if (slot->la == la && slot->lb == lb)
			return slot->rec;
		h = (h + 1) & mask;
	}
}

// rebuilds the table, dropping every tombstone;
// 'new_cap' lets the caller grow or hold steady in the same pass;
//=============================================================================
static void ext_var_hash_rebuild(struct ergo *s, int new_cap)
{
	int old_cap = s->ext_var_hash_cap;
	struct ext_hash_slot *old = s->ext_var_hash;

	s->ext_var_hash_cap = new_cap;
	s->ext_var_hash = malloc((size_t)new_cap * sizeof(struct ext_hash_slot));
	for (int i = 0; i < new_cap; ++i)
		s->ext_var_hash[i].la = var_undef;

	uint32_t mask = (uint32_t)(new_cap - 1);
	for (int i = 0; i < old_cap; ++i)
		if (old[i].la != var_undef && old[i].la != lit_undef) {
			uint32_t h = ext_var_hash(old[i].la, old[i].lb, mask);
			while (s->ext_var_hash[h].la != var_undef)
				h = (h + 1) & mask;
			s->ext_var_hash[h] = old[i];
		}
	free(old);
	s->ext_var_hash_dead = 0;
}

//
//=============================================================================
void ext_var_insert(struct ergo *s, int la, int lb, int zlit)
{
	if (la > lb) { int t = la; la = lb; lb = t; }

	if (s->ext_var_hash_cap == 0 ||
			(s->ext_var_hash_live + s->ext_var_hash_dead) * 2 >= s->ext_var_hash_cap) {
		int old_cap = s->ext_var_hash_cap;
		// still mostly live (not just garbage tombstones) -- actually grow;
		// otherwise a same-size compaction is enough to make room again;
		int new_cap = old_cap == 0 ? 1024
				: s->ext_var_hash_live * 2 >= old_cap ? old_cap * 2 : old_cap;
		ext_var_hash_rebuild(s, new_cap);
	}

	uint32_t mask = (uint32_t)(s->ext_var_hash_cap - 1);
	uint32_t h = ext_var_hash(la, lb, mask);
	while (s->ext_var_hash[h].la != var_undef)
		h = (h + 1) & mask;
	s->ext_var_hash[h] = (struct ext_hash_slot){ la, lb, zlit };
	s->ext_var_hash_live++;
}

// tombstones (la,lb)'s entry; called only by ergo_ext_retire_pending()
// once the pair's z has no live references left, so the pair becomes
// mineable again from scratch if it recurs;
//=============================================================================
static void ext_var_delete(struct ergo *s, int la, int lb)
{
	if (la > lb) { int t = la; la = lb; lb = t; }

	uint32_t mask = (uint32_t)(s->ext_var_hash_cap - 1);
	uint32_t h = ext_var_hash(la, lb, mask);
	for (;;) {
		struct ext_hash_slot *slot = &s->ext_var_hash[h];
		assert(slot->la != var_undef);
		if (slot->la == la && slot->lb == lb) {
			slot->la = lit_undef;
			s->ext_var_hash_live--;
			s->ext_var_hash_dead++;
			return;
		}
		h = (h + 1) & mask;
	}
}

// scans lits[start..n) for any pair already registered and folds it into its z;
// start=1 for a reason clause (protects index 0's asserting literal);
// start=0 for an external clause; loops to a fixed point since one
// substitution can expose another;
//=============================================================================
void ergo_ext_subst(struct ergo *s, struct vect *lits, size_t start)
{
	if (!s->ext_var_hash_cap)
		return;

	bool again = true;
	while (again) {
		again = false;
		int *l = vect_begin(lits);
		size_t n = vect_size(lits);

		for (size_t i = start; i < n && !again; ++i)
			for (size_t j = i + 1; j < n; ++j) {
				int zlit = ext_var_find(s, l[i], l[j]);
				if (zlit == lit_undef)
					continue;

				l[i] = zlit;
				l[j] = l[n - 1];
				vect_shrink(lits, n - 1);
				again = true;
				break;
			}
	}
}

// indexed min-heap over 'ext_cands[]', ordered by 'activity';
// same shape as order_percolate_up/down for VSIDS;
//=============================================================================
static void ext_cand_heap_up(struct ergo *s, int i)
{
	int *heap = s->ext_cand_heap;
	int  x    = heap[i];

	while (i != 0) {
		int parent = (i - 1) / 2;
		if (s->ext_cands[heap[parent]].activity <= s->ext_cands[x].activity)
			break;

		heap[i] = heap[parent];
		s->ext_cand_heap_pos[heap[i]] = i;
		i = parent;
	}

	heap[i] = x;
	s->ext_cand_heap_pos[x] = i;
}

//
//=============================================================================
static void ext_cand_heap_down(struct ergo *s, int i)
{
	int *heap = s->ext_cand_heap;
	int  sz   = s->ext_cand_heap_sz;
	int  x    = heap[i];

	for (;;) {
		int child = 2 * i + 1;
		if (child >= sz)
			break;
		if (child + 1 < sz &&
				s->ext_cands[heap[child + 1]].activity < s->ext_cands[heap[child]].activity)
			++child;
		if (s->ext_cands[x].activity <= s->ext_cands[heap[child]].activity)
			break;

		heap[i] = heap[child];
		s->ext_cand_heap_pos[heap[i]] = i;
		i = child;
	}

	heap[i] = x;
	s->ext_cand_heap_pos[x] = i;
}

// removes the record at heap position 'pos' entirely: drops it from the
// hash index, unlinks it from the heap (swap-with-last then re-settle,
// same as order_select()'s pop), and returns its slot to the free-list;
//=============================================================================
static void ext_cand_remove_at(struct ergo *s, int pos)
{
	int rec = s->ext_cand_heap[pos];

	ext_hash_delete(s, s->ext_cands[rec].la, s->ext_cands[rec].lb);

	int last = --s->ext_cand_heap_sz;
	s->ext_cand_heap_pos[rec] = -1;
	if (pos != last) {
		s->ext_cand_heap[pos] = s->ext_cand_heap[last];
		s->ext_cand_heap_pos[s->ext_cand_heap[pos]] = pos;
		// the record moved into 'pos' could belong either above or below
		// its new spot; try both, only one will ever actually move it
		ext_cand_heap_down(s, pos);
		ext_cand_heap_up  (s, pos);
	}

	s->ext_cand_free[s->ext_cand_nfree++] = rec;
}

//
//=============================================================================
static void ext_cand_insert(struct ergo *s, int la, int lb, double weight)
{
	int rec = s->ext_cand_free[--s->ext_cand_nfree];

	// must rebuild before 'rec' joins the heap below, or the rebuild
	// (which walks the heap to repopulate the hash) would absorb this
	// insert too and plant a duplicate, stale hash slot;
	if (s->ext_cand_hash_dead >= EXT_REHASH_DEAD)
		ext_hash_rebuild(s);

	s->ext_cands[rec] = (struct ext_cand){ .la = la, .lb = lb,
			.count = weight, .activity = s->ext_cand_inc };

	int pos = s->ext_cand_heap_sz++;
	s->ext_cand_heap[pos] = rec;
	ext_cand_heap_up(s, pos);

	ext_hash_insert(s, la, lb, rec);
}

// VSIDS-style bump: grows 'activity' by the current increment, rescaling
// on overflow like ergo_bump_var();
//=============================================================================
static void ext_cand_bump(struct ergo *s, int rec)
{
	struct ext_cand *c = &s->ext_cands[rec];

	c->activity += s->ext_cand_inc;
	if (c->activity > 1e100) {
		for (int i = 0; i < s->ext_cand_heap_sz; ++i)
			s->ext_cands[s->ext_cand_heap[i]].activity *= 1e-100;
		s->ext_cand_inc *= 1e-100;
	}

	ext_cand_heap_down(s, s->ext_cand_heap_pos[rec]);
}

#define EXT_CAND_DECAY_INV (1.0 / 0.95) // matches var_decay's own default

// bumps (la,lb)'s tracking record
//=============================================================================
static void ergo_ext_mine(struct ergo *s, int la, int lb, double weight)
{
	if (la > lb) { int t = la; la = lb; lb = t; }

	// already extended (propagated independently of this mining path);
	// nothing to do, it already has a 'z'.
	if (ext_var_find(s, la, lb) != lit_undef)
		return;

	int rec = ext_hash_find(s, la, lb);

	if (rec < 0) {
		if (s->ext_cand_nfree == 0) {
			// table full -- evict the weakest entry only if this
			// occurrence is already stronger; otherwise, drop it
			// rather than displace an established candidate
			int weakest = s->ext_cand_heap[0];
			if (s->ext_cand_inc <= s->ext_cands[weakest].activity)
				return;
			ext_cand_remove_at(s, 0);
		}
		ext_cand_insert(s, la, lb, weight);
		LOG(s, "extmine %d %d", ergo_lit_to_dimacs(la), ergo_lit_to_dimacs(lb));
		return;
	}

	ext_cand_bump(s, rec);
	s->ext_cands[rec].count += weight;
}

// true iff 'var' is eligible for mining
//=============================================================================
static inline bool ext_in_scope(struct ergo *s, int var)
{
	return s->ext_scope_all || s->ext_scope[var];
}

// scans lits[start..n) for recurring pairs, weighted 1/|decision-level diff|
//=============================================================================
void ergo_ext_mine_cl(struct ergo *s, int *lits, size_t n, size_t start)
{
	if (n > EXT_MAX_LEARNT_FOR_MINING)
		return;

	for (size_t i = start; i < n; ++i)
		for (size_t j = i + 1; j < n; ++j) {
			// same level: already related by one ordered
			// propagation chain, not two independent reasons;
			// not what z <-> (la v lb) is meant to name
			int lvl_i = s->levels[lit_var(lits[i])];
			int lvl_j = s->levels[lit_var(lits[j])];
			if (lvl_i == lvl_j)
				continue;

			if (!ext_in_scope(s, lit_var(lits[i])) ||
					!ext_in_scope(s, lit_var(lits[j])))
				continue;

			ergo_ext_mine(s, lits[i], lits[j], 1.0 / (double)abs(lvl_i - lvl_j));
		}
}

//
//=============================================================================
void ergo_ext_mine_learnt(struct ergo *s, struct vect *learnt)
{
	s->ext_cand_inc *= EXT_CAND_DECAY_INV; // once per conflict, mirroring
	                                        // ergo_decay_act_v()'s cadence

	if (s->stat.conflicts < (uint64_t)s->ext_warmup)
		return;

	ergo_ext_mine_cl(s, vect_begin(learnt), vect_size(learnt), 0);
}

// turn the extension mode on; fixed at setup time
//=============================================================================
void ergo_xenable(struct ergo *s, bool on)
{
	assert(!s->ext);
	s->ext = on;

	if (on) {
		s->ext_cands         = malloc(EXT_CAND_CAP * sizeof(struct ext_cand));
		s->ext_cand_free     = malloc(EXT_CAND_CAP * sizeof(int));
		s->ext_cand_heap     = malloc(EXT_CAND_CAP * sizeof(int));
		s->ext_cand_heap_pos = malloc(EXT_CAND_CAP * sizeof(int));
		s->ext_cand_hash     = malloc(EXT_HASH_CAP * sizeof(struct ext_hash_slot));

		for (int i = 0; i < EXT_CAND_CAP; ++i) {
			s->ext_cand_free[i]     = i;
			s->ext_cand_heap_pos[i] = -1;
		}

		for (int i = 0; i < EXT_HASH_CAP; ++i)
			s->ext_cand_hash[i].la = var_undef;

		s->ext_cand_nfree = EXT_CAND_CAP;
	}
}

//
//=============================================================================
void ergo_setxthreshold(struct ergo *s, double val)
{
	s->ext_threshold = val;
}

//
//=============================================================================
void ergo_setxwarmup(struct ergo *s, int64_t val)
{
	s->ext_warmup = val;
}

//
//=============================================================================
void ergo_setxescalate(struct ergo *s, double val)
{
	s->ext_escalate = val;
}

// drops every extension variable both of whose defining literals have left
// the scope; as one pass cannot deal with nested definitions, runs until a
// fixed point;
//=============================================================================
static void ext_scope_cascade(struct ergo *s)
{
	assert(!s->ext_scope_all); // or every test below is trivially true

	bool again = true;
	while (again) {
		again = false;

		for (size_t i = 0; i < vect_size(&s->ext_active); ++i) {
			int             v = *(int *)vect_at(&s->ext_active, i);
			struct ext_def *d = &s->ext_defs[v];

			if (!ext_in_scope(s, v))
				continue;
			if (ext_in_scope(s, lit_var(d->la)) ||
					ext_in_scope(s, lit_var(d->lb)))
				continue;

			s->ext_scope[v] = false;
			again = true;
		}
	}
}

//
//=============================================================================
void ergo_setxscope(struct ergo *s, struct vect *add, struct vect *rem)
{
	size_t nadd = vect_size (add),  nrem = vect_size (rem);
	int   *ap   = vect_begin(add), *rp   = vect_begin(rem);

#ifndef NDEBUG
	for (size_t i = 0; i < nadd; ++i)
		for (size_t j = 0; j < nrem; ++j)
			assert(ap[i] != rp[j]); // the two must not overlap
#endif

	if (!nadd && !nrem) {
		s->ext_scope_all = true;
		for (int v = 0; v < s->size; ++v)
			s->ext_scope[v] = false;
		return;
	}

	if (s->ext_scope_all && nrem) {
		for (int v = 0; v < s->size; ++v)
			s->ext_scope[v] = true;
	}
	s->ext_scope_all = false;

	for (size_t i = 0; i < nrem; ++i) {
		assert(rp[i] < s->size);
		s->ext_scope[rp[i]] = false;
	}

	for (size_t i = 0; i < nadd; ++i) {
		assert(ap[i] < s->size);
		s->ext_scope[ap[i]] = true;
	}

	if (nrem)
		ext_scope_cascade(s);
}

// every pair extension currently tracks: the promoted ones (each named by its
// 'z') first, then the candidates, which rank among themselves by 'count';
//=============================================================================
void ergo_xpairs(struct ergo *s, struct vect *out)
{
	vect_clear(out);

	for (size_t i = 0; i < vect_size(&s->ext_active); ++i) {
		int             v = *(int *)vect_at(&s->ext_active, i);
		struct ext_def *d = &s->ext_defs[v];

		if (d->refc < 0)
			continue;

		vect_append(out, ((struct ergo_xpair){
					.la = ergo_lit_to_dimacs(d->la),
					.lb = ergo_lit_to_dimacs(d->lb),
					.z  = ergo_lit_to_dimacs(lit_of(v)),
					.count = 0.0 }));
	}

	for (int i = 0; i < s->ext_cand_heap_sz; ++i) {
		struct ext_cand *c = &s->ext_cands[s->ext_cand_heap[i]];

		vect_append(out, ((struct ergo_xpair){
					.la = ergo_lit_to_dimacs(c->la),
					.lb = ergo_lit_to_dimacs(c->lb),
					.z  = 0,
					.count = c->count }));
	}
}

// an extra reference, held on the caller's behalf: the refcount can no
// longer fall to 0, so these variables never retire / die;
//=============================================================================
void ergo_xpin(struct ergo *s, struct vect *vars)
{
	int *vp = vect_begin(vars);

	for (size_t i = 0; i < vect_size(vars); ++i) {
		assert(vp[i] < s->size);
		struct ext_def *d = &s->ext_defs[vp[i]];

		if (d->la != lit_undef && d->refc >= 0)
			d->refc++;
	}
}

// drops the reference ergo_xpin() took, dying on the last one exactly as a
// clause removal would; unpinning what was never pinned consumes a real
// reference, so this should not be called on variables that were not pinned
// first;
//=============================================================================
void ergo_xunpin(struct ergo *s, struct vect *vars)
{
	int *vp = vect_begin(vars);

	for (size_t i = 0; i < vect_size(vars); ++i) {
		assert(vp[i] < s->size);
		struct ext_def *d = &s->ext_defs[vp[i]];

		if (d->la != lit_undef && d->refc > 0 && --d->refc == 0)
			ergo_ext_die(s, vp[i]);
	}
}

// scans one clause pool for every live clause containing both 'la' and 'lb',
// replacing each with (clause \ {la,lb}) U {zlit};
//=============================================================================
static void ergo_ext_rewrite_pool(struct ergo *s, struct clset *pool, int la, int lb, int zlit)
{
	size_t n = clset_size(pool);
	if (!n)
		return;

	aref *snapshot = malloc(n * sizeof(aref));
	memcpy(snapshot, clset_begin(pool), n * sizeof(aref));

	for (size_t i = 0; i < n; ++i) {
		aref clr = snapshot[i];
		struct clause *c = arena_deref(&s->arena, clr);
		if (cl_marked(c))
			continue;

		int *lits = cl_begin(c);
		int  size = cl_size(c);
		bool has_la = false, has_lb = false;

		for (int k = 0; k < size; ++k) {
			if (lits[k] == la)
				has_la = true;
			else if (lits[k] == lb)
				has_lb = true;
		}
		if (!has_la || !has_lb)
			continue;

#ifdef LOGGING
		ergo_log_begin(s);
		fprintf(stderr, "extrewrite");
		for (int k = 0; k < size; ++k)
			fprintf(stderr, " %d", ergo_lit_to_dimacs(lits[k]));
		fprintf(stderr, " 0\n");
#endif

		int *newlits = malloc((size_t)(size - 1) * sizeof(int));
		int  j = 0;
		newlits[j++] = zlit;
		for (int k = 0; k < size; ++k)
			if (lits[k] != la && lits[k] != lb)
				newlits[j++] = lits[k];
		assert(j == size - 1);

#ifdef LOGGING
		ergo_log_begin(s);
		fprintf(stderr, "extrewrite (rewritten)");
		for (int k = 0; k < j; ++k)
			fprintf(stderr, " %d", ergo_lit_to_dimacs(newlits[k]));
		fprintf(stderr, " 0\n");
#endif

		bool     learnt  = cl_learnt(c);
		unsigned old_lbd = cl_lbd(c);

		ergo_remove_cl(s, clr);
		clset_detach(pool, clr);

		if (j == 1)
			ergo_enqueue(s, newlits[0], AREF_NIL);
		else {
			struct vect vnew = { .cap = j, .nmemb = j,
					.size = sizeof(int), .ptr = newlits };
			aref newcl = ergo_new_cl(s, &vnew, learnt);

			// preserve the original clause's LBD
			cl_relbd(arena_deref(&s->arena, newcl), old_lbd);
		}

		free(newlits);
	}

	free(snapshot);
}

// true iff literal 'l' is the phase its variable would actually be set to
// on the next decision;
//=============================================================================
static inline bool ergo_lit_pref(struct ergo *s, int l)
{
	int v = lit_var(l);
	int pref = s->user_pol[v] != lit_undef ? s->user_pol[v] : s->polarity[v];
	return pref == l;
}

// adds one of z's 3 definition clauses, watching two literals that are not
// already permanently false; la/lb (or even z itself, if an earlier sibling
// definition clause already forced it) may have become fixed since being
// mined, so blindly watching the first two literals can leave a clause that
// never gets re-examined again; always called at decision level 0, so any
// assignment found here is permanent; a Tseitin definition is never
// contradictory regardless of la/lb's current truth values, so at least one
// literal is always live;
//=============================================================================
static aref ergo_ext_def_cl(struct ergo *s, int *lits, int n)
{
	int nlive = 0;
	for (int i = 0; i < n && nlive < 2; ++i)
		if (s->assigns[lits[i]] != lfalse) {
			int t = lits[nlive]; lits[nlive] = lits[i]; lits[i] = t;
			++nlive;
		}

	assert(nlive > 0);
	if (nlive == 1) {
		ergo_enqueue(s, lits[0], AREF_NIL);
		return AREF_NIL;
	}

	struct vect v = { .cap = n, .nmemb = n, .size = sizeof(int), .ptr = lits };
	return ergo_new_cl(s, &v, false);
}

// creates z for (la v lb): z <-> (la v lb) via (¬la∨z),(¬lb∨z),(la∨lb∨¬z).
// rewrites every (la,lb) in the learnt pool to z (never s->clauses, so z
// can still retire later), only at decision level 0; z is left unassigned
// via order_unassign() for ordinary search to decide;
//=============================================================================
static void ergo_extend(struct ergo *s, int la, int lb)
{
	assert(ergo_dlevel(s) == 0);
	assert(la != lit_neg(lb));

	if (s->ext_orig_nvars < 0)
		s->ext_orig_nvars = s->size;

	// a retired variable's id is only freed once nothing references it
	int zvar;
	if (vect_size(&s->ext_free_vars)) {
		vect_pop(&s->ext_free_vars, &zvar);
		ergo_init_var(s, zvar);
	} else {
		zvar = s->size;
		ergo_setnvars(s, s->size + 1);
	}
	int zlit = lit_of(zvar);

	// remembered permanently, and marked unless the scope is everything
	ext_var_insert(s, la, lb, zlit);
	s->ext_scope[zvar] = !s->ext_scope_all;

	// created before 'zvar's 'ext_defs' entry is registered below; each
	// of these 3 clauses contains exactly one literal of 'zvar', by
	// construction;
	int b1[2] = { lit_neg(la), zlit };
	aref d0 = ergo_ext_def_cl(s, b1, 2);

	int b2[2] = { lit_neg(lb), zlit };
	aref d1 = ergo_ext_def_cl(s, b2, 2);

	int b3[3] = { la, lb, lit_neg(zlit) };
	aref d2 = ergo_ext_def_cl(s, b3, 3);

	s->ext_defs[zvar] = (struct ext_def){ .refc = 0,
			.def = { d0, d1, d2 }, .la = la, .lb = lb,
			.active_pos = (int)vect_size(&s->ext_active) };
	vect_append(&s->ext_active, zvar);

	// substiture the pair la/lb with the extension variable
	ergo_ext_rewrite_pool(s, &s->learnts, la, lb, zlit);

	// z can be born already unreferenced if every la/lb occurrence that
	// crossed the threshold was since reduceDB'd away; die immediately
	// rather than queue, since this sweep isn't done and a later pair
	// could nest on 'zlit' before a batched drain would run;
	if (s->ext_defs[zvar].refc == 0)
		ergo_ext_die(s, zvar);

	double aa = s->activity[lit_var(la)], ab = s->activity[lit_var(lb)];
	s->activity[zvar] = (aa + ab) / 2;

	if (s->activity[zvar] > 1e100)
		ergo_rescale_act_v(s);

	ergo_set_dvar(s, zvar);
	order_unassign(s, zvar);

	++s->ext_rewrites;
}

// the one place a variable's definition clauses actually get removed:
// drains 's->ext_zero_pending' as a worklist, since removing one variable's
// definition clauses can drop a nested variable's count to 0 too;
//=============================================================================
void ergo_ext_retire_pending(struct ergo *s)
{
	while (vect_size(&s->ext_zero_pending)) {
		int v;
		vect_pop(&s->ext_zero_pending, &v);

		// queued at refc==-1, but ergo_new_cl() revives (refc>=0 again)
		if (s->ext_defs[v].refc >= 0)
			continue;

		// a dying variable can still be on the trail, including at
		// level 0; it cannot be removed until the assignment gets
		// undone;
		if (s->assigns[lit_of(v)] != lundef)
			continue;

		aref def0 = s->ext_defs[v].def[0];
		aref def1 = s->ext_defs[v].def[1];
		aref def2 = s->ext_defs[v].def[2];
		int  la   = s->ext_defs[v].la;
		int  lb   = s->ext_defs[v].lb;

		// a definition that was already a permanent fact when 'v' was
		// created (ergo_ext_def_cl()) was never given a clause object
		if (def0 != AREF_NIL) { ergo_remove_cl(s, def0); clset_detach(&s->clauses, def0); }
		if (def1 != AREF_NIL) { ergo_remove_cl(s, def1); clset_detach(&s->clauses, def1); }
		if (def2 != AREF_NIL) { ergo_remove_cl(s, def2); clset_detach(&s->clauses, def2); }

		ergo_clean_wlist(s, lit_of(v));
		ergo_clean_wlist(s, lit_neg(lit_of(v)));
		ergo_clean_wlist(s, la);
		ergo_clean_wlist(s, lit_neg(la));
		ergo_clean_wlist(s, lb);
		ergo_clean_wlist(s, lit_neg(lb));

		// only now unlinked from 's->ext_active'
		ergo_ext_active_remove(s, v);
		s->ext_defs[v] = (struct ext_def){ .refc = 0,
				.def = { AREF_NIL, AREF_NIL, AREF_NIL },
				.la = lit_undef, .lb = lit_undef, .active_pos = -1 };

		// the ID of this variable is now safe to reuse;
		// 'dec_var[v]' is cleared here too
		if (s->dec_var[v]) {
			s->dec_var[v] = false;
			s->dec_vars--;
		}
		vect_append(&s->ext_free_vars, v);
	}
}

// runs restart_sweep() from ext.h's top-of-file comment; called once per
// restart, at decision level 0; collects qualifying pairs by value first,
// then re-looks-up by hash;
//=============================================================================
void ergo_ext_rewrite(struct ergo *s)
{
	if (s->stat.conflicts < (uint64_t)s->ext_warmup)
		return;
	if (!s->ext_cand_heap_sz)
		return;

	struct pending { int la, lb; };
	struct pending *ready = malloc((size_t)s->ext_cand_heap_sz * sizeof(*ready));
	int n = 0;
	double threshold = s->ext_threshold *
		(1.0 + (double)s->ext_rewrites / s->ext_escalate);

	for (int i = 0; i < s->ext_cand_heap_sz; ++i) {
		int rec = s->ext_cand_heap[i];
		if (s->ext_cands[rec].count < threshold)
			continue;

		int la = s->ext_cands[rec].la, lb = s->ext_cands[rec].lb;

		// the scope may have shrunk since the pair was mined
		if (!ext_in_scope(s, lit_var(la)) || !ext_in_scope(s, lit_var(lb)))
			continue;

		// phase-match gate: la/lb were false when mined, which is what
		// makes z=false's forced propagation correct;
		// if either has since flipped to its preferred phase,
		// forcing z=false would fight phase-saving;
		if (ergo_lit_pref(s, la) || ergo_lit_pref(s, lb)) {
			LOG(s, "extskip_phase %d %d", ergo_lit_to_dimacs(la), ergo_lit_to_dimacs(lb));
			continue;
		}

		ready[n].la = la;
		ready[n].lb = lb;
		++n;
	}

	for (int i = 0; i < n; ++i) {
		int rec = ext_hash_find(s, ready[i].la, ready[i].lb);
		if (rec < 0)
			continue; // already consumed earlier in this same sweep;
		ext_cand_remove_at(s, s->ext_cand_heap_pos[rec]);
		LOG(s, "extpromote %d %d -> x%d",
				ergo_lit_to_dimacs(ready[i].la), ergo_lit_to_dimacs(ready[i].lb),
				s->size + 1);
		ergo_extend(s, ready[i].la, ready[i].lb);
	}

	free(ready);

	if (n) {
		ergo_clean_wlists(s);
		ergo_compact(s);
		ergo_ext_retire_pending(s); // this sweep's own rewrite_pool() calls
		                           // may have just zeroed out a nested var
		if (ergo_propagate(s) != AREF_NIL)
			s->ok = false;

		LOG(s, "extdiag restarts=%llu orig_nvars=%d nvars=%d ext_vars=%llu"
				" cand_heap=%d cand_hash_live=%d",
				(unsigned long long)s->stat.starts,
				s->ext_orig_nvars, s->size,
				(unsigned long long)s->ext_rewrites,
				s->ext_cand_heap_sz, s->ext_cand_hash_live);
	}
}
