/*
 * api.h
 *
 *  Created on: Apr 2, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef SAT_H_
#define SAT_H_

// system includes:
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
// local includes:
#include "clset.h"
#include "lit.h"
#include "vect.h"

// local types:
//=============================================================================
struct ergo;  // actual field layout is shown in ergo.h

// local functions prototypes:
//=============================================================================

extern struct ergo *ergo_new            (void);
extern void        ergo_delete         (struct ergo *);

extern bool        ergo_append_formula (struct ergo *, struct clset *);
extern bool        ergo_import_formula (struct ergo *, struct clset *);
extern bool        ergo_load_formula   (struct ergo *, FILE *);
extern void        ergo_set_proof      (struct ergo *, FILE *);
extern bool        ergo_add_cl         (struct ergo *, struct clause *);
extern bool        ergo_solve          (struct ergo *, struct vect *);
extern lbool       ergo_solve_lim      (struct ergo *, struct vect *);
extern bool        ergo_prop_check     (struct ergo *, struct vect *, struct vect *, int);
extern bool        ergo_simplify       (struct ergo *);
extern void        ergo_clear_learnts  (struct ergo *);

extern void        ergo_set_cbudget    (struct ergo *, int64_t);
extern void        ergo_set_pbudget    (struct ergo *, int64_t);
extern void        ergo_budget_off     (struct ergo *);
extern void        ergo_interrupt      (struct ergo *);
extern void        ergo_clear_interrupt(struct ergo *);

extern int         ergo_nvars          (struct ergo *);
extern size_t      ergo_nclauses       (struct ergo *);
extern size_t      ergo_nlearnts       (struct ergo *);
extern uint64_t    ergo_nconflicts     (struct ergo *);
extern uint64_t    ergo_ndecisions     (struct ergo *);
extern uint64_t    ergo_npropagations  (struct ergo *);
extern uint64_t    ergo_nstarts        (struct ergo *);
extern void        ergo_print_model    (struct ergo *);

extern void        ergo_setnvars       (struct ergo *, int);
extern void        ergo_set_start      (struct ergo *, bool);
extern void        ergo_set_polar      (struct ergo *, struct vect *, bool);
extern void        ergo_set_acts       (struct ergo *, struct vect *vars,
                                                       struct vect *acts);  // excluded vars receive activity 0.0
extern void        ergo_set_dvars      (struct ergo *, struct vect *);
extern void        ergo_set_dvars_all  (struct ergo *);
extern void        ergo_bump_first     (struct ergo *, int);
extern void        ergo_bump_some      (struct ergo *, struct vect *);
extern void        ergo_set_jwmode     (struct ergo *);

// IPASIR-UP API for connecting and disconnecting an external propagator;
// only one propagator can be connected at a time; connecting a new one
// implicitly disconnects whatever was connected before.
struct ergo_propagator {
	void *ctx;
	bool  is_lazy;  // if set, the notify_*/cb_decide/cb_propagate hooks
			// are skipped;

	void (*notify_assignment)(void *ctx, const int *lits, int n);
	void (*notify_new_decision_level)(void *ctx);
	void (*notify_backtrack)(void *ctx, int new_level);

	int  (*cb_decide)(void *ctx);                              // 0 = no suggestion
	int  (*cb_propagate)(void *ctx);                           // 0 = nothing to propagate
	int  (*cb_add_reason_clause_lit)(void *ctx, int propagated_lit); // 0 = done

	bool (*cb_has_external_clause)(void *ctx, bool *is_forgettable);
	int  (*cb_add_external_clause_lit)(void *ctx);              // 0 = done

	bool (*cb_check_found_model)(void *ctx, const int *model, int n);
};

extern void                   ergo_connect_propagator   (struct ergo *, struct ergo_propagator *);
extern void                   ergo_disconnect_propagator(struct ergo *);
extern struct ergo_propagator *ergo_get_propagator       (struct ergo *);
extern void                   ergo_observe_var          (struct ergo *, int var);   // 0-based
extern void                   ergo_unobserve_var        (struct ergo *, int var);
extern bool                   ergo_is_decision          (struct ergo *, int dimacs_lit);
extern void                   ergo_force_backtrack      (struct ergo *, int new_level);

#endif // SAT_H_
