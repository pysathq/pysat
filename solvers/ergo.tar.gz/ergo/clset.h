/*
 * clset.h
 *
 *  Created on: Dec 24, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef CLSET_H_
#define CLSET_H_

// system includes:
#include <stdbool.h>
// local includes:
#include "arena.h"
#include "clausemm.h"
#include "vect.h"
// local defines:

// local types:
//=============================================================================

// clause set
struct clset {
	struct aref_vect ptrs;    // (contains: aref)
	struct clmm storage;
};

//
//=============================================================================
static inline void clset_init(struct clset *self, struct arena *arena, bool learnt)
{
	vect_init(&self->ptrs);
	clmm_init(&self->storage, arena, learnt);
}

//
//=============================================================================
static inline struct clset clset_new(struct arena *arena, bool learnt)
{
	struct clset self;
	clset_init(&self, arena, learnt);

	return self;
}

//
//=============================================================================
static inline struct clset *clset_new_p(struct arena *arena, bool learnt)
{
	struct clset *self = malloc(sizeof(struct clset));
	clset_init(self, arena, learnt);

	return self;
}

//
//=============================================================================
static inline void clset_destroy(struct clset *self)
{
	vect_destroy(&self->ptrs);
	clmm_destroy(&self->storage);
}

//
//=============================================================================
static inline void clset_destroy_p(struct clset *self)
{
	clset_destroy(self);
	free(self);
}

//
//=============================================================================
static inline struct clause *clset_deref(struct clset *self, aref cl)
{
	return clmm_deref(&self->storage, cl);
}

//
//=============================================================================
static inline aref clset_add(
	struct clset *self,
	struct int_vect *lits,
	bool learnt
)
{
	aref cl = clmm_alloc(&self->storage, vect_size(lits));
	cl_init(clset_deref(self, cl), lits, learnt);

	vect_append(&self->ptrs, cl);
	cl_setidx(clset_deref(self, cl), (unsigned)(vect_size(&self->ptrs) - 1));
	return cl;
}

//
//=============================================================================
static inline aref clset_add_unary(
	struct clset *self,
	int l,
	bool learnt
)
{
	struct int_vect lits = vect_new(int_vect);
	vect_append(&lits, l);

	aref cl = clset_add(self, &lits, learnt);

	vect_destroy(&lits);
	return cl;
}

//
//=============================================================================
static inline aref clset_add_binary(
	struct clset *self,
	int l1,
	int l2,
	bool learnt
)
{
	struct int_vect lits = vect_new(int_vect);
	vect_append(&lits, l1);
	vect_append(&lits, l2);

	aref cl = clset_add(self, &lits, learnt);

	vect_destroy(&lits);
	return cl;
}

//
//=============================================================================
static inline aref clset_add_ternary(
	struct clset *self,
	int l1,
	int l2,
	int l3,
	bool learnt
)
{
	struct int_vect lits = vect_new(int_vect);
	vect_append(&lits, l1);
	vect_append(&lits, l2);
	vect_append(&lits, l3);

	aref cl = clset_add(self, &lits, learnt);

	vect_destroy(&lits);
	return cl;
}

// takes a clause instead of a vector of literals
//=============================================================================
static inline aref clset_import(
	struct clset *self,
	struct clause *cl
)
{
	struct int_vect lits = {
		.cap   = cl_size(cl),
		.nmemb = cl_size(cl),
		.ptr   = cl->lits };

	return clset_add(self, &lits, cl_learnt(cl));
}

// detach by swapping with the last clause; keep its storage
//=============================================================================
static inline void clset_detach(struct clset *self, aref cl)
{
	unsigned p    = cl_idx(clset_deref(self, cl));
	size_t   last = vect_size(&self->ptrs) - 1;

	if (p != last) {
		aref moved = *(aref *)vect_at(&self->ptrs, last);
		vect_replace(&self->ptrs, p, moved);
		cl_setidx(clset_deref(self, moved), (unsigned)p);
	}

	vect_shrink(&self->ptrs, last);
}

//
//=============================================================================
static inline void clset_remove(struct clset *self, aref cl)
{
	clset_detach(self, cl);
	clmm_free(&self->storage, cl);
}

// cl_old must be a live member of this set
//=============================================================================
static inline aref clset_replace(
	struct clset *self,
	aref cl_old,
	struct int_vect *lits_new
)
{
	unsigned p       = cl_idx(clset_deref(self, cl_old));
	bool     learnt  = cl_learnt(clset_deref(self, cl_old));

	aref cl_new = clmm_alloc(&self->storage, vect_size(lits_new));
	cl_init(clset_deref(self, cl_new), lits_new, learnt);
	cl_setidx(clset_deref(self, cl_new), p);

	vect_replace(&self->ptrs, p, cl_new);
	clmm_free(&self->storage, cl_old);

	return cl_new;
}

//
//=============================================================================
static inline size_t clset_size(struct clset *self)
{
	return self->ptrs.nmemb;
}

//
//=============================================================================
static inline bool clset_empty(struct clset *self)
{
	return self->ptrs.nmemb == 0;
}

//
//=============================================================================
static inline aref *clset_begin(struct clset *self)
{
	return vect_begin(&self->ptrs);
}

//
//=============================================================================
static inline void clset_shrink(struct clset *self, size_t to)
{
	vect_shrink(&self->ptrs, to);
}

//
//=============================================================================
static inline aref *clset_end(struct clset *self)
{
	return vect_end(&self->ptrs);
}

//
//=============================================================================
static inline aref clset_at(struct clset *self, size_t pos)
{
	return *(aref *)vect_at(&self->ptrs, pos);
}

//
//=============================================================================
static inline void clset_clear(struct clset *self)
{
	aref *cls = clset_begin(self);

	for (size_t i = 0; i < clset_size(self); ++i)
		clmm_free(&self->storage, cls[i]);

	vect_shrink(&self->ptrs, 0);
}

//
//=============================================================================
static inline void clset_dump(struct clset *self, enum oformat fmt, FILE *fp)
{
	aref *cls = clset_begin(self);

	for (size_t i = 0; i < clset_size(self); ++i)
		cl_dump(clset_deref(self, cls[i]), fmt, fp);
}

#endif // CLSET_H_
