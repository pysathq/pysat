/*
 * ext.h
 *
 *  Created on: Oct 5, 2026
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@monash.edu
 */

#ifndef EXT_H_
#define EXT_H_

// system includes:
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
// local includes:
#include "arena.h"
#include "lit.h"
#include "ergo.h"

// --ext: mine recurring pairs and promote them to names z <-> (la v lb).
//
//   pool           candidate records, indexed by stable record ids
//   free_list      reusable record ids
//   hash           (la,lb) -> record id
//   heap/heap_pos  activity min-heap and reverse positions
//
// Undecayed counts control promotion; decayed activity controls eviction.
//
//   mine(la, lb, weight):
//       rec = hash.find(la, lb)
//       if rec exists: pool[rec].count += weight
//                       heap_activity[heap_pos[rec]] += inc
//                       heap_sift(heap_pos[rec]); return
//       if free_list.empty():
//           weakest = heap[0]                        # O(1): heap root
//           if inc <= heap_activity[0]: return  # not strong enough
//           evict(weakest)
//       rec = free_list.pop()
//       pool[rec] = {la, lb, count: weight, activity: inc}
//       heap_insert(rec); hash.insert(la, lb, rec)
//
//   evict(rec):
//       hash.delete(pool[rec].la, pool[rec].lb)
//       heap_remove(heap_pos[rec]); free_list.push(rec)
//
//   restart_sweep(threshold):          # once per restart, O(n)
//       for i in 0 .. heap_size-1:      # plain array walk; heap ORDER
//           rec = heap[i]               # is irrelevant to this check
//           if pool[rec].count >= threshold:
//               evict(rec); ergo_extend(pool[rec].la, pool[rec].lb)
//
// Example (toy capacity 3): mine(A,B)/mine(C,D)/mine(E,F) fill the entire
// table. Assume (A,B) keeps recurring, its activity pulls ahead; (C,D)/(E,F)
// go stale. mine(G,H) arrives new: table's full, heap[0] (say (C,D)) loses to
// the newcomer's current increment and gets evicted to make room. Separately,
// (E,F) was mined so often early on that its count crossed the promotion
// threshold even though its activity has since fallen behind. The next
// restart's sweep finds it by count, evicts it here, and hands it to
// ergo_extend() to get a real extension variable.
//
// Named pairs live in ext_var_hash until retirement; substitution reuses z.
// Mined pairs that are blocked by a caller map to var_undef and never retire.
//=============================================================================

// local types:
//=============================================================================

// definition and reference count of a named extension variable
struct ext_def {
	int  refc;
	aref def[3];
	int  la, lb;
	int  zlit;
	int  active_pos;
};

// refc of a caller's ergo_xname() name: never reaches 0, so never retired
#define EXT_OWNED (INT_MAX / 2)

// candidate pair: count controls promotion, activity controls eviction
struct ext_cand {
	int    la, lb;
	double count;     // promotion gate
};

// one tracked pair as reported by ergo_xpairs(): either already promoted
// ('z' names it) or still only a candidate ('z' == 0, ranked by 'count')
struct ergo_xpair {
	int    la, lb;   // DIMACS
	int    z;        // DIMACS, or 0 if not promoted
	double count;    // only meaningful when z == 0
};

DECLARE_VECT(xpair_vect, struct ergo_xpair, size_t);

// (la,lb) -> rec slot;
// 'la' doubles as the empty/tombstone tag
// (var_undef = empty, lit_undef = tombstone)
struct ext_hash_slot {
	int la, lb;
	int rec;
};

// local functions prototypes:
//=============================================================================

// lifecycle, called from ergo_new()/ergo_setnvars()/ergo_delete()
extern void ext_init     (struct ergo *s);
extern void ext_reset    (struct ergo *s);
extern void ext_grow_vars(struct ergo *s);
extern void ext_destroy  (struct ergo *s);

// resets a (possibly reused) variable's ext-specific fields
//=============================================================================
static inline void ext_init_var(struct ergo *s, int var)
{
	if (s->ext_scope)
		s->ext_scope[var] = false;
	if (!s->ext_defs)
		return;
	s->ext_defs  [var] = (struct ext_def){
		.refc = 0,
		.def = { AREF_NIL, AREF_NIL, AREF_NIL },
		.la = lit_undef, .lb = lit_undef, .zlit = lit_undef,
		.active_pos = -1
	};
}

// queue an unreferenced name; its registry entry stays until removal
extern void ergo_ext_die(struct ergo *s, int v);

// increment referenced extension variables, reviving pending retirements
//=============================================================================
static inline void ext_cl_created(struct ergo *s, aref cl)
{
	struct clause *cde = arena_deref(&s->arena, cl);
	int *lits = cl_begin(cde);
	bool has_ext = false;

	for (int i = 0; i < cl_size(cde); ++i) {
		struct ext_def *d = &s->ext_defs[lit_var(lits[i])];
		if (d->la != lit_undef) {
			if (d->refc < 0)
				d->refc = 0;
			d->refc++;
			has_ext = true;
		}
	}

	if (has_ext)
		cl_setext(cde, true);
}

// decrement referenced extension variables; retire at zero
//=============================================================================
static inline void ext_cl_removed(struct ergo *s, struct clause *cl)
{
	if (!cl_ext(cl))
		return;

	int *lits = cl_begin(cl);
	for (int i = 0; i < cl_size(cl); ++i) {
		int v = lit_var(lits[i]);
		struct ext_def *d = &s->ext_defs[v];
		if (d->la != lit_undef && d->refc >= 0) {
			--d->refc;
			if (d->refc == 0)
				ergo_ext_die(s, v);
		}
	}
}

// re-queues a dying (refc < 0) variable the instant it is actually unassigned
//=============================================================================
static inline void ext_var_unassigned(struct ergo *s, int v)
{
	if (s->ext_defs[v].refc < 0)
		vect_append(&s->ext_zero_pending, v);
}

// relocate definition clauses; AREF_NIL denotes a permanent fact
//=============================================================================
static inline void ext_compact_relocate(struct ergo *s)
{
	for (size_t i = 0; i < vect_size(&s->ext_active); ++i) {
		int v = *(int *)vect_at(&s->ext_active, i);
		struct ext_def *d = &s->ext_defs[v];

		if (d->def[0] != AREF_NIL) d->def[0] = clmm_reloc(&s->arena, d->def[0]);
		if (d->def[1] != AREF_NIL) d->def[1] = clmm_reloc(&s->arena, d->def[1]);
		if (d->def[2] != AREF_NIL) d->def[2] = clmm_reloc(&s->arena, d->def[2]);
	}
}

// protect clauses containing a live extension variable
//=============================================================================
static inline bool ext_cl_protected(struct ergo *s, struct clause *c)
{
	int *lits = cl_begin(c);
	for (int k = 0; k < cl_size(c); ++k)
		if (s->ext_defs[lit_var(lits[k])].la != lit_undef)
			return true;

	return false;
}

// fixed at setup time; call at most once, right after ergo_new(),
// before any solving starts;
extern void ergo_xenable     (struct ergo *, bool);

// per-solver overrides of --ext's tuning defaults;
// safe to call any time, takes effect on the next check;
extern void ergo_setxthreshold(struct ergo *, double);
extern void ergo_setxwarmup   (struct ergo *, int64_t);
extern void ergo_setxescalate (struct ergo *, double);

// rewriting and full equivalence default to enabled;
// disabling rewriting pins new names; disabling equivalence also disables rewriting
extern void ergo_setxrewrite  (struct ergo *, bool);
extern void ergo_setxequiv    (struct ergo *, bool);

// update the mining scope with disjoint add/rem variable sets;
// both empty resets to all variables; extension variables join automatically
// and leave recursively when both defining variables leave
extern void ergo_setxscope(struct ergo *, struct int_vect *add,
                                          struct int_vect *rem); // of int, 0-based

// report named pairs, then candidates, as struct ergo_xpair;
// last argument: DIMACS literal filter (no repeats), or NULL for all
extern void ergo_xpairs(struct ergo *, struct xpair_vect *, struct int_vect *);

// adopt caller-owned names from struct ergo_xpair (count ignored), never
// retired; skip existing naming variables; duplicate pairs get definitions only
extern void ergo_xname(struct ergo *, struct xpair_vect *);

// take the caller's pairs out of mining for good
extern void ergo_xblock(struct ergo *, struct xpair_vect *);

// pin/unpin takes/releases one reference per variable, preventing retirement
extern void ergo_xpin  (struct ergo *, struct int_vect *); // of int, 0-based
extern void ergo_xunpin(struct ergo *, struct int_vect *); // of int, 0-based

// mine pairs from reason, external and learnt clauses
extern void ergo_ext_mine_cl    (struct ergo *s, int *lits, size_t n, size_t start);
extern void ergo_ext_mine_learnt(struct ergo *s, struct int_vect *learnt);

// substitute named pairs before storing reason or external clauses
extern void ergo_ext_subst(struct ergo *s, struct int_vect *lits, size_t start);

// remove definition clauses of pending retired variables
extern void ergo_ext_retire_pending(struct ergo *s);

// promote qualifying pairs at level 0 after a restart
extern void ergo_ext_rewrite(struct ergo *s);

#endif // EXT_H_
