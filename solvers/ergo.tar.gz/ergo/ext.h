/*
 * ext.h
 *
 *  Created on: Oct 5, 2026
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@monash.edu
 */

#ifndef EXT_H_
#define EXT_H_

// system includes:
#include <stdbool.h>
#include <stdint.h>
// local includes:
#include "arena.h"
#include "lit.h"
#include "ergo.h"

// --ext: automatic extension-variable discovery. Mines recurring literal
// pairs (la,lb) out of learnt/reason/external clauses as the search runs;
// once a pair recurs often enough, a restart rewrites the clause database
// to use a fresh variable z <-> (la v lb) in its place.
//
// Tracking not-yet-promoted pairs takes four cooperating structures, each
// answering one question:
//
//   pool[CAP]      struct ext_cand  the (la,lb,count,activity) records,
//                                   indexed by a stable id 'rec'
//   free_list      stack<int>       recycled, unused 'rec' ids
//   hash           (la,lb) -> rec   "seen this pair before?" -- asked on each
//                                   pair in every learnt clause / conflict
//   heap/heap_pos  rec[], rec->pos  "who's the weakest tracked pair?" -
//                                   asked whenever the hash table is full; a
//                                   min-heap by 'activity';'heap_pos' lets a
//                                   bump re-settle it
//
// 'count' (undecayed, lifetime) and 'activity' (VSIDS-style decayed) are
// deliberately different: eviction wants "gone cold recently" (cheap to
// get wrong -- an evicted pair just restarts from scratch if it recurs),
// so it decays; promotion wants "recurred reliably over its whole life"
// (permanent, hard to undo), so it never does.
//
//   mine(la, lb, weight):
//       rec = hash.find(la, lb)
//       if rec exists: pool[rec].count += weight; pool[rec].activity += inc
//                       heap_sift(heap_pos[rec]); return
//       if free_list.empty():
//           weakest = heap[0]                        # O(1): heap root
//           if inc <= pool[weakest].activity: return  # not strong enough
//           evict(weakest)
//       rec = free_list.pop()
//       pool[rec] = {la, lb, count: weight, activity: inc}
//       heap_insert(rec); hash.insert(la, lb, rec)
//
//   evict(rec):
//       hash.delete(pool[rec].la, pool[rec].lb)
//       heap_remove(heap_pos[rec]); free_list.push(rec)
//
//   restart_sweep(threshold):          # once per restart, O(n)
//       for i in 0 .. heap_size-1:      # plain array walk; heap ORDER
//           rec = heap[i]               # is irrelevant to this check
//           if pool[rec].count >= threshold:
//               evict(rec); ergo_extend(pool[rec].la, pool[rec].lb)
//
// Example (toy capacity 3): mine(A,B)/mine(C,D)/mine(E,F) fill the entire
// table. Assume (A,B) keeps recurring, its activity pulls ahead; (C,D)/(E,F)
// go stale. mine(G,H) arrives new: table's full, heap[0] (say (C,D)) loses to
// the newcomer's current increment and gets evicted to make room. Separately,
// (E,F) was mined so often early on that its count crossed the promotion
// threshold even though its activity has since fallen behind. The next
// restart's sweep finds it by count, evicts it here, and hands it to
// ergo_extend() to get a real extension variable.
//
// A promoted pair leaves this system entirely and is registered permanently
// in 's->ext_var_hash' (la,lb -> z) instead, checked by ergo_ext_subst() so
// a recurring pair folds into z rather than being re-mined.
//=============================================================================

// local types:
//=============================================================================

// per-variable state for a promoted extension variable: live-clause
// refcount, its 3 definition clauses' arefs, its (la,lb) pair, and its
// index into 's->ext_active'.
struct ext_def {
	int  refc;
	aref def[3];
	int  la, lb;
	int  active_pos;
};

// a not-yet-promoted candidate literal-pair. z's activity seeds from the
// average of la/lb's own; count bumps by 1/|decision-level diff| per re-mine
struct ext_cand {
	int    la, lb;
	double count;     // promotion gate
	double activity;  // eviction priority
};

// one tracked pair as reported by ergo_xpairs(): either already promoted
// ('z' names it) or still only a candidate ('z' == 0, ranked by 'count')
struct ergo_xpair {
	int    la, lb;   // DIMACS
	int    z;        // DIMACS, or 0 if not promoted
	double count;    // only meaningful when z == 0
};

// (la,lb) -> rec slot;
// 'la' doubles as the empty/tombstone tag
// (var_undef = empty, lit_undef = tombstone)
struct ext_hash_slot {
	int la, lb;
	int rec;
};

// local functions prototypes:
//=============================================================================

// lifecycle, called from ergo_new()/ergo_setnvars()/ergo_delete()
extern void ext_init     (struct ergo *s);
extern void ext_grow_vars(struct ergo *s);
extern void ext_destroy  (struct ergo *s);

// resets a (possibly reused) variable's ext-specific fields
//=============================================================================
static inline void ext_init_var(struct ergo *s, int var)
{
	s->ext_scope [var] = false;
	s->ext_reason[var] = false;
	s->ext_defs  [var] = (struct ext_def){
		.refc = 0,
		.def = { AREF_NIL, AREF_NIL, AREF_NIL },
		.la = lit_undef, .lb = lit_undef, .active_pos = -1
	};
}

// retires 'v' when its refcount reaches 0; removes 'v' from 's->ext_active';
extern void ergo_ext_die(struct ergo *s, int v);
extern void ergo_ext_active_remove(struct ergo *s, int v);

// undoes a tombstone ergo_ext_die() already left in 's->ext_var_hash';
extern void ext_var_insert(struct ergo *s, int la, int lb, int zlit);

// bumps every live extension variable 'cl' references; a dying variable
// (refc==-1, queued but not yet drained) gets revived here if a later clause
// in the same sweep still references it;
//=============================================================================
static inline void ext_cl_created(struct ergo *s, aref cl)
{
	struct clause *cde = arena_deref(&s->arena, cl);
	int *lits = cl_begin(cde);
	bool has_ext = false;

	for (int i = 0; i < cl_size(cde); ++i) {
		struct ext_def *d = &s->ext_defs[lit_var(lits[i])];
		if (d->la != lit_undef) {
			if (d->refc < 0) {
				d->refc = 0;
				ext_var_insert(s, d->la, d->lb, lit_of(lit_var(lits[i])));
			}
			d->refc++;
			has_ext = true;
		}
	}

	if (has_ext)
		cl_setext(cde, true);
}

// mirrors ext_cl_created(): drops 'cl's references, dying a variable that
// reaches refc 0 immediately;
//=============================================================================
static inline void ext_cl_removed(struct ergo *s, struct clause *cl)
{
	if (!cl_ext(cl))
		return;

	int *lits = cl_begin(cl);
	for (int i = 0; i < cl_size(cl); ++i) {
		int v = lit_var(lits[i]);
		struct ext_def *d = &s->ext_defs[v];
		if (d->la != lit_undef && d->refc >= 0) {
			--d->refc;
			if (d->refc == 0)
				ergo_ext_die(s, v);
		}
	}
}

// re-queues a dying (refc < 0) variable the instant it is actually unassigned
//=============================================================================
static inline void ext_var_unassigned(struct ergo *s, int v)
{
	if (s->ext_defs[v].refc < 0)
		vect_append(&s->ext_zero_pending, v);
}

// relocates every live extension variable's 3 definition-clause arefs;
// a slot can be AREF_NIL if that definition was already a permanent fact
// when 'v' was created (ergo_ext_def_cl()) -- nothing to relocate there;
//=============================================================================
static inline void ext_compact_relocate(struct ergo *s)
{
	for (size_t i = 0; i < vect_size(&s->ext_active); ++i) {
		int v = *(int *)vect_at(&s->ext_active, i);
		struct ext_def *d = &s->ext_defs[v];

		if (d->def[0] != AREF_NIL) d->def[0] = clmm_reloc(&s->arena, d->def[0]);
		if (d->def[1] != AREF_NIL) d->def[1] = clmm_reloc(&s->arena, d->def[1]);
		if (d->def[2] != AREF_NIL) d->def[2] = clmm_reloc(&s->arena, d->def[2]);
	}
}

// true iff 'c' is a permanent clause that can only be a still-live
// extension variable's own definition clause;
//=============================================================================
static inline bool ext_cl_protected(struct ergo *s, struct clause *c)
{
	int *lits = cl_begin(c);
	for (int k = 0; k < cl_size(c); ++k)
		if (s->ext_defs[lit_var(lits[k])].la != lit_undef)
			return true;

	return false;
}

// fixed at setup time; call at most once, right after ergo_new(),
// before any solving starts;
extern void ergo_xenable     (struct ergo *, bool);

// per-solver overrides of --ext's tuning defaults;
// safe to call any time, takes effect on the next check;
extern void ergo_setxthreshold(struct ergo *, double);
extern void ergo_setxwarmup   (struct ergo *, int64_t);
extern void ergo_setxescalate (struct ergo *, double);

// restricts --ext's mining to a specific variable set -- typically the
// input variables of an external constraint; a pair is only mined if both
// literals are in scope; 'add' variables join the scope, 'rem' variables
// leave it, and the two must be disjoint; if both are empty, the function
// resets the scope to the default including every variable;
// a rewrite-born variable joins the scope on its own, so a scoped family
// can nest; 'rem' takes it back out once both of its defining literals have
// left, recursively -- or two of them would still pair with each other;
extern void ergo_setxscope(struct ergo *, struct vect *add,
                                          struct vect *rem); // of int, 0-based

// every pair --ext currently tracks: the promoted ones first, then the
// candidates; output is a vect of struct ergo_xpair;
// valid until the next solve, like a model or a core;
extern void ergo_xpairs(struct ergo *, struct vect *);

// forces Ergo to hold a reference on each variable in the input vect,
// so its refcount can no longer reach 0 and its id is never recycled;
// unpin decrements that reference by 1, again for each variable in the
// input vect;
extern void ergo_xpin  (struct ergo *, struct vect *); // of int, 0-based
extern void ergo_xunpin(struct ergo *, struct vect *); // of int, 0-based

// mining entry points; called from ergo_reason()/ergo_propagate_ext()
// (a freshly-arrived reason/external clause) and ergo_search() (a learnt
// clause, each conflict);
extern void ergo_ext_mine_cl    (struct ergo *s, int *lits, size_t n, size_t start);
extern void ergo_ext_mine_learnt(struct ergo *s, struct vect *learnt);

// folds an already-extended pair into its z on the spot, before a
// freshly-arriving reason/external clause is even stored;
// called from ergo_build_reason_clause()/ergo_propagate_ext();
extern void ergo_ext_subst(struct ergo *s, struct vect *lits, size_t start);

// drains 's->ext_zero_pending', removing each dying variable's 3
// definition clauses; called from ergo_reducedb()/ergo_reducedb_gluc()/
// ergo_simplify()/ergo_ext_rewrite() itself;
extern void ergo_ext_retire_pending(struct ergo *s);

// runs the restart_sweep() described above;
// called once per restart, at decision level 0
extern void ergo_ext_rewrite(struct ergo *s);

#endif // EXT_H_
