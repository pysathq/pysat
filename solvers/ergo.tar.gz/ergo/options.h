/*
 * options.h
 *
 *  Created on: May 14, 2012
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

#ifndef OPTIONS_H_
#define OPTIONS_H_

// system includes:
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// local includes:
// local defines:

struct options {
	float cla_decay;
	float var_decay;
	float reduce_by;

	char *restart_policy;
	char *reducedb_policy;
	int restart_first;
	float restart_inc;
	int min_learnts;

	bool glucose_bump;
	char *adapt_at;
	bool keep_binary;
	bool lcm;
	bool no_copy;
	bool ext;
	bool help;
	bool version;
	int verbose;
	int ccmin_mode;
	int phase_saving;
	char *emulate;
	char *jw_mode;
	char *proof_trace;

	bool adapt_at_set;
	bool ccmin_mode_set;
	bool cla_decay_set;
	bool emulate_set;
	bool jw_mode_set;
	bool min_learnts_set;
	bool phase_saving_set;
	bool proof_trace_set;
	bool reduce_by_set;
	bool restart_first_set;
	bool restart_inc_set;
	bool restart_policy_set;
	bool reducedb_policy_set;
	bool var_decay_set;
	bool verbose_set;

	int restc;
	char **restv;
};

//
//=============================================================================
static inline void opt_init(struct options *self)
{
	self->cla_decay = 0.999;
	self->var_decay = 0.95;
	self->reduce_by = 0.5;

	self->restart_policy = malloc(5 * sizeof(char));
	strcpy(self->restart_policy, "geom");
	self->restart_first  = 100;
	self->restart_inc    = 2;
	self->min_learnts    = 0;

	self->glucose_bump = false;
	self->keep_binary  = false;
	self->lcm          = false;
	self->no_copy      = false;
	self->ext          = false;
	self->help         = false;
	self->version      = false;
	self->verbose      = 0;
	self->ccmin_mode   = 0;
	self->phase_saving = 0;

	self->adapt_at = malloc(6 * sizeof(char));
	strcpy(self->adapt_at, "never");

	self->emulate = malloc(5 * sizeof(char));
	strcpy(self->emulate, "none");

	self->jw_mode = malloc(5 * sizeof(char));
	strcpy(self->jw_mode, "none");

	self->proof_trace = malloc(1 * sizeof(char));
	strcpy(self->proof_trace, "");

	self->reducedb_policy = malloc(9 * sizeof(char));
	strcpy(self->reducedb_policy, "standard");

	self->adapt_at_set        = false;
	self->ccmin_mode_set      = false;
	self->cla_decay_set       = false;
	self->emulate_set         = false;
	self->jw_mode_set         = false;
	self->min_learnts_set     = false;
	self->phase_saving_set    = false;
	self->proof_trace_set     = false;
	self->reduce_by_set       = false;
	self->restart_first_set   = false;
	self->restart_inc_set     = false;
	self->restart_policy_set  = false;
	self->reducedb_policy_set = false;
	self->var_decay_set       = false;
	self->verbose_set         = false;

	self->restc = 0;
	self->restv = NULL;
}

//
//=============================================================================
static inline struct options *opt_new(void)
{
	struct options *self = malloc(sizeof(struct options));

	opt_init(self);

	return self;
}

//
//=============================================================================
static inline void opt_destroy(struct options *self)
{
	free(self->reducedb_policy);
	free(self->adapt_at);
	free(self->emulate);
	free(self->jw_mode);
	free(self->proof_trace);
	free(self->restart_policy);

	if (self->restc != 0) {
		for (int i = 0; i < self->restc; ++i)
			free(self->restv[i]);
		free(self->restv);
	}
}

//
//=============================================================================
static inline void opt_del(struct options *self)
{
	opt_destroy(self);
	free(self);
}

//
//=============================================================================
static inline bool opt_parse(struct options *self, int argc, char *argv[])
{
	bool res = true;

	static char option_string[] = "a:hlv";

	static struct option long_options[] = {
		{ "adapt-at", 1, 0, 'a' },
		{ "ccmin-mode", 1, 0, 256 },
		{ "cla-decay", 1, 0, 257 },
		{ "dbpolicy", 1, 0, 258 },
		{ "emulate", 1, 0, 259 },
		{ "ext", 0, 0, 274 },
		{ "glucose-bump", 0, 0, 260 },
		{ "help", 0, 0, 'h' },
		{ "jw-mode", 1, 0, 262 },
		{ "keep-bin", 0, 0, 263 },
		{ "lcm", 0, 0, 'l' },
		{ "min-learnts", 1, 0, 264 },
		{ "no-copy", 0, 0, 265 },
		{ "phase-saving", 1, 0, 266 },
		{ "proof-trace", 1, 0, 267 },
		{ "reduceby", 1, 0, 268 },
		{ "rfirst", 1, 0, 269 },
		{ "rinc", 1, 0, 270 },
		{ "rpolicy", 1, 0, 271 },
		{ "var-decay", 1, 0, 272 },
		{ "version", 0, 0, 273 },
		{ "verb", 0, 0, 'v' },
		{ 0, 0, 0, 0 }
	};

	while (res) {
		int option_index = 0;

		int c = getopt_long(argc, argv, option_string, long_options, &option_index);
		if (c == -1)
			break;

		switch (c) {
		case 0:
			break;
		case 'a':
			self->adapt_at = realloc(self->adapt_at, (strlen(optarg) + 1) * sizeof(char));
			strcpy(self->adapt_at, optarg);
			self->adapt_at_set = true;
			break;
		case 256:
			self->ccmin_mode = atoi(optarg);
			self->ccmin_mode_set = true;
			break;
		case 257:
			self->cla_decay = atof(optarg);
			self->cla_decay_set = true;
			break;
		case 258:
			self->reducedb_policy = realloc(self->reducedb_policy, (strlen(optarg) + 1) * sizeof(char));
			strcpy(self->reducedb_policy, optarg);
			self->reducedb_policy_set = true;
			break;
		case 259:
			self->emulate = realloc(self->emulate, (strlen(optarg) + 1) * sizeof(char));
			strcpy(self->emulate, optarg);
			self->emulate_set = true;
			break;
		case 260:
			self->glucose_bump = true;
			break;
		case 274:
			self->ext = true;
			break;
		case 'h':
			self->help = true;
			break;
		case 262:
			self->jw_mode = realloc(self->jw_mode, (strlen(optarg) + 1) * sizeof(char));
			strcpy(self->jw_mode, optarg);
			self->jw_mode_set = true;
			break;
		case 263:
			self->keep_binary = true;
			break;
		case 'l':
			self->lcm = true;
			break;
		case 264:
			self->min_learnts = atoi(optarg);
			self->min_learnts_set = true;
			break;
		case 265:
			self->no_copy = true;
			break;
		case 266:
			self->phase_saving = atoi(optarg);
			self->phase_saving_set = true;
			break;
		case 267:
			self->proof_trace = realloc(self->proof_trace, (strlen(optarg) + 1) * sizeof(char));
			strcpy(self->proof_trace, optarg);
			self->proof_trace_set = true;
			break;
		case 268:
			self->reduce_by = atof(optarg);
			self->reduce_by_set = true;
			break;
		case 269:
			self->restart_first = atoi(optarg);
			self->restart_first_set = true;
			break;
		case 270:
			self->restart_inc = atof(optarg);
			self->restart_inc_set = true;
			break;
		case 271:
			self->restart_policy = realloc(self->restart_policy, (strlen(optarg) + 1) * sizeof(char));
			strcpy(self->restart_policy, optarg);
			self->restart_policy_set = true;
			break;
		case 272:
			self->var_decay = atof(optarg);
			self->var_decay_set = true;
			break;
		case 273:
			self->version = true;
			break;
		case 'v':
			self->verbose++;
			self->verbose_set = true;
			break;
		case '?':
			res = false;
			break;
		}
	}

	if (optind < argc) {
		self->restv = malloc(sizeof(char *) * (argc - optind));

		for (int i = optind; i < argc; ++i) {
			self->restv[self->restc] = malloc((strlen(argv[i]) + 1) * sizeof(char));
			strcpy(self->restv[self->restc++], argv[i]);
		}
	}

	return res;
}

//
//=============================================================================
static inline void opt_usage(FILE *ofp, char *prog_name)
{
	fprintf(ofp, "Usage: %s [options] file\n", prog_name);
	fprintf(ofp, "Options:\n");
	fprintf(ofp, "        -a, --adapt-at=<int>      Conflict count at which to adapt solver strategies\n");
	fprintf(ofp, "                                  Available values: [1 .. INT_MAX], never (default = never)\n");
	fprintf(ofp, "        --ccmin-mode=<int>        Controls conflict clause minimization\n");
	fprintf(ofp, "                                  Available values: 0, 1, 2 (default = 0)\n");
	fprintf(ofp, "        --cla-decay=<float>       The clause activity decay factor\n");
	fprintf(ofp, "                                  Available values: (0 .. 1] (default = 0.999)\n");
	fprintf(ofp, "        --dbpolicy=<string>       ReduceDB strategy\n");
	fprintf(ofp, "                                  Available values: aggressive, standard (default = standard)\n");
	fprintf(ofp, "        --emulate=<string>        Emulate another solver's behavior\n");
	fprintf(ofp, "                                  Available values: g3, g4.2, m2.0, m2.2 (default = none)\n");
	fprintf(ofp, "        --ext                     Apply extension mechanisms with default parameters\n");
	fprintf(ofp, "        --glucose-bump            Turn on glucose-like variable bumping\n");
	fprintf(ofp, "        -h, --help                Show this message\n");
	fprintf(ofp, "        --jw-mode=<string>        Turns on activity and polarity strategy based on the Jeroslow-Wang heuristic\n");
	fprintf(ofp, "                                  Available values: act, full-hard, full-soft, none, pol-hard, pol-soft (default = none)\n");
	fprintf(ofp, "        --keep-bin                Try to keep binary clauses when cleaning learnt clauses\n");
	fprintf(ofp, "        -l, --lcm                 Vivify learnt clauses (LCM) at each return to decision level 0\n");
	fprintf(ofp, "        --min-learnts=<int>       Minimum learnt clause limit\n");
	fprintf(ofp, "                                  Available values: [0 .. INT_MAX] (default = 0)\n");
	fprintf(ofp, "        --no-copy                 Try to avoid copying formula when importing\n");
	fprintf(ofp, "        --phase-saving=<int>      Controls the level of phase saving\n");
	fprintf(ofp, "                                  Available values: 0, 1, 2 (default = 0)\n");
	fprintf(ofp, "        --proof-trace=<string>    Path where the proof trace should be saved\n");
	fprintf(ofp, "        --reduceby=<float>        Amount of learnt clauses to remove\n");
	fprintf(ofp, "                                  Available values: [0 .. 1] (default = 0.5)\n");
	fprintf(ofp, "        --rfirst=<int>            The base restart interval\n");
	fprintf(ofp, "                                  Available values: [1 .. INT_MAX] (default = 100)\n");
	fprintf(ofp, "        --rinc=<float>            Restart interval increase factor (for geometric progression only)\n");
	fprintf(ofp, "                                  Available values: [1 .. FLOAT_MAX] (default = 2.0)\n");
	fprintf(ofp, "        --rpolicy=<string>        Restart sequence strategy\n");
	fprintf(ofp, "                                  Available values: arif, geom, gluc, luby (default = geom)\n");
	fprintf(ofp, "        --var-decay=<float>       The variable activity decay factor\n");
	fprintf(ofp, "                                  Available values: (0 .. 1] (default = 0.95)\n");
	fprintf(ofp, "        --version                 Print version\n");
	fprintf(ofp, "        -v, --verb                Verbosity level ('-vv' shows a model)\n");
}

#endif // OPTIONS_H_
