/*
 * ergodbg.c
 *
 *  Created on: Dec 2, 2011
 *      Author: Alexey Ignatiev
 *      E-mail: alexey.ignatiev@gmail.com
 */

// system includes:
#include <assert.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
// local includes:
#include "api.h"
#include "ergo.h"
#include "ergodbg.h"

//
//=============================================================================
void dbg_print_vect(struct vect* cl, enum oformat fmt, FILE *fp)
{
	char *delim = "", *last = "";

	if (fmt == FMT_DIMACS)
		last = " 0";
	else if (fmt == FMT_BF)
		delim = " v";

	int *l = vect_begin(cl);

	size_t i = 0;
	for (; i < vect_size(cl) - 1; ++i) {
		lit_dump(l[i], fp);
		fprintf(fp, "%s ", delim);
	}
	lit_dump(l[i], fp);
	fprintf(fp, "%s\n", last);
}

//
//=============================================================================
void dbg_print_clauses(struct ergo *s, enum oformat fmt, FILE *fp)
{
	if (fmt == FMT_DIMACS)
		fprintf(fp, "p cnf %d %lu\n", ergo_nvars(s), clset_size(&s->clauses));

	clset_dump(&s->clauses, fmt, fp);
}

//
//=============================================================================
void dbg_write_clauses(struct ergo *s, char *fname)
{
	FILE *fp = fopen(fname, "w");
	dbg_print_clauses(s, FMT_DIMACS, fp);
	fclose(fp);
}

//
//=============================================================================
void dbg_print_learnts(struct ergo *s, enum oformat fmt, FILE *fp)
{
	if (fmt == FMT_DIMACS)
		fprintf(fp, "p cnf %d %lu\n", ergo_nvars(s), clset_size(&s->learnts));

	clset_dump(&s->learnts, fmt, fp);
}

//
//=============================================================================
void dbg_write_learnts(struct ergo *s, char *fname)
{
	FILE *fp = fopen(fname, "w");
	dbg_print_learnts(s, FMT_DIMACS, fp);
	fclose(fp);
}

//
//=============================================================================
void dbg_print_reason(struct ergo *s, int var, FILE *fp, int spaces)
{
	fprintf(fp, "%*sreason: ", spaces, "");

	if (s->reasons[var] != AREF_NIL)
		cl_dump(arena_deref(&s->arena, s->reasons[var]), FMT_BF, fp);
	else
		fprintf(fp, "null\n");
}

//
//=============================================================================
void dbg_enqueue_reason(
	struct ergo *s,
	int var,
	int *vseen,
	int **v_arr,
	int *sz,
	int *pos
)
{
	if (*pos >= *sz - 1) {
		*sz <<= 1;
		*v_arr = realloc(v_arr, (*sz) * sizeof(int));
	}

	(*v_arr)[++(*pos)] = -1;

	struct clause *reason = arena_deref(&s->arena, s->reasons[var]);
	int *cl = reason->lits;
	for (int i = 1; i < cl_size(reason); ++i) {
		if (*pos >= *sz - 1) {
			*sz <<= 1;
			*v_arr = realloc(*v_arr, (*sz) * sizeof(int));
		}

		int v = lit_var(cl[i]);
		if (!vseen[v])
			(*v_arr)[++(*pos)] = v;
	}
}

//
//=============================================================================
void dbg_print_backtrace(struct ergo *s, int var, FILE *fp)
{
	int size = 100, pos = 0, spaces = 0;
	int *vseen = calloc(ergo_nvars(s), sizeof(int));
	int *v_arr = malloc(size * sizeof(int));
	v_arr[0] = var;

	fprintf(fp, "\nbacktrace for %d:\n", var + 1);

	while (pos >= 0) {
		int curr = v_arr[pos--];
		if (curr == -1) {
			spaces -= 4;
			continue;
		}

		fprintf(fp, "%*s%d:\n", spaces, "", curr + 1);
		fprintf(fp, "%*slevel: %d\n", spaces, "", s->levels[curr]);
		fprintf(fp, "%*svalue: %d\n", spaces, "",
			s->assigns[curr << 1]);
		dbg_print_reason(s, curr, fp, spaces);
		fprintf(fp, "\n");

		vseen[curr] = 1;

		if (s->reasons[curr] != AREF_NIL) {
			spaces += 4;
			dbg_enqueue_reason(s, curr, vseen, &v_arr, &size, &pos);
		}
	}

	free(v_arr);
	free(vseen);
}

// consumes exactly strlen(prefix) bytes from 'fp'; a mismatch or a premature
// EOF/newline both count as no match, and neither puts anything back;
//=============================================================================
static bool dbg_match_prefix(FILE *fp, const char *prefix)
{
	for (const char *p = prefix; *p; ++p)
		if (fgetc(fp) != *p)
			return false;

	return true;
}

//
//=============================================================================
static void dbg_skip_line(FILE *fp)
{
	int c;
	while ((c = fgetc(fp)) != '\n' && c != EOF)
		;
}

// looks for a comment line of the form "c model: 1,0,1,...\n" (one '0'/'1'
// per variable, in order) and checks it against 's->model';
//=============================================================================
void dbg_check_model(struct ergo *s, FILE *fp)
{
	static const char *prefix = "c model: ";

	if (fp == stdin)
		return;
	rewind(fp);

	bool found = false;

	while (!found) {
		int c = fgetc(fp);
		if (c == EOF)
			break;
		ungetc(c, fp);

		found = dbg_match_prefix(fp, prefix);
		if (!found)
			dbg_skip_line(fp);
	}

	if (!found) {
		printf("c no '%s' line found -- skipping model check\n", prefix);
		return;
	}

	int  k       = 0;
	bool correct = true;
	int  c;

	while (correct && (c = fgetc(fp)) != EOF && c != '\n') {
		if (c == ',' || c == ' ')
			continue;
		else if (c - '0' != (*(lbool *)vect_at(&s->model, k) + 1) / 2)
			correct = false;
		++k;
	}

	if (correct)
		printf("CORRECT\n");
	else
		printf("INCORRECT\n");

	assert(correct);
}

#ifdef LOGGING

//
//=============================================================================
void ergo_log_begin(struct ergo *s)
{
	fprintf(stderr, "c LOG %d %llu ",
			(int)vect_size(&s->trail_lim),
			(unsigned long long)s->stat.conflicts);
}

//
//=============================================================================
void ergo_log(struct ergo *s, const char *fmt, ...)
{
	ergo_log_begin(s);

	va_list ap;
	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	va_end(ap);

	fprintf(stderr, "\n");
}

#endif // LOGGING
